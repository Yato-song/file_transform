#!/usr/bin/env python3
"""深度审核FDA试验：核对试验身份、纳排条件、结果判定、来源层级"""
import json, sys, os, re

def deep_review_fda_trial(trial_rec, fda_catalog, fda_text_cache):
    """深度审核单个FDA试验"""
    rec_id = trial_rec['record_id']
    drug = trial_rec['drug']
    trial_name = trial_rec['trial_name']

    # 在FDA目录中搜索相关文件
    matching_files = []
    for item in fda_catalog:
        if drug in item.get('original_name','') or trial_name in item.get('original_name',''):
            matching_files.append({
                'id': item['id'],
                'path': item['path'],
                'type': item['archived_type'],
                'sha256': item['sha256']
            })

    # 读取文本缓存
    text_found = []
    for mf in matching_files[:5]:  # 最多读5个相关文件
        file_id = mf['id']
        cache_dirs = [d for d in os.listdir(fda_text_cache) if d.startswith(file_id)]
        if cache_dirs:
            cache_dir = os.path.join(fda_text_cache, cache_dirs[0])
            # 读取前3页
            for pg in range(1,4):
                txt_file = os.path.join(cache_dir, f'p{pg:04d}.txt')
                if os.path.exists(txt_file):
                    with open(txt_file, encoding='utf-8') as f:
                        text = f.read()
                        if trial_name in text or drug in text:
                            text_found.append({
                                'file_id': file_id,
                                'page': pg,
                                'snippet': text[:300]
                            })
                            break

    return {
        'record_id': rec_id,
        'drug': drug,
        'trial_name': trial_name,
        'matching_files_count': len(matching_files),
        'matching_files': matching_files[:3],
        'text_found': text_found[:2],
        'status': '已审' if text_found else '未找到原文'
    }

def batch_review_fda_trials(sample_path, catalog_path, text_cache, output_path):
    sampled = json.load(open(sample_path, encoding='utf-8'))
    catalog = json.load(open(catalog_path, encoding='utf-8'))

    reviews = []
    for i, trial in enumerate(sampled, 1):
        print(f"审核 {i}/{len(sampled)}: {trial['record_id']} {trial['drug']} {trial['trial_name']}")
        review = deep_review_fda_trial(trial, catalog, text_cache)
        reviews.append(review)

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(reviews, f, ensure_ascii=False, indent=2)

    found = sum(1 for r in reviews if r['status']=='已审')
    print(f"\n审核完成: {len(reviews)}个试验，找到原文{found}个")
    return reviews

if __name__ == '__main__':
    reviews = batch_review_fda_trials(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
