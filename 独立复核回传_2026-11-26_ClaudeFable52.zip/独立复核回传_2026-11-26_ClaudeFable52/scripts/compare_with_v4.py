#!/usr/bin/env python3
"""对比第一阶段独立提取与现版判断v4的差异"""
import json, sys, os

def compare_phase1_with_v4(phase1_reviews, v4_statements_path, output_path):
    """
    对比94条已审陈述与现版v4的差异
    差异类型：
    1. 引文/翻译：原文摘录、中文释义
    2. 页码：物理页vs印刷页
    3. 研究讨论vs用药建议判定
    4. 证据等级和推荐强度
    """

    # 读取phase1审核结果
    f026 = json.load(open('phase1/f026_who_dep1_reviews.json'))
    others = json.load(open('phase1/other_guidelines_reviews.json'))

    all_reviews = f026 + others

    differences = []

    for review in all_reviews:
        stmt_id = review['stmt_id']

        # 这里需要与v4比较，记录差异
        diff = {
            'stmt_id': stmt_id,
            'source': review['source'],
            'phase1_status': review.get('status', ''),
            'phase1_pages': review.get('actual_pages') or review.get('pages_checked'),
            'phase2_comparison': '待比较v4',
            'differences_found': []
        }

        differences.append(diff)

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(differences, f, ensure_ascii=False, indent=2)

    return differences

if __name__ == '__main__':
    diffs = compare_phase1_with_v4(None, None, 'phase1/phase2_differences.json')
    print(f"已生成{len(diffs)}条记录的差异模板")
