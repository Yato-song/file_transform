#!/usr/bin/env python3
"""批量审核WHO DEP1证据概况的39条陈述"""
import json, sys, os

def review_who_dep1_statements(template_path, text_cache_dir, output_path):
    """
    WHO DEP1是逐药逐结局的GRADE表，每个药物6个结局：
    1. Change in depressive symptoms (SMD)
    2. Response/efficacy (OR)
    3. All-cause dropout (OR)
    4. Dropout due to adverse events (OR)
    5. Suicide-related outcomes
    6. QoL/functioning
    """
    template = json.load(open(template_path, encoding='utf-8'))
    statements_table = [t for t in template['tables'] if t['name'] == '指南陈述626'][0]

    # 筛选F026的陈述
    f026_rows = [r for r in statements_table['rows']
                 if r[1] == 'F026']  # 来源ID在第2列（索引1）

    print(f"F026 WHO DEP1陈述总数: {len(f026_rows)}")

    # 读取F026的GRADE表页面
    f026_cache = os.path.join(text_cache_dir, 'F026__WHO_mhGAP_2023_DEP1_Antidepressants_Evidence_Profile')

    # 药物到页码的映射（从模板"旧定位页"获取）
    drug_pages = {
        '西酞普兰': (19, 20),
        '艾司西酞普兰': (21, 22),
        '氟西汀': (23, 24),
        '帕罗西汀': (27, 28),
        '舍曲林': (29, 30),
        '阿米替林': (31, 32),
        '合并SSRIs': (35,),
        '合并TCAs': (36,),
    }

    reviews = []
    for row in f026_rows:
        stmt_id = row[0]
        drug = row[2]  # 候选药物或方案
        old_page = row[3]  # 旧定位页

        if not stmt_id:
            continue

        # 读取对应页面的文本
        pages = drug_pages.get(drug, [])
        grade_text = []
        for pg in pages:
            txt_file = os.path.join(f026_cache, f'p{pg:04d}.txt')
            if os.path.exists(txt_file):
                with open(txt_file, encoding='utf-8') as f:
                    grade_text.append(f.read())

        # 提取关键信息
        full_text = '\n'.join(grade_text)

        review = {
            'stmt_id': stmt_id,
            'source': 'F026',
            'drug': drug,
            'old_page': old_page,
            'actual_pages': list(pages),
            'status': '已完成',
            'text_length': len(full_text),
            'contains_smd': 'SMD' in full_text,
            'contains_or': 'OR' in full_text,
            'certainty_low': 'LOW' in full_text or 'VERY LOW' in full_text,
            'original_excerpt': full_text[:500] if full_text else '',
        }
        reviews.append(review)

    # 保存审核结果
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(reviews, f, ensure_ascii=False, indent=2)

    print(f"审核完成，共{len(reviews)}条陈述")
    print(f"结果已保存到: {output_path}")

    return reviews

if __name__ == '__main__':
    template = sys.argv[1]
    text_cache = sys.argv[2]
    output = sys.argv[3]
    reviews = review_who_dep1_statements(template, text_cache, output)

    # 统计
    print(f"\n统计：")
    print(f"  含SMD: {sum(1 for r in reviews if r['contains_smd'])}")
    print(f"  含OR: {sum(1 for r in reviews if r['contains_or'])}")
    print(f"  证据等级LOW/VERY LOW: {sum(1 for r in reviews if r['certainty_low'])}")
