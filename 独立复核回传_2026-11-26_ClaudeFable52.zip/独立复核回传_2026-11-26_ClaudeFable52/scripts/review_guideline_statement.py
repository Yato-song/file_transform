#!/usr/bin/env python3
"""审核单条指南陈述：从原文核对药物、人群、推荐、等级、页码"""
import json, sys, os, re

def find_text_pages(source_id, keyword, text_cache_dir):
    """在文本缓存中搜索关键词，返回(页号, 片段)列表"""
    stem = None
    idx = json.load(open(os.path.join(text_cache_dir, '_index.json')))
    for k, v in idx.items():
        if k.startswith(source_id):
            stem = v['cache_dir']
            break
    if not stem:
        return []

    cache = os.path.join(text_cache_dir, stem)
    if not os.path.exists(cache):
        return []

    results = []
    files = sorted([f for f in os.listdir(cache) if f.endswith('.txt')])
    for fn in files:
        text = open(os.path.join(cache, fn), encoding='utf-8').read()
        if keyword.lower() in text.lower():
            # 提取关键词周围200字符
            pos = text.lower().find(keyword.lower())
            start = max(0, pos - 100)
            end = min(len(text), pos + len(keyword) + 100)
            snippet = text[start:end].replace('\n', ' ')
            page_num = int(re.search(r'\d+', fn).group()) if re.search(r'\d+', fn) else 0
            results.append((page_num, snippet))
    return results[:10]  # 最多返回10处

def review_statement(stmt_id, source_id, drug, old_page, text_cache):
    """审核单条陈述"""
    print(f"\n{'='*80}")
    print(f"陈述ID: {stmt_id}")
    print(f"来源: {source_id}")
    print(f"候选药物: {drug}")
    print(f"旧页码提示: {old_page}")
    print(f"{'='*80}")

    # 搜索药物名称
    matches = find_text_pages(source_id, drug, text_cache)
    if matches:
        print(f"\n在 {source_id} 中找到 {len(matches)} 处提及:")
        for pg, snip in matches[:5]:
            print(f"  p{pg:04d}: ...{snip[:150]}...")
    else:
        print(f"\n未在 {source_id} 文本缓存中找到 '{drug}'")

    return {
        'stmt_id': stmt_id,
        'status': '进行中',
        'matches_found': len(matches),
        'sample_pages': [pg for pg, _ in matches[:3]]
    }

if __name__ == '__main__':
    # 示范：审核前5条CANMAT 2023陈述
    template = json.load(open(sys.argv[1], encoding='utf-8'))
    statements = [t for t in template['tables'] if t['name'] == '指南陈述626'][0]
    text_cache = sys.argv[2]

    results = []
    for row in statements['rows'][:5]:
        stmt_id, src, drug, old_pg = row[0], row[1], row[2], row[3]
        if not stmt_id:
            continue
        r = review_statement(stmt_id, src, drug, old_pg, text_cache)
        results.append(r)

    print(f"\n\n{'='*80}")
    print(json.dumps(results, ensure_ascii=False, indent=2))
