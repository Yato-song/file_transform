#!/usr/bin/env python3
"""逐页抽取PDF文字 / 逐段逐表抽取DOCX，写入文本缓存，供检索定位。
抽取文字仅用于检索；判断须回到页图或原件。
用法: extract_text.py <源目录> <输出目录> [--ext pdf,docx]
输出: <输出目录>/<文件名stem>/p0001.txt ...（PDF物理页，从1起）
      <输出目录>/<stem>/docx.txt（DOCX：P段号 / T表号.R行号）
      <输出目录>/_index.json（sha256、页数、每页字符数）
"""
import sys, os, json, hashlib


def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def do_pdf(src, outdir):
    import fitz
    os.makedirs(outdir, exist_ok=True)
    doc = fitz.open(src)
    chars = []
    for i, page in enumerate(doc, start=1):
        t = page.get_text('text')
        with open(os.path.join(outdir, f'p{i:04d}.txt'), 'w', encoding='utf-8') as f:
            f.write(t)
        chars.append(len(t.strip()))
    return {'pages': len(chars), 'chars_per_page': chars}


def do_docx(src, outdir):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    os.makedirs(outdir, exist_ok=True)
    d = docx.Document(src)
    lines = []
    pi = ti = 0
    for el in d.element.body.iterchildren():
        tag = el.tag.split('}')[-1]
        if tag == 'p':
            pi += 1
            t = Paragraph(el, d).text.strip()
            if t:
                lines.append(f'[P{pi}] {t}')
        elif tag == 'tbl':
            ti += 1
            tb = Table(el, d)
            for ri, row in enumerate(tb.rows, start=1):
                cells = []
                prev = None
                for c in row.cells:
                    if c._tc is prev:
                        continue
                    prev = c._tc
                    cells.append(c.text.strip().replace('\n', ' / '))
                lines.append(f'[T{ti}.R{ri}] ' + ' | '.join(cells))
    with open(os.path.join(outdir, 'docx.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    return {'paragraphs': pi, 'tables': ti, 'chars': sum(len(x) for x in lines)}


def main():
    src_root, out_root = sys.argv[1], sys.argv[2]
    exts = {'pdf', 'docx'}
    if '--ext' in sys.argv:
        exts = set(sys.argv[sys.argv.index('--ext') + 1].split(','))
    index = {}
    idx_path = os.path.join(out_root, '_index.json')
    os.makedirs(out_root, exist_ok=True)
    if os.path.exists(idx_path):
        index = json.load(open(idx_path, encoding='utf-8'))
    for dp, _, fns in os.walk(src_root):
        for fn in sorted(fns):
            ext = fn.rsplit('.', 1)[-1].lower()
            if ext not in exts:
                continue
            src = os.path.join(dp, fn)
            rel = os.path.relpath(src, src_root)
            if rel in index:
                continue
            stem = rel.rsplit('.', 1)[0].replace(os.sep, '__')
            outdir = os.path.join(out_root, stem)
            try:
                info = do_pdf(src, outdir) if ext == 'pdf' else do_docx(src, outdir)
                info['status'] = 'ok'
            except Exception as e:  # 记录打不开的文件，不静默跳过
                info = {'status': 'error', 'error': repr(e)[:300]}
            info['sha256'] = sha256(src)
            info['cache_dir'] = stem
            index[rel] = info
            json.dump(index, open(idx_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('files indexed:', len(index))


if __name__ == '__main__':
    main()
