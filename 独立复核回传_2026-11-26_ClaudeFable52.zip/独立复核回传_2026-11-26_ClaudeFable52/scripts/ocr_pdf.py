#!/usr/bin/env python3
"""对扫描PDF逐页渲染并OCR（tesseract）。OCR文字仅助检索，判断须看页图。
用法: ocr_pdf.py <pdf> <输出目录> <语言如chi_sim+eng> [dpi=200] [并行数=6] [起页 止页]
输出: <输出目录>/p0001.txt ...；页图 <输出目录>/img/p0001.png（保留供目视核对）
"""
import sys, os, subprocess
from concurrent.futures import ThreadPoolExecutor


def main():
    pdf, out, lang = sys.argv[1], sys.argv[2], sys.argv[3]
    dpi = int(sys.argv[4]) if len(sys.argv) > 4 else 200
    workers = int(sys.argv[5]) if len(sys.argv) > 5 else 6
    import pymupdf
    doc = pymupdf.open(pdf)
    n = len(doc)
    a = int(sys.argv[6]) if len(sys.argv) > 6 else 1
    b = int(sys.argv[7]) if len(sys.argv) > 7 else n
    img_dir = os.path.join(out, 'img')
    os.makedirs(img_dir, exist_ok=True)

    todo = []
    for i in range(a, b + 1):
        txt = os.path.join(out, f'p{i:04d}.txt')
        if os.path.exists(txt) and os.path.getsize(txt) > 0:
            continue
        png = os.path.join(img_dir, f'p{i:04d}.png')
        if not os.path.exists(png):
            pix = doc[i - 1].get_pixmap(dpi=dpi, colorspace=pymupdf.csGRAY)
            pix.save(png)
        todo.append((png, txt[:-4]))

    def run(job):
        png, base = job
        r = subprocess.run(['tesseract', png, base, '-l', lang, '--psm', '3'],
                           capture_output=True, text=True)
        return r.returncode

    with ThreadPoolExecutor(workers) as ex:
        rc = list(ex.map(run, todo))
    print('pages', n, 'ocr_done', len(todo), 'failed', sum(1 for x in rc if x))


if __name__ == '__main__':
    main()
