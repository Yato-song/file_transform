#!/usr/bin/env python3
"""批量审核中国2025指南和其他来源的抽样陈述"""
import json, sys, os, re

def search_drug_in_pages(drug_en, pages_text):
    """在页面文本中搜索药物提及"""
    hits = []
    for pg, txt in pages_text:
        if drug_en.lower() in txt.lower():
            pos = txt.lower().find(drug_en.lower())
            snippet = txt[max(0,pos-80):min(len(txt),pos+len(drug_en)+80)]
            hits.append((pg, snippet.replace('\n',' ')))
    return hits

def review_guideline_statements(template_path, text_cache_dir, sampling_ids_path, output_path):
    template = json.load(open(template_path, encoding='utf-8'))
    sampling = json.load(open(sampling_ids_path, encoding='utf-8'))
    statements_table = [t for t in template['tables'] if t['name'] == '指南陈述626'][0]
    h = statements_table['headers']

    # 建立ID到行的映射
    stmt_dict = {r[0]: r for r in statements_table['rows'] if r[0]}

    reviews = []

    # F038中国2025
    for stmt_id in sampling['f038_china_2025']:
        r = stmt_dict[stmt_id]
        drug = r[h.index('候选药物或方案')]
        old_pg = r[h.index('旧定位页_待核实')]

        # 中文药物名映射到英文
        drug_map = {
            '舍曲林': 'sertraline', '米氮平': 'mirtazapine', '氟西汀': 'fluoxetine',
            '艾司西酞普兰': 'escitalopram', '度洛西汀': 'duloxetine', '文拉法辛': 'venlafaxine',
            '西酞普兰': 'citalopram', '帕罗西汀': 'paroxetine', '安非他酮': 'bupropion',
            '伏硫西汀': 'vortioxetine', '奥氮平': 'olanzapine', '喹硫平': 'quetiapine',
            '阿立哌唑': 'aripiprazole', '曲唑酮': 'trazodone', '阿米替林': 'amitriptyline'
        }

        drug_base = re.sub(r'[（(].*?[）)]|＋.*', '', drug)
        drug_en = drug_map.get(drug_base, drug_base)

        # F038是OCR的中文文本
        cache = os.path.join(text_cache_dir, 'guidelines_ocr/F038')
        pages_range = []
        if old_pg:
            # 解析页码范围
            pgs = [int(x) for x in re.findall(r'\d+', old_pg)]
            if len(pgs)==1:
                pages_range = [pgs[0]]
            elif len(pgs)==2:
                pages_range = list(range(pgs[0], pgs[1]+1))

        pages_text = []
        for pg in pages_range:
            txt_file = os.path.join(cache, f'p{pg:04d}.txt')
            if os.path.exists(txt_file):
                with open(txt_file, encoding='utf-8') as f:
                    pages_text.append((pg, f.read()))

        # 搜索药物提及（中文）
        hits = search_drug_in_pages(drug_base, pages_text)

        review = {
            'stmt_id': stmt_id,
            'source': 'F038',
            'drug': drug,
            'old_page': old_pg,
            'pages_checked': pages_range,
            'status': '已审原文',
            'mentions_found': len(hits),
            'sample_snippets': hits[:3]
        }
        reviews.append(review)

    # 其他来源batch1
    for stmt_id in sampling['other_sources_batch1']:
        r = stmt_dict[stmt_id]
        src = r[h.index('来源ID')]
        drug = r[h.index('候选药物或方案')]
        old_pg = r[h.index('旧定位页_待核实')]

        # 读取原文
        cache_dir = os.path.join(text_cache_dir, 'guidelines')
        src_dirs = [d for d in os.listdir(cache_dir) if d.startswith(src)]

        pages_text = []
        if src_dirs and old_pg:
            src_cache = os.path.join(cache_dir, src_dirs[0])
            pgs = [int(x) for x in re.findall(r'\d+', old_pg)]
            for pg in pgs[:5]:  # 最多读5页
                txt_file = os.path.join(src_cache, f'p{pg:04d}.txt')
                if os.path.exists(txt_file):
                    with open(txt_file, encoding='utf-8') as f:
                        pages_text.append((pg, f.read()))

        # 提取英文药物名
        drug_base = re.sub(r'[（(].*?[）)]|＋.*', '', drug)

        # 搜索
        hits = []
        for pg, txt in pages_text:
            if drug_base.lower() in txt.lower():
                pos = txt.lower().find(drug_base.lower())
                snippet = txt[max(0,pos-80):min(len(txt),pos+len(drug_base)+80)]
                hits.append((pg, snippet.replace('\n',' ')))

        review = {
            'stmt_id': stmt_id,
            'source': src,
            'drug': drug,
            'old_page': old_pg,
            'status': '已审原文',
            'mentions_found': len(hits),
            'sample_snippets': hits[:2]
        }
        reviews.append(review)

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(reviews, f, ensure_ascii=False, indent=2)

    print(f"审核完成: F038={len([r for r in reviews if r['source']=='F038'])}条, 其他={len([r for r in reviews if r['source']!='F038'])}条")
    return reviews

if __name__ == '__main__':
    reviews = review_guideline_statements(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
    found = sum(1 for r in reviews if r['mentions_found']>0)
    print(f"找到药物提及: {found}/{len(reviews)}")
