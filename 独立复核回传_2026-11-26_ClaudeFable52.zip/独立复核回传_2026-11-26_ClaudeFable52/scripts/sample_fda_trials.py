#!/usr/bin/env python3
"""审核FDA试验抽样：每个药物2-3个关键试验"""
import json, sys, os, collections

def review_fda_trials(template_path, fda_text_cache, output_path):
    template = json.load(open(template_path, encoding='utf-8'))
    fda_table = [t for t in template['tables'] if t['name'] == 'FDA源表候选235'][0]
    h = fda_table['headers']

    # 按药物分组
    by_drug = collections.defaultdict(list)
    for r in fda_table['rows']:
        if r[0]:  # 候选记录ID
            drug = r[h.index('药物')]
            by_drug[drug].append(r)

    print(f"FDA试验按药物分布: {len(by_drug)}个药物")

    # 每个药物抽2-3个：优先阳性试验、老年试验、共病试验
    sampled = []
    priority_keywords = ['老年', '阳性', '标签', '003-', 'D1448', 'PAR', 'HGIE']

    for drug, trials in by_drug.items():
        # 优先级排序
        scored = []
        for trial in trials[:20]:  # 限制每药最多看20条
            trial_name = trial[h.index('试验名称候选')]
            score = sum(1 for kw in priority_keywords if kw in trial_name)
            scored.append((score, trial))
        scored.sort(reverse=True, key=lambda x: x[0])

        # 取前2-3个
        for score, trial in scored[:3]:
            rec_id = trial[h.index('候选记录ID')]
            trial_name = trial[h.index('试验名称候选')]
            sampled.append({
                'record_id': rec_id,
                'drug': drug,
                'trial_name': trial_name,
                'status': '待审',
                'priority_score': score
            })

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(sampled, f, ensure_ascii=False, indent=2)

    print(f"抽样完成: {len(sampled)}个FDA试验")
    return sampled

if __name__ == '__main__':
    sampled = review_fda_trials(sys.argv[1], sys.argv[2], sys.argv[3])
    by_drug = collections.Counter(s['drug'] for s in sampled)
    print(f"按药物分布: {by_drug.most_common()}")
