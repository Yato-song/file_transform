#!/usr/bin/env python3
'''R8 step28: 补充验证(只读)。失败项原样输出到submission/validation_extra.json，不改任何决定。仅标准库。'''
import json, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
W = B + 'r8_work/'
P2 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase2_trial_extractions_235.json'
cw = json.load(open(W + 'submission/identity_crosswalk.json', encoding='utf-8'))['records']
cd = json.load(open(W + 'submission/candidate_disposition.json', encoding='utf-8'))['records']
cands = {r['候选记录ID']: r for r in json.load(open(P2, encoding='utf-8'))}
res = {}
def add(name, items):
    res[name] = {'count': len(items), 'items': items}
ver = [r for r in cw if r['mapping_status'] == 'verified']
cnt = collections.Counter(r['ft_id'] for r in cw)
add('FT行重复', [k for k, v in cnt.items() if v > 1])
ccnt = collections.Counter(r['candidate_id'] for r in cd)
add('候选处置行重复', [k for k, v in ccnt.items() if v > 1])
add('已核实FT无候选关联(漏关联)', [r['ft_id'] for r in ver if not r['candidate_ids']])
by_c = collections.defaultdict(list)
for r in cw:
    for c in r['candidate_ids']:
        by_c[c].append(r['ft_id'])
add('一个候选对应多个FT(一对多)', [{'candidate': c, 'fts': v} for c, v in by_c.items() if len(v) > 1])
add('一个FT对应多个候选', [{'ft': r['ft_id'], 'cands': r['candidate_ids']} for r in cw if len(r['candidate_ids']) > 1])
add('候选ID不存在', [{'ft': r['ft_id'], 'c': c} for r in cw for c in r['candidate_ids'] if c not in cands])
add('已核实但候选FDA判定为空(未匹配FDA判定)', [r['ft_id'] for r in ver if any(not cands[c].get('FDA判定') for c in r['candidate_ids'] if c in cands)])
add('纳入主设定但非参照臂=False', [r['ft_id'] for r in cw if r['main_scope'] == 'included' and r['is_reference_arm'] is not False])
add('纳入主设定但年龄设计为老年/儿少/未知', [r['ft_id'] for r in cw if r['main_scope'] == 'included' and r['age_scope'] in ('elderly_design', 'youth_design', 'unknown')])
add('参照臂未被排除', [r['ft_id'] for r in cw if r['is_reference_arm'] is True and r['main_scope'] != 'excluded'])
add('名称含参照臂但未标参照臂', [r['ft_id'] for r in ver if '参照臂' in r['original_trial_name'] and r['is_reference_arm'] is not True])
rg = collections.defaultdict(set)
for r in ver:
    rg[r['regimen_id']].add((r['standard_drug'], r['regimen_class'], r['is_reference_arm']))
add('同一方案ID下药物/方案类/参照臂不一致(方案合并)', [{'regimen_id': k, 'values': [list(x) for x in v]} for k, v in rg.items() if len(v) > 1])
add('喹硫平加药被写成单药', [r['ft_id'] for r in ver if r['original_drug'] == '喹硫平' and r['original_trial_name'] in ('D1448C00006', 'D1448C00007') and r['regimen_class'] != 'augmentation'])
add('HGIE/OFC混入普通单药方案', [r['ft_id'] for r in ver if 'HGIE' in r['original_trial_name'] and r['regimen_class'] != 'ofc'])
add('去甲文拉法辛错药', [r['ft_id'] for r in cw if r['ft_id'] in ('FT0035', 'FT0036', 'FT0038', 'FT0039', 'FT0040', 'FT0041', 'FT0042') and r.get('standard_drug') != '去甲文拉法辛'])
add('标签汇总行被核实为单项试验', [r['ft_id'] for r in ver if r['original_trial_name'].startswith('标签') and r['record_type'] == 'single_trial'])
par = collections.defaultdict(list)
for r in ver:
    if r['record_type'] == 'single_trial' and r['is_reference_arm'] is False:
        for a in r['application_ids']:
            for p in r['parent_trial_ids']:
                par[(a, p)].append(r['ft_id'])
add('同申报同母试验下多个单项非参照臂FT(可能重复计数)', [{'key': list(k), 'fts': v} for k, v in par.items() if len(v) > 1])
add('已核实FT缺依据', [r['ft_id'] for r in ver if not r['identity_basis']])
add('已核实FT缺original级依据(仅工作表线索)', [r['ft_id'] for r in ver if not any(b.get('basis_type') == 'original' for b in r['identity_basis'])])
add('未决FT缺类别或下一步', [r['ft_id'] for r in cw if r['mapping_status'] != 'verified' and not (r['unresolved_categories'] and r['next_action'])])
add('候选mapped但无反向FT', [c['candidate_id'] for c in cd if c['status'] == 'mapped' and not c['ft_ids']])
add('候选unresolved缺类别', [c['candidate_id'] for c in cd if c['status'] == 'unresolved' and not c.get('unresolved_category')])
res['summary'] = {'ft_total': len(cw), 'ft_verified': len(ver), 'candidate_total': len(cd), 'candidate_status': dict(collections.Counter(c['status'] for c in cd)), 'main_scope': dict(collections.Counter(r['main_scope'] for r in cw))}
json.dump(res, open(W + 'submission/validation_extra.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for k, v in res.items():
    if k == 'summary':
        print('summary', v)
    else:
        print(('FAIL ' if v['count'] else 'ok   ') + k, v['count'], str(v['items'][:6])[:240])
