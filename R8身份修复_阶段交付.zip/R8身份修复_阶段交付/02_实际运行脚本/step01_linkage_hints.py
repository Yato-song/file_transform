#!/usr/bin/env python3
"""R8 step01: 生成FT->候选的【线索】(非映射结论)。只用标准库。
线索类型: exact_drug_trial(药物+试验名完全相等) / refarm_parse(解析'母药 试验 的X参照臂')。
不使用子串匹配药物；字段缺失直接报错。"""
import json, re, sys, collections, hashlib
BASE = '/Users/dxm/work/jingya/FDAcheck/r8_materials/R8_身份修复任务/'
OUT = '/Users/dxm/work/jingya/FDAcheck/r8_work/checkpoints/linkage_hints.json'
P3 = BASE + '02_冻结输入/phase3_dimensions_3674_CORRECTED.json'
P2 = BASE + '02_冻结输入/phase2_trial_extractions_235.json'

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        h.update(f.read())
    return h.hexdigest()

def need(rec, keys, where):
    for k in keys:
        if k not in rec:
            sys.exit('字段不存在: %s in %s' % (k, where))

def main():
    dims = json.load(open(P3, encoding='utf-8'))
    cands = json.load(open(P2, encoding='utf-8'))
    for r in dims[:1]:
        need(r, ['模型记录ID', '药物', '试验名称候选', '证据文件及SHA'], 'phase3')
    for r in cands:
        need(r, ['候选记录ID', '药物', '试验名称候选', '来源工作表', '确认母试验ID'] if '确认母试验ID' in r else ['候选记录ID', '药物', '试验名称候选', '来源工作表'], 'phase2:' + r.get('候选记录ID', '?'))
    ft = collections.OrderedDict()
    for r in dims:
        ft.setdefault(r['模型记录ID'], r)
    key2c = collections.defaultdict(list)
    for c in cands:
        key2c[(c['药物'], c['试验名称候选'])].append(c['候选记录ID'])
    pat = re.compile(r'^(\S+)\s+(.+?)\s*的(\S+?)参照臂')
    hints = {}
    for k, v in ft.items():
        d, n = v['药物'], v['试验名称候选']
        h = {'ft_id': k, 'drug': d, 'trial_name': n, 'method': None, 'candidate_hints': [],
             'parent_hints': [], 'note': ''}
        ex = key2c.get((d, n), [])
        if ex:
            h['method'] = 'exact_drug_trial'; h['candidate_hints'] = ex
        else:
            m = pat.match(n)
            if m:
                pd, pt, ad = m.groups()
                h['method'] = 'refarm_parse'
                h['parent_hints'] = key2c.get((pd, pt), [])
                h['candidate_hints'] = key2c.get((ad, pt), [])
                if ad != d:
                    h['note'] = '名称内药物与药物字段不一致: %s vs %s' % (ad, d)
            else:
                h['method'] = 'none'
        hints[k] = h
    # 反向统计
    hit = collections.defaultdict(list)
    for k, h in hints.items():
        for c in h['candidate_hints']:
            hit[c].append(k)
    multi_ft = {c: v for c, v in hit.items() if len(v) > 1}
    unhit = [c['候选记录ID'] for c in cands if c['候选记录ID'] not in hit]
    # 候选按确认母试验ID分组: 共用母试验的候选
    mg = collections.defaultdict(list)
    for c in cands:
        m = c.get('确认母试验ID')
        if m:
            mg[m].append(c['候选记录ID'])
    shared = {m: v for m, v in mg.items() if len(v) > 1}
    # 未命中候选的分类线索(仅供人工): 来源工作表 + 是否有同母试验的已命中候选
    cmap = {c['候选记录ID']: c for c in cands}
    unhit_info = []
    for cid in unhit:
        c = cmap[cid]
        sib = [x for x in mg.get(c.get('确认母试验ID'), []) if x != cid and x in hit]
        unhit_info.append({'cid': cid, 'sheet': c['来源工作表'], 'drug': c['药物'], 'trial': c['试验名称候选'],
                           'mother': c.get('确认母试验ID'), 'sibling_hit': sib, 'judg': c.get('FDA判定')})
    res = {'inputs_sha256': {'phase3': sha(P3), 'phase2': sha(P2)},
           'method_counts': dict(collections.Counter(h['method'] for h in hints.values())),
           'multi_ft_per_candidate': multi_ft, 'shared_mother_ids': shared,
           'unhit_candidates': unhit_info, 'hints': hints}
    json.dump(res, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('method_counts', res['method_counts'])
    print('同一候选被多个FT线索命中:', multi_ft)
    print('共用同一确认母试验ID的候选组:', len(shared))
    for m, v in shared.items():
        print('  ', m, v)
    print('未被FT线索命中的候选:', len(unhit), '按工作表', dict(collections.Counter(u['sheet'] for u in unhit_info)))
    print('其中有同母试验已命中的兄弟候选:', sum(1 for u in unhit_info if u['sibling_hit']))
    for u in unhit_info:
        if u['sheet'] == '成人与老年试验':
            print('  成人/老年未命中', u['cid'], u['drug'], u['trial'], u['mother'], u['judg'], u['sibling_hit'])

if __name__ == '__main__':
    main()
