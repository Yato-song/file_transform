#!/usr/bin/env python3
'''R8 step10: 为未被已核实FT反向对应的候选生成处置(decisions/cand_batch01.json)。
规则: 儿少设计候选且无FT线索 -> outside_ft_scope；FYP0003与FAD0004同药同母试验101同文件 -> duplicate_source；
FYP0007-0009为成人数据复制在儿少表参照臂名下 -> unresolved(身份待核)；其余unresolved并写明原因类别。不强造映射。'''
import json, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
P2 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase2_trial_extractions_235.json'
H = json.load(open(B + 'r8_work/checkpoints/linkage_hints.json', encoding='utf-8'))['hints']
CW = json.load(open(B + 'r8_work/submission/identity_crosswalk.json', encoding='utf-8'))['records']
ft_status = {r['ft_id']: r['mapping_status'] for r in CW}
c = {r['候选记录ID']: r for r in json.load(open(P2, encoding='utf-8'))}
mapped = {x for r in CW for x in r['candidate_ids']}
hintft = collections.defaultdict(list)
for f, h in H.items():
    for x in h['candidate_hints']:
        hintft[x].append(f)
recs = []
for cid, k in c.items():
    if cid in mapped:
        continue
    hf = hintft.get(cid, [])
    sheet = k['来源工作表']
    cat = None
    if cid == 'FYP0003':
        assert c['FAD0004']['药物'] == k['药物'] and c['FAD0004']['确认母试验ID'] == k['确认母试验ID'] == '101'
        st, fts, why = 'duplicate_source', ['FT0003'], '儿少表内的成人数据行：药物、母试验101、出处文件与FAD0004相同(Study 1017/101线索)，按工作表字段判为重复来源；未目视原件。'
    elif cid in ('FYP0007', 'FYP0008', 'FYP0009'):
        st, fts, cat, why = 'unresolved', [], '身份待核', '成人氟西汀试验数据(母试验%s)被复制在儿少表的参照臂名称下，所属父试验应为儿少试验，复制关系未核。' % k['确认母试验ID']
    elif hf:
        st, fts, cat = 'unresolved', [], '尚未核完'
        why = '存在FT线索%s，但对应FT状态为%s，待FT核实后再定。' % (hf, [ft_status[f] for f in hf])
    elif sheet == '儿少试验' and str(k.get('年龄', '')) != 'None' and ('儿少' in str(k.get('人群'))):
        st, fts, why = 'outside_ft_scope', [], '儿少设计候选(人群=%s)；167个FT维度输入中无对应儿少FT线索，按工作表字段判为FT集合范围外；未目视原件。' % k.get('人群')
    else:
        st, fts, cat = 'unresolved', [], '尚未核完'
        why = '无精确FT线索(药物+试验名)；尚需确认是否确属FT维度输入范围外，或在FT中以其他名称出现。'
    r = {'candidate_id': cid, 'status': st, 'ft_ids': fts, 'reason': why}
    if cat:
        r['unresolved_category'] = cat
    recs.append(r)
json.dump({'batch': 'cand_batch01', 'records': recs}, open(B + 'r8_work/decisions/cand_batch01.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('写入', len(recs), dict(collections.Counter(r['status'] for r in recs)))
print('未决类别', dict(collections.Counter(r.get('unresolved_category') for r in recs if r['status'] == 'unresolved')))
