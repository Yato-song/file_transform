import json,glob,os,re
B='/Users/dxm/work/jingya/FDAcheck/r3_full_revision/'
BASE='/Users/dxm/work/jingya/FDAcheck/r8_materials/R8_身份修复任务/'
d=json.load(open(BASE+'02_冻结输入/phase3_dimensions_3674_CORRECTED.json',encoding='utf-8'))
ft={}
for r in d: ft.setdefault(r['模型记录ID'],r)
for k in ['FT0134','FT0164','FT0166','FT0165','FT0017','FT0146','FT0135','FT0085']:
    v=ft[k]; print(k,v['药物'],'|',v['试验名称候选'],'|',v['来源级别'],'|',(v['证据文件及SHA'] or '')[:50],'|',v['物理页与印刷页'],'|',str(v['原文短摘'])[:120])
print('=== 文本缓存检索(仅线索:缓存文本来自原PDF的机器抽取,非目视)')
pats={'D1448C00014':r'D1448C00014|Study\s*14\b','CCT004':r'CCT[- ]?004','mirt003023':r'003-?023','venl_elderly':r'elderly|geriatric|65 years'}
files=sorted(glob.glob(B+'_pdftext/*.json'))+sorted(glob.glob(B+'_ocrtext/*.json'))
hits={k:[] for k in ['D1448C00014','CCT004']}
for f in files:
    try: j=json.load(open(f,encoding='utf-8'))
    except Exception as e: print('ERR',f,e); continue
    for pg,tx in j.get('pages',{}).items():
        if not isinstance(tx,str): continue
        for k in hits:
            m=re.search(pats[k],tx)
            if m: hits[k].append((os.path.basename(os.path.dirname(f)),j.get('id') or os.path.basename(f),pg,tx[max(0,m.start()-80):m.end()+120].replace('\n',' ')))
for k,v in hits.items():
    print('---',k,'命中页数',len(v))
    seen=set()
    for x in v:
        if (x[1]) in seen and k=='D1448C00014' : continue
        seen.add(x[1]); print(x)
        if len(seen)>8: break
