#!/usr/bin/env python3
'''R8 step27: 由交叉表自动生成scope_ledger.json。计数单位=FT记录；药物按original_drug精确相等；不计算字母、缺口或患者比例。'''
import json, collections
W = '/Users/dxm/work/jingya/FDAcheck/r8_work/'
cw = json.load(open(W + 'submission/identity_crosswalk.json', encoding='utf-8'))['records']
T = ['舍曲林', '米氮平', '喹硫平', '氟西汀', '文拉法辛', '帕罗西汀']
g = collections.defaultdict(lambda: {'included': [], 'excluded': [], 'unresolved': []})
for r in cw:
    d = r['original_drug']
    if d not in T:
        continue
    rc = r['regimen_class'] if r['mapping_status'] == 'verified' else 'unknown'
    k = d + '|' + rc + ('|reference_arm' if r['is_reference_arm'] else '')
    g[k][r['main_scope']].append(r['ft_id'])
rows = []
for k in sorted(g):
    v = g[k]
    rows.append({'drug_regimen': k, 'candidate_set_ft': sorted(v['included'] + v['excluded'] + v['unresolved']),
                 'included': sorted(v['included']), 'excluded': sorted(v['excluded']), 'unresolved': sorted(v['unresolved']),
                 'counts': {s: len(v[s]) for s in v}})
out = {'counting_unit': 'FT记录(模型记录ID)，非独立试验数；同一母试验的多臂/多索引记录可能各占一行', 'source': 'submission/identity_crosswalk.json', 'note': '不含D18编码、字母、缺口或患者比例；unknown方案=身份未决。', 'rows': rows}
json.dump(out, open(W + 'submission/scope_ledger.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for r in rows:
    print(r['drug_regimen'], r['counts'])
