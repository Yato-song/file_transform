#!/usr/bin/env python3
'''R8 step12: 只读。查fdadrug_26/fdadrug_22/fdadrug_24/fdadrug_21的申报号依据(目录别名+缓存文本中的NDA号)。不写决定。'''
import json, re, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
base = B + 'r8_materials/R8_身份修复任务/'
cat = json.load(open(base + '04_原文目录/FDA原文与电子资料目录.json', encoding='utf-8'))
for key in ['fdadrug_26', 'fdadrug_22', 'fdadrug_24', 'fdadrug_21', 'fdadrug_27']:
    rows = [c for c in cat if key in c.get('original_name', '') or any(key in a for a in c.get('aliases', []))]
    print('==', key, '目录行数', len(rows))
    for c in rows[:3]:
        print('  ', c['id'], c.get('original_name'), '|', [u for u in c.get('urls', [])][:2], '|', [a for a in c.get('aliases', []) if 'NDA' in a or 'nda' in a][:2])
    for c in rows[:1]:
        for sub in ['_pdftext', '_ocrtext']:
            p = B + 'r3_full_revision/' + sub + '/' + c['id'] + '.json'
            try:
                j = json.load(open(p, encoding='utf-8'))
            except Exception:
                continue
            cnt = collections.Counter()
            for pg in sorted(j['pages'], key=int)[:15]:
                t = j['pages'][pg]
                if isinstance(t, str):
                    for m in re.finditer(r'(?:NDA|N\.?D\.?A\.?)\s*(?:No\.?|#)?\s*(\d{2}-?\d{3})', t, re.I):
                        cnt[m.group(1)] += 1
            print('   ', sub, '前15页NDA号计数', dict(cnt.most_common(5)))
