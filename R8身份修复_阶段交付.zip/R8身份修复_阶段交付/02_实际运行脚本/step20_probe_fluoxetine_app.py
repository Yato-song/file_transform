#!/usr/bin/env python3
'''R8 step20: 只读。在氟西汀相关缓存文本(fdadrug_22, Prozac Medr/Statr, FLX2003)中检索申报号字样，按页给出上下文。不写决定。'''
import json, re, os
B = '/Users/dxm/work/jingya/FDAcheck/'
base = B + 'r8_materials/R8_身份修复任务/'
cat = json.load(open(base + '04_原文目录/FDA原文与电子资料目录.json', encoding='utf-8'))
files = [c for c in cat if c['id'].startswith('FDA-') and re.search(r'fdadrug_22|Prozac|FLX2003', c.get('original_name', ''))]
pat = re.compile(r'(NDA|N\.D\.A\.|Application|Appl\.?)\s*(No\.?|Number|#)?\s*[:\-]?\s*(\d{2}[-,]?\d{3})|\b(18-936|21-235|20-974)\b', re.I)
for c in files:
    p = B + 'r3_full_revision/_pdftext/' + c['id'] + '.json'
    if not os.path.exists(p):
        print(c['id'], c['original_name'], '无缓存'); continue
    j = json.load(open(p, encoding='utf-8'))
    hits = []
    for pg in sorted(j['pages'], key=int):
        t = j['pages'][pg]
        if isinstance(t, str):
            for m in pat.finditer(t):
                hits.append((int(pg), t[max(0, m.start() - 50):m.end() + 60].replace('\n', ' ')))
    print('==', c['id'], c['original_name'], 'n_pages', j.get('n_pages'), '命中', len(hits))
    for h in hits[:4]:
        print('   p', h[0], '|', h[1])
