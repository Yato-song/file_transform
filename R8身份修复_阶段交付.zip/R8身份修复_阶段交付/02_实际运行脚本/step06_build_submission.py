#!/usr/bin/env python3
'''R8 step06: 由模板 + 线索 + 人工决定文件(decisions/*.json)生成交叉表与候选处置。
无决定的FT保持unresolved，线索只写入linkage_hint字段，不进入candidate_ids。仅标准库。'''
import json, glob, os, sys, collections
W = '/Users/dxm/work/jingya/FDAcheck/r8_work/'
T = '/Users/dxm/work/jingya/FDAcheck/r8_materials/R8_身份修复任务/05_回传起始模板/'
OUT = W + 'submission/'

def load(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)

def load_decisions(pattern, key):
    d = {}
    for p in sorted(glob.glob(W + 'decisions/' + pattern)):
        for r in load(p)['records']:
            if key not in r:
                sys.exit('决定缺少字段 %s: %s' % (key, p))
            if r[key] in d:
                sys.exit('重复决定: %s in %s' % (r[key], p))
            d[r[key]] = dict(r, _source_file=os.path.basename(p))
    return d

def main():
    os.makedirs(OUT, exist_ok=True)
    cw = load(T + 'identity_crosswalk.json')
    cd = load(T + 'candidate_disposition.json')
    hints = load(W + 'checkpoints/linkage_hints.json')['hints']
    fdec = load_decisions('ft_*.json', 'ft_id')
    cdec = load_decisions('cand_*.json', 'candidate_id')
    unknown = [k for k in fdec if k not in hints]
    if unknown:
        sys.exit('决定中的FT不存在: %s' % unknown)
    rev = collections.defaultdict(list)
    for r in cw['records']:
        ft = r['ft_id']
        h = hints[ft]
        r['linkage_hint'] = {'method': h['method'], 'candidate_hints': h['candidate_hints'], 'parent_hints': h['parent_hints'], 'note': h['note'], 'status': '仅线索，未核实'}
        if ft in fdec:
            for k, v in fdec[ft].items():
                if k != '_source_file':
                    r[k] = v
            r['decision_source'] = fdec[ft]['_source_file']
            for c in r.get('candidate_ids', []):
                rev[c].append(ft)
    cw['note'] = 'R8阶段交叉表：verified仅表示本轮作者核对，待接收方验收；unresolved保留未决。'
    for r in cd['records']:
        cid = r['candidate_id']
        if cid in cdec:
            for k, v in cdec[cid].items():
                if k != '_source_file':
                    r[k] = v
        elif rev.get(cid):
            r['status'] = 'mapped'
            r['ft_ids'] = sorted(rev[cid])
            r['reason'] = '由已核实FT的交叉表反向对应'
        else:
            hit = [f for f, h in hints.items() if cid in h['candidate_hints']]
            r['status'] = 'unresolved'
            r['ft_ids'] = []
            r['reason'] = '尚未核对；线索FT: %s' % (hit if hit else '无精确线索')
    json.dump(cw, open(OUT + 'identity_crosswalk.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    json.dump(cd, open(OUT + 'candidate_disposition.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('FT决定数', len(fdec), '候选决定数', len(cdec))
    print('FT状态', dict(collections.Counter(r['mapping_status'] for r in cw['records'])))
    print('候选状态', dict(collections.Counter(r['status'] for r in cd['records'])))

if __name__ == '__main__':
    main()
