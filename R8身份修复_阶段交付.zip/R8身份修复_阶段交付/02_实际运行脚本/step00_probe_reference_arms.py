import json,re,collections
base='/Users/dxm/work/jingya/FDAcheck/r8_materials/R8_身份修复任务/'
d=json.load(open(base+'02_冻结输入/phase3_dimensions_3674_CORRECTED.json',encoding='utf-8'))
t=json.load(open(base+'02_冻结输入/phase2_trial_extractions_235.json',encoding='utf-8'))
ft={}
for r in d: ft.setdefault(r['模型记录ID'],r)
idx=collections.defaultdict(list)
for r in t: idx[(r['药物'],r['试验名称候选'])].append(r['候选记录ID'])
pat=re.compile(r'^(\S+)\s+(.+?)\s*的(\S+?)参照臂')
out=[]
for k,v in sorted(ft.items()):
    if idx.get((v['药物'],v['试验名称候选'])): continue
    nm=v['试验名称候选']; m=pat.match(nm)
    if not m:
        out.append((k,v['药物'],nm,'NOPARSE')); continue
    pd,pt,ad=m.groups()
    parent=idx.get((pd,pt),[])
    arm_fref=[r['候选记录ID'] for r in t if r['药物']==ad and r['试验名称候选']==pt]
    arm_by_mother=[r['候选记录ID'] for r in t if r['药物']==ad and nm.replace(' ','') in str(r.get('确认母试验ID')).replace(' ','')]
    out.append((k,v['药物'],pd,pt,'父试验候选',parent,'参照臂候选(药+试验名)',arm_fref,'按母试验字段',arm_by_mother,'证据文件',(v.get('证据文件及SHA') or '')[:40]))
for o in out: print(o)
print('--- 其他线索(仅子串提示，不是映射)')
for key in ['D1448C00014','D1448C00005','CCT','老年入组','FDA项目汇总']:
    print(key,[(r['候选记录ID'],r['药物'],r['试验名称候选'],r.get('方案候选'),r.get('人群')) for r in t if key in str(r['试验名称候选'])])
