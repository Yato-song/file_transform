#!/usr/bin/env python3
'''R8 step11: 只读诊断84个未决候选。不写决定文件。试验名出现在FT名称中仅作线索。'''
import json, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
P2 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase2_trial_extractions_235.json'
cand = {r['候选记录ID']: r for r in json.load(open(P2, encoding='utf-8'))}
disp = json.load(open(B + 'r8_work/submission/candidate_disposition.json', encoding='utf-8'))['records']
cw = json.load(open(B + 'r8_work/submission/identity_crosswalk.json', encoding='utf-8'))['records']
H = json.load(open(B + 'r8_work/checkpoints/linkage_hints.json', encoding='utf-8'))['hints']
hint_ft = collections.defaultdict(list)
for f, h in H.items():
    for x in h['candidate_hints']:
        hint_ft[x].append(f)
out = []
groups = collections.defaultdict(list)
for d in disp:
    if d['status'] != 'unresolved':
        continue
    cid = d['candidate_id']; k = cand[cid]
    tn = str(k['试验名称候选'])
    name_hits = [r['ft_id'] for r in cw if len(tn) >= 3 and tn in r['original_trial_name'] and r['original_drug'] != k['药物']]
    hf = hint_ft.get(cid, [])
    ftst = {f: next(r['mapping_status'] for r in cw if r['ft_id'] == f) for f in hf}
    grp = 'FT线索存在但FT未核实' if hf else ('试验名出现在他药FT名称中(可能为参照臂/同试验)' if name_hits else '无任何FT线索')
    row = {'cid': cid, 'group': grp, 'drug': k['药物'], 'trial': tn, 'type': k.get('研究类型'), 'judg': str(k.get('FDA判定'))[:30], 'sheet': k['来源工作表'], 'hint_ft': ftst, 'name_hits_other_drug': name_hits, 'cat': d.get('unresolved_category')}
    out.append(row); groups[grp].append(row)
json.dump(out, open(B + 'r8_work/checkpoints/step11_unresolved_diagnosis.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
for g, v in groups.items():
    print('##', g, len(v))
    for r in v:
        print('  ', r['cid'], r['drug'], r['trial'][:28], '|', r['type'], '|', r['judg'], '|', r['hint_ft'] or r['name_hits_other_drug'], '|', r['sheet'])
