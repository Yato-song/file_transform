#!/usr/bin/env python3
'''R8 step17: 只读。对每个申报号，列出文件名含该号的全部文件，并给出各候选(出处字段)实际引用的文件名，核对申报号与来源文件是否一致。不写决定。'''
import json, re, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
base = B + 'r8_materials/R8_身份修复任务/'
cat = json.load(open(base + '04_原文目录/FDA原文与电子资料目录.json', encoding='utf-8'))
cw = json.load(open(B + 'r8_work/submission/identity_crosswalk.json', encoding='utf-8'))['records']
cands = {r['候选记录ID']: r for r in json.load(open(base + '02_冻结输入/phase2_trial_extractions_235.json', encoding='utf-8'))}
for key, nda in [('021992', 'NDA021992'), ('204447', 'NDA204447'), ('021427', 'NDA021427'), ('21-323', 'NDA021323'), ('020699', 'NDA020699'), ('20-936', 'NDA020936')]:
    names = sorted({c.get('original_name', '') for c in cat if c['id'].startswith('FDA-') and key in c.get('original_name', '')})
    print('==', nda, '文件名含号的文件', len(names))
    for n in names[:10]:
        print('    ', n[:90])
    used = collections.Counter()
    for r in cw:
        if r['mapping_status'] == 'verified' and nda in r['application_ids']:
            for c in r['candidate_ids']:
                m = re.findall(r'([\w\-\. ]+?\.pdf)', str(cands[c].get('出处及物理页')))
                used[m[0].strip() if m else '无pdf文件名'] += 1
    print('   候选出处实际引用的文件:', dict(used.most_common(6)))
