#!/usr/bin/env python3
'''R8 step24: 只读。审计未决清单: (1)verified但main_scope=unresolved的FT; (2)身份未决FT按类别与原因; (3)未决候选分组。不写决定。'''
import json, collections
B = '/Users/dxm/work/jingya/FDAcheck/r8_work/'
cw = json.load(open(B + 'submission/identity_crosswalk.json', encoding='utf-8'))['records']
cd = json.load(open(B + 'submission/candidate_disposition.json', encoding='utf-8'))['records']
m = {r['ft_id']: r for r in cw}
print('== (1) 身份已核实但范围未决')
for r in cw:
    if r['mapping_status'] == 'verified' and r['main_scope'] == 'unresolved':
        print(' ', r['ft_id'], r['original_drug'], r['original_trial_name'], '|', r['regimen_class'], '|', r['unresolved_categories'], '|', r['scope_reason'][:60])
print('== (2) 身份未决FT(按类别)')
grp = collections.defaultdict(list)
for r in cw:
    if r['mapping_status'] != 'verified':
        grp[tuple(r['unresolved_categories'])].append(r['ft_id'] + ':' + r['original_trial_name'][:22])
for k, v in grp.items():
    print(' ', k, len(v))
    for x in v:
        print('     ', x)
print('== (3) 未决候选分组')
g2 = collections.defaultdict(list)
for d in cd:
    if d['status'] == 'unresolved':
        g2[d.get('unresolved_category', '无类别')].append(d['candidate_id'])
for k, v in g2.items():
    print(' ', k, len(v), v[:12])
print('未决候选无类别字段数:', sum(1 for d in cd if d['status'] == 'unresolved' and not d.get('unresolved_category')))
