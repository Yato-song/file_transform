#!/usr/bin/env python3
'''R8 step15: 只读。按三类给step08 APP_MAP中每个申报号定级: page_evidence(缓存文本内含该号)/filename_only/none。
修正step14逻辑: 号码统一去连字符与前导0比较; 扫描全部匹配文件(不截前6个); 同时扫描描述性写法 NDA 20-031 / 20,699 / NDA 21-323。'''
import json, re, os, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
base = B + 'r8_materials/R8_身份修复任务/'
cat = json.load(open(base + '04_原文目录/FDA原文与电子资料目录.json', encoding='utf-8'))
def find_ids(sub):
    return [(c['id'], c.get('original_name', '')) for c in cat if c['id'].startswith('FDA-') and (sub in c.get('original_name', '') or any(sub in a for a in c.get('aliases', [])))]
def norm(s):
    return re.sub(r'[^0-9]', '', s).lstrip('0')
pat = re.compile(r'(?:NDA|N\.D\.A\.|Application)\s*(?:No\.?|Number|#)?\s*[:\-]?\s*(\d{2}[-,]?\d{3})', re.I)
cache = {}
def scan(fid):
    if fid in cache: return cache[fid]
    out = collections.defaultdict(list)
    p = B + 'r3_full_revision/_pdftext/' + fid + '.json'
    if os.path.exists(p):
        j = json.load(open(p, encoding='utf-8'))
        for pg in sorted(j['pages'], key=int):
            t = j['pages'][pg]
            if isinstance(t, str):
                for m in pat.finditer(t):
                    out[norm(m.group(1))].append(int(pg))
    cache[fid] = out
    return out
APP_MAP = [('fdadrug_27', 'NDA019839'), ('fdadrug_22', 'NDA018936'), ('fdadrug_24', 'NDA020151'), ('fdadrug_21', 'NDA020358'), ('020415', 'NDA020415'), ('022047', 'NDA022047'), ('021992', 'NDA021992'), ('020699', 'NDA020699'), ('021520', 'NDA021520'), ('204447', 'NDA204447'), ('021427', 'NDA021427'), ('021436', 'NDA021436'), ('018644', 'NDA018644'), ('20-936', 'NDA020936'), ('020822', 'NDA020822'), ('21-323', 'NDA021323'), ('022411', 'NDA022411'), ('PAR_SBA', 'NDA020031')]
rows = []
for key, nda in APP_MAP:
    n = norm(nda)
    ids = find_ids(key)
    page_hit = []
    for fid, nm in ids:
        o = scan(fid)
        if n in o:
            page_hit.append((fid, o[n][:3]))
    fname = any(n in norm(nm) for _, nm in ids)
    tier = 'page_evidence' if page_hit else ('filename_only' if fname else 'none')
    rows.append({'key': key, 'nda': nda, 'n_files': len(ids), 'tier': tier, 'page_hits': page_hit[:3]})
    print(key.ljust(11), nda, 'files', len(ids), tier, page_hit[:2])
print(dict(collections.Counter(r['tier'] for r in rows)))
json.dump(rows, open(B + 'r8_work/checkpoints/step15_app_map_tiers.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
