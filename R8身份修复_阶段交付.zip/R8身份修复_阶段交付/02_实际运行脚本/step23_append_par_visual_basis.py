#!/usr/bin/env python3
'''R8 step23: 为申报号NDA020031的已核实FT追加本轮目视原件依据(fdadrug_26 物理1/32/33页)。幂等，写revision_trace。'''
import json, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
S = B + 'r8_work/submission/'
PID = 'par_visual_01'
B1 = {'basis_type': 'original', 'source': 'e4f1c139b27f_PAR_SBA.pdf(fdadrug_26)', 'locator': '物理1页', 'excerpt': 'STATISTICAL REVIEW AND EVALUATION; NDA#: 20-031; Applicant: SmithKline Beecham; Drug: Paxil (paroxetine hydrochloride); PAR 01-001 single center, double blind, placebo controlled. 本轮目视渲染页；仅证明文件所属申报，单个试验的设计以候选出处字段为准，未逐试验目视。'}
B2 = {'basis_type': 'original', 'source': 'e4f1c139b27f_PAR_SBA.pdf(fdadrug_26)', 'locator': '物理32-33页(印刷11-12)', 'excerpt': 'PAR 03 series comprises six trials with identical protocols comparing paroxetine to imipramine and placebo; six week single center outpatient trials; inclusion: minimum age of 18 years. 本轮目视；本轮不涉及排除标准的D18编码。'}
cw = json.load(open(S + 'identity_crosswalk.json', encoding='utf-8'))
n = collections.Counter()
for r in cw['records']:
    if r['mapping_status'] != 'verified' or 'NDA020031' not in r['application_ids']:
        continue
    tr = r.setdefault('revision_trace', [])
    if any(t.get('patch_id') == PID for t in tr):
        n['skip'] += 1
        continue
    add = [B1] + ([B2] if r['original_trial_name'].startswith('PAR 03-') else [])
    r['identity_basis'].extend(add)
    tr.append({'patch_id': PID, 'action': 'append_original_basis', 'added_basis': add})
    n['added'] += 1
json.dump(cw, open(S + 'identity_crosswalk.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('结果', dict(n), 'NDA020031已核实FT', [r['ft_id'] for r in cw['records'] if 'NDA020031' in r['application_ids']])
