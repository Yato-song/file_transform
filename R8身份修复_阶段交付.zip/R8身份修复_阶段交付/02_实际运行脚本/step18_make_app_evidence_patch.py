#!/usr/bin/env python3
'''R8 step18: 生成申报号依据补丁(patches/app_evidence_patch.json)。不修改交叉表本身；由构建脚本的后置步骤应用，并写入revision_trace。
依据来源: step15_app_map_tiers.json(页内/仅文件名/无依据三级) 与 step17 对出处文件名的核对。仅标准库。'''
import json, os, collections
B = '/Users/dxm/work/jingya/FDAcheck/r8_work/'
cw = json.load(open(B + 'submission/identity_crosswalk.json', encoding='utf-8'))['records']
tiers = {r['nda']: r['tier'] for r in json.load(open(B + 'checkpoints/step15_app_map_tiers.json', encoding='utf-8'))}
FILENAME_ONLY_NOTE = '申报号仅来自来源文件名，缓存文本页内未读到该号，未目视核对。'
WEAK_NOTE = '候选出处仅写"P2.pdf"，无法确定具体来源文件；申报号NDA020936仅为文件名线索(20-936_Paxil_medr_P2.pdf)，页内未核。'
NONE_WHY = '申报号NDA018936来自step08固定表，fdadrug_22文件名与缓存文本均无该号或任何NDA号，无依据，不得作为已核实身份。'
patch = []
for r in cw:
    ft = r['ft_id']
    if r['mapping_status'] != 'verified':
        continue
    for a in r['application_ids']:
        t = tiers.get(a, 'none')
        if a == 'NDA018936' or t == 'none':
            patch.append({'ft_id': ft, 'action': 'downgrade_to_unresolved', 'old': {'mapping_status': r['mapping_status'], 'application_ids': r['application_ids'], 'main_scope': r['main_scope']}, 'reason': NONE_WHY, 'category': '尚未核完', 'next_action': '在氟西汀审评文件(fdadrug_22及Prozac/FLX2003系列)内定位申报号页内依据，再恢复核实。'})
            break
        if a == 'NDA020936':
            patch.append({'ft_id': ft, 'action': 'append_basis_note', 'basis': {'basis_type': 'working_table', 'source': 'step15/step17核对', 'locator': '候选出处"P2.pdf"', 'excerpt': WEAK_NOTE}})
            break
        if t == 'filename_only':
            patch.append({'ft_id': ft, 'action': 'append_basis_note', 'basis': {'basis_type': 'working_table', 'source': 'step15核对', 'locator': '来源文件名含申报号', 'excerpt': FILENAME_ONLY_NOTE}})
            break
os.makedirs(B + 'patches', exist_ok=True)
json.dump({'patch_id': 'app_evidence_patch_01', 'basis': 'step15/step17 只读核对', 'records': patch}, open(B + 'patches/app_evidence_patch.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('补丁条数', len(patch), dict(collections.Counter(p['action'] for p in patch)))
print('降级FT', [p['ft_id'] for p in patch if p['action'] == 'downgrade_to_unresolved'])
