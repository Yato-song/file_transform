import Foundation
import PDFKit
import AppKit

// 用法: render_pdf_page <pdf路径> <物理页码(从1开始)> <输出png路径> [缩放倍数]
let args = CommandLine.arguments
guard args.count >= 4 else {
    FileHandle.standardError.write("usage: render_pdf_page <pdf> <page(1-based)> <out.png> [scale]\n".data(using: .utf8)!)
    exit(2)
}
let url = URL(fileURLWithPath: args[1])
guard let doc = PDFDocument(url: url) else {
    FileHandle.standardError.write("cannot open pdf\n".data(using: .utf8)!)
    exit(3)
}
let pageNo = Int(args[2]) ?? 0
let scale = args.count >= 5 ? (Double(args[4]) ?? 1.6) : 1.6
guard pageNo >= 1, pageNo <= doc.pageCount, let page = doc.page(at: pageNo - 1) else {
    FileHandle.standardError.write("page out of range (pageCount=\(doc.pageCount))\n".data(using: .utf8)!)
    exit(4)
}
let box = page.bounds(for: .mediaBox)
let size = NSSize(width: box.width * scale, height: box.height * scale)
let img = page.thumbnail(of: size, for: .mediaBox)
guard let tiff = img.tiffRepresentation,
      let rep = NSBitmapImageRep(data: tiff),
      let png = rep.representation(using: .png, properties: [:]) else {
    FileHandle.standardError.write("render failed\n".data(using: .utf8)!)
    exit(5)
}
try png.write(to: URL(fileURLWithPath: args[3]))
print("OK pages=\(doc.pageCount) page=\(pageNo) out=\(args[3]) size=\(Int(size.width))x\(Int(size.height))")
