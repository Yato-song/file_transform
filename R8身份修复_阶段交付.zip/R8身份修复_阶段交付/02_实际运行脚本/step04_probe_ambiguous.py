import json,glob,os,re
BASE='/Users/dxm/work/jingya/FDAcheck/r8_materials/R8_身份修复任务/'
B='/Users/dxm/work/jingya/FDAcheck/r3_full_revision/'
t=json.load(open(BASE+'02_冻结输入/phase2_trial_extractions_235.json',encoding='utf-8'))
cat=json.load(open(BASE+'04_原文目录/FDA原文与电子资料目录.json',encoding='utf-8'))
m={r['候选记录ID']:r for r in t}
print('=== 候选完整字段(截断200字)')
for cid in ['FAD0021','FAD0125','FAD0172','FYP0003','FYP0007','FYP0009','FAD0030','FAD0009']:
    print('---',cid)
    for k,v in m[cid].items():
        if k in ('证据块','维度代码'): print('  ',k,'<len',len(v) if v else 0,'>'); continue
        print('  ',k,':',str(v)[:200].replace('\n',' '))
print('=== 全文本字段检索 FT0134线索(老年入组/项目汇总)与00014')
for r in t:
    s=json.dumps(r,ensure_ascii=False)
    if re.search(r'00014|项目汇总|老年入组|Study 14',s): print('候选命中',r['候选记录ID'],r['药物'],r['试验名称候选'])
for c in cat:
    s=json.dumps(c,ensure_ascii=False)
    if re.search(r'00014|TGA|AusPAR|项目汇总',s): print('目录命中',c['id'],c.get('original_name'),c.get('archived_type'))
print('=== 米氮平文件 9f5adbd403bb 第302/303页含003-023的文本(缓存,非目视)')
j=json.load(open(B+'_pdftext/FDA-9f5adbd403bb.json',encoding='utf-8'))
for pg in ['302','303','69','80']:
    tx=j['pages'].get(pg,'')
    for mm in re.finditer(r'003-?023|elderly|geriatric|55 years|Trazodone',tx):
        print('p',pg,'|',tx[max(0,mm.start()-120):mm.end()+200].replace('\n',' ')); break
    else: print('p',pg,'无命中, 字符数',len(tx))
