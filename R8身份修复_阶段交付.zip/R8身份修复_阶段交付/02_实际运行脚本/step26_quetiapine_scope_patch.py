#!/usr/bin/env python3
'''R8 step26: 依据本轮目视的NDA 22-047审评页(物理143-144)与D1448C00006/00007摘要首页，更新喹硫平加药FT范围。
规则来源: 既定编码定义[0]主分析使用各药自身申报试验，含明确的自身联合方案。FT0019/FT0020 -> included；方案身份仍与单药分开。幂等。'''
import json, collections
B = '/Users/dxm/work/jingya/FDAcheck/r8_work/'
S = B + 'submission/'
PID = 'quet_scope_01'
BASIS = [
 {'basis_type': 'original', 'source': 'dbae50cc0c21_022047Orig1s011.pdf', 'locator': '物理143-144页(印刷11-12)', 'excerpt': 'Clinical Review NDA 22-047 quetiapine XR; Studies 1,2,3,4,6,7 key inclusion: aged 18 to 65 years inclusive, DSM-IV MDD confirmed by MINI; adjunct Studies 6 and 7: quetiapine XR or placebo randomly assigned to patients treated with an approved antidepressant with HAM-D >=20. 本轮目视渲染页；不涉及D18编码。'},
 {'basis_type': 'original', 'source': 'quetiapine00006/00007 synopsis.pdf', 'locator': '各摘要物理1页', 'excerpt': 'D1448C00006 (Pearl) and D1448C00007 (Onyx): multicenter double-blind randomized placebo-controlled phase III of quetiapine XR in combination with an antidepressant in MDD with inadequate response to an antidepressant. 本轮目视渲染页。'}]
cw = json.load(open(S + 'identity_crosswalk.json', encoding='utf-8'))
n = collections.Counter()
for r in cw['records']:
    ft = r['ft_id']
    if ft not in ('FT0019', 'FT0020'):
        continue
    tr = r.setdefault('revision_trace', [])
    if any(t.get('patch_id') == PID for t in tr):
        n['skip'] += 1
        continue
    old = {k: r[k] for k in ['main_scope', 'scope_reason', 'unresolved_categories', 'next_action']}
    r['main_scope'] = 'included'
    r['unresolved_categories'] = []
    r['scope_reason'] = '自身申报(NDA 22-047)、成人设计(18-65岁)、自身联合方案(喹硫平XR加用于抗抑郁药)；按既定主设定纳入，方案身份与单药分开。范围状态不涉及疗效或D18编码。'
    r['next_action'] = '待接收方验收'
    r['identity_basis'].extend(BASIS)
    tr.append({'patch_id': PID, 'action': 'scope_update', 'old': old, 'new_scope': 'included', 'added_basis': BASIS})
    n[ft] += 1
json.dump(cw, open(S + 'identity_crosswalk.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('结果', dict(n))
