#!/usr/bin/env python3
'''R8 step25: 依据本轮目视的NDA 21436原件页(医学审评物理143-145、统计审评物理6)，更新阿立哌唑加药FT的范围状态。
规则来源: 既定编码定义[0] 主分析使用各药自身申报试验，含明确的自身联合方案。
FT0061/FT0062 -> included(自身申报成人设计加药，方案身份仍与单药分开)；FT0165 -> 保持unresolved(ongoing，无该试验自己的入排页)。
幂等: 以patch_id写入revision_trace。喹硫平加药与HGIE/OFC不在此补丁内。'''
import json, collections
B = '/Users/dxm/work/jingya/FDAcheck/r8_work/'
S = B + 'submission/'
PID = 'ari_scope_01'
BASIS = [
 {'basis_type': 'original', 'source': '961f8849bf9e_021436s018_MedR.pdf', 'locator': '物理143-145页(印刷143-145)', 'excerpt': 'NDA 21436 N018 Abilify; generally healthy adult (18-65 years old) outpatient; MDD DSM-IV-TR; HAMD-17>=18 at baseline; Phase C entry: must be 18-65 years old; aripiprazole plus ADT vs placebo plus ADT, ADT dose unchanged from Phase B. 本轮目视渲染页；不涉及D18编码。'},
 {'basis_type': 'original', 'source': 'f9227a615d2d_021436s018_StatR.pdf', 'locator': '物理6页(印刷5/22)', 'excerpt': 'sNDA 21436 (SN 018) Abilify; 3 placebo-controlled studies of identical design; CN138139 and CN138163 completed, CN138165 ongoing; adjunctive to 1 of 5 ADTs (Phase B 8-week single-blind placebo+ADT; Phase C 6-week randomization). 本轮目视渲染页。'}]
cw = json.load(open(S + 'identity_crosswalk.json', encoding='utf-8'))
n = collections.Counter()
for r in cw['records']:
    ft = r['ft_id']
    if ft not in ('FT0061', 'FT0062', 'FT0165'):
        continue
    tr = r.setdefault('revision_trace', [])
    if any(t.get('patch_id') == PID for t in tr):
        n['skip'] += 1
        continue
    old = {k: r[k] for k in ['main_scope', 'scope_reason', 'unresolved_categories', 'next_action', 'age_scope']}
    if ft in ('FT0061', 'FT0062'):
        r['main_scope'] = 'included'
        r['unresolved_categories'] = []
        r['scope_reason'] = '自身申报(NDA 21436)、成人设计(18-65岁)、自身联合方案(阿立哌唑加用于ADT)；按既定主设定纳入，方案身份与单药分开。范围状态不涉及疗效或D18编码。'
        r['next_action'] = '待接收方验收'
        r['identity_basis'].extend(BASIS)
    else:
        r['main_scope'] = 'unresolved'
        r['unresolved_categories'] = ['尚未核完']
        r['scope_reason'] = '申报与方案身份已核实；原件写明CN138165仍在进行(ongoing)，设计相同仅为概述，无该试验自己的入排页，年龄与设计不能沿用概述直接定。'
        r['next_action'] = '查找CN138165自己的方案或后续审评页，确认入排与年龄后再定范围。'
        r['identity_basis'].append(BASIS[1])
    tr.append({'patch_id': PID, 'action': 'scope_update', 'old': old, 'new_scope': r['main_scope'], 'added_basis': BASIS if ft != 'FT0165' else [BASIS[1]]})
    n[ft] += 1
json.dump(cw, open(S + 'identity_crosswalk.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('结果', dict(n))
