import json, re, collections
B='/Users/dxm/work/jingya/FDAcheck/'
cw=json.load(open(B+'r8_work/submission/identity_crosswalk.json',encoding='utf-8'))['records']
d=json.load(open(B+'r8_materials/R8_身份修复任务/02_冻结输入/phase3_dimensions_3674_CORRECTED.json',encoding='utf-8'))
src={}
for r in d: src.setdefault(r['模型记录ID'],r)
issues=collections.defaultdict(list)
pm=collections.defaultdict(list)
for r in cw:
    ft=r['ft_id']; n=r['original_trial_name']
    if r['mapping_status']!='verified': continue
    if '参照臂' in n and r['is_reference_arm'] is not True: issues['名称含参照臂但未标参照臂'].append((ft,n,r['main_scope']))
    if r['age_scope']=='elderly_design' and r['is_reference_arm'] is False and r['main_scope']!='excluded': issues['老年设计却未排除'].append(ft)
    if re.search(r'(层）|层\)|\d[ab]$)',n): issues['分层或a/b子试验按单项试验记录'].append((ft,n,r['record_type'],r['parent_trial_ids']))
    if src[ft]['来源级别']=='未记录': issues['来源级别未记录却已核实'].append((ft,n,r['main_scope']))
    if '老年' in n and r['age_scope']!='elderly_design': issues['名称含老年但年龄设计非老年'].append((ft,n,r['age_scope'],r['main_scope']))
    for p in r['parent_trial_ids']: pm[(tuple(r['application_ids']),p)].append(ft)
issues['多个FT共用同一申报+母试验ID']=[(k,v) for k,v in pm.items() if len(v)>1]
for k,v in issues.items():
    print('##',k,len(v))
    for x in v[:25]: print('  ',x)
json.dump({k:[str(x) for x in v] for k,v in issues.items()},open(B+'r8_work/checkpoints/audit_batch03.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
