#!/usr/bin/env python3
'''R8 step14: 只读。(1)检索氟西汀Prozac文件的NDA号；(2)核对step08固定表(APP_MAP)中每个申报号能否在对应文件缓存文本中找到，区分"有页内依据"与"仅固定表"。不写决定。'''
import json, re, os, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
base = B + 'r8_materials/R8_身份修复任务/'
cat = json.load(open(base + '04_原文目录/FDA原文与电子资料目录.json', encoding='utf-8'))
name2id = {c.get('original_name', ''): c['id'] for c in cat}
def find_ids(sub):
    return [(c['id'], c.get('original_name')) for c in cat if sub in c.get('original_name', '') or any(sub in a for a in c.get('aliases', []))]
pat = re.compile(r'(?:NDA|N\.D\.A\.|Application)\s*(?:No\.?|Number|#)?\s*[:\-]?\s*(\d{2}-?\d{3})', re.I)
def scan(fid):
    out = collections.Counter(); first = {}
    p = B + 'r3_full_revision/_pdftext/' + fid + '.json'
    if not os.path.exists(p):
        return None, None
    j = json.load(open(p, encoding='utf-8'))
    for pg in sorted(j['pages'], key=int):
        t = j['pages'][pg]
        if isinstance(t, str):
            for m in pat.finditer(t):
                n = m.group(1).replace('-', '')
                out[n] += 1
                first.setdefault(n, pg)
    return out, first
print('== 氟西汀Prozac文件')
for key in ['Prozac', 'FLX2003']:
    for fid, nm in find_ids(key):
        o, f = scan(fid)
        print('  ', fid, nm, dict(o.most_common(5)) if o is not None else '无缓存', {k: f[k] for k in list(f)[:3]} if f else '')
print('== step08 APP_MAP 核对(文件关键词 -> 申报号)')
APP_MAP = [('fdadrug_27', 'NDA019839'), ('fdadrug_22', 'NDA018936'), ('fdadrug_24', 'NDA020151'), ('fdadrug_21', 'NDA020358'), ('020415', 'NDA020415'), ('NDA022047', 'NDA022047'), ('021992', 'NDA021992'), ('020699', 'NDA020699'), ('021520', 'NDA021520'), ('204447', 'NDA204447'), ('021427', 'NDA021427'), ('021436', 'NDA021436'), ('018644', 'NDA018644'), ('20-936', 'NDA020936'), ('020822', 'NDA020822'), ('21-323', 'NDA021323'), ('022411', 'NDA022411')]
rows = []
for key, nda in APP_MAP:
    num = nda.replace('NDA', '')
    ids = find_ids(key)
    in_name = any(num[-5:] in (nm or '').replace('-', '').replace('_', '') or num[1:] in (nm or '').replace('-', '') for _, nm in ids)
    in_text = False
    for fid, nm in ids[:6]:
        o, f = scan(fid)
        if o and num in o:
            in_text = True; break
    rows.append({'key': key, 'nda': nda, 'files': len(ids), 'in_filename': in_name, 'in_text': in_text})
    print('  ', key, nda, '文件数', len(ids), '文件名含号', in_name, '缓存文本含号', in_text)
json.dump(rows, open(B + 'r8_work/checkpoints/step14_app_map_check.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
