#!/usr/bin/env python3
'''R8 step29: 由submission数据自动生成 change_log.json、search_log.json、unresolved_ledger.json、R8_REPORT.txt。
所有计数来自数据；不手写完成率。R7旧值取自R8任务包03_R7原回传/identity_table.json。仅标准库。'''
import json, collections, hashlib, glob, os
B = '/Users/dxm/work/jingya/FDAcheck/'
W = B + 'r8_work/'
S = W + 'submission/'
PK = B + 'r8_materials/R8_身份修复任务/'
cw = json.load(open(S + 'identity_crosswalk.json', encoding='utf-8'))['records']
cd = json.load(open(S + 'candidate_disposition.json', encoding='utf-8'))['records']
r7 = {r['FT']: r for r in json.load(open(PK + '03_R7原回传/identity_table.json', encoding='utf-8'))['records']}
extra = json.load(open(S + 'validation_extra.json', encoding='utf-8'))
m = {r['ft_id']: r for r in cw}

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        h.update(f.read())
    return h.hexdigest()

# change_log: 逐FT对比R7旧值与R8候选新值
chg = []
for ft, r in m.items():
    o = r7.get(ft, {})
    for fld, old, new in [('申报药物', o.get('申报药物'), r['application_drugs']), ('父试验', o.get('父试验ID'), r['parent_trial_ids']),
                          ('是否参照臂', o.get('是否参照臂'), r['is_reference_arm']), ('年龄人群', o.get('年龄人群'), r['age_scope']),
                          ('方案', o.get('方案ID'), r['regimen_id']), ('主分析纳入', o.get('主分析纳入'), r['main_scope'])]:
        if old != new:
            chg.append({'ft_id': ft, 'field': fld, 'r7_old': old, 'r8_candidate_new': new, 'status': r['mapping_status'],
                        'basis': [b['source'] + ' ' + b['locator'] for b in r['identity_basis'][:2]],
                        'impact': '身份/范围字段变化；本轮不改D18编码与字母'})
json.dump({'note': 'R7旧值来自R7 identity_table.json(含默认空值/False/成人/单药)，R8为候选新值，待接收方验收；原文件未覆盖。', 'count': len(chg), 'by_field': dict(collections.Counter(c['field'] for c in chg)), 'records': chg},
          open(S + 'change_log.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# search_log: 检查点日志清单
logs = sorted(glob.glob(W + 'checkpoints/step*.log'))
json.dump({'note': '定位与检索过程；未查的不记缺失。', 'visual_checks': json.load(open(W + 'checkpoints/visual_checks_round1.json', encoding='utf-8')),
           'checkpoint_logs': [os.path.basename(p) for p in logs],
           'tooling': 'PDF页渲染用 r8_work/scripts/render_pdf_page.swift(PDFKit)；缓存文本检索仅作线索，不等于目视'},
          open(S + 'search_log.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# 未决台账: 逐ID分类
ui = [{'id': r['ft_id'], 'kind': 'FT', 'name': r['original_trial_name'], 'category': (r['unresolved_categories'] or ['未分类'])[0], 'identity_status': r['mapping_status'], 'scope': r['main_scope'], 'next_action': r['next_action']}
      for r in cw if r['mapping_status'] != 'verified' or r['main_scope'] == 'unresolved']
ui += [{'id': d['candidate_id'], 'kind': 'candidate', 'category': d.get('unresolved_category'), 'reason': d['reason']} for d in cd if d['status'] == 'unresolved']
json.dump({'note': '逐ID；缺原件=0项，因本轮未判定任何记录为缺原件(未实际穷尽查找前不归此类)。', 'items': ui}, open(S + 'unresolved_ledger.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

ver = [r for r in cw if r['mapping_status'] == 'verified']
orig = [r for r in ver if any(b.get('basis_type') == 'original' for b in r['identity_basis'])]
L = []
L.append('R8 身份修复 阶段交付报告（数字均由数据自动生成）')
L.append('范围：身份关联与范围台账。未做D18编码、字母、缺口或proposal更新；不代表全量证据核查完成。')
L.append('FT总数=%d；身份核实(verified)=%d；身份未决=%d' % (len(cw), len(ver), len(cw) - len(ver)))
L.append('其中含本轮目视原件依据(original)的核实FT=%d；仅工作表线索的核实FT=%d' % (len(orig), len(ver) - len(orig)))
L.append('main_scope 分布: %s' % dict(collections.Counter(r['main_scope'] for r in cw)))
L.append('候选总数=%d；处置分布: %s' % (len(cd), dict(collections.Counter(d['status'] for d in cd))))
L.append('未决FT类别: %s' % dict(collections.Counter((r['unresolved_categories'] or ['无'])[0] for r in cw if r['mapping_status'] != 'verified' or r['main_scope'] == 'unresolved')))
L.append('未决候选类别: %s' % dict(collections.Counter(d.get('unresolved_category') for d in cd if d['status'] == 'unresolved')))
L.append('change_log 条数=%d，按字段: %s' % (len(chg), dict(collections.Counter(c['field'] for c in chg))))
L.append('补充验证失败项:')
for k, v in extra.items():
    if k != 'summary' and v['count']:
        L.append('  - %s: %d' % (k, v['count']))
L.append('说明: 失败项原样保留。HGIE的FT0085/FT0135为同一母试验的两个药物索引，不得重复计数；仅工作表线索的核实FT未目视原件，需验收方抽查。')
L.append('说明: 附带检查程序只检查结构，退出码2表示仍有未决，不代表科学审核通过。')
L.append('输入SHA256:')
for p in [PK + '02_冻结输入/phase3_dimensions_3674_CORRECTED.json', PK + '02_冻结输入/phase2_trial_extractions_235.json']:
    L.append('  %s %s' % (os.path.basename(p), sha(p)))
L.append('输出SHA256:')
for fn in ['identity_crosswalk.json', 'candidate_disposition.json', 'scope_ledger.json', 'change_log.json', 'search_log.json', 'unresolved_ledger.json', 'validation_extra.json']:
    L.append('  %s %s' % (fn, sha(S + fn)))
open(S + 'R8_REPORT.txt', 'w', encoding='utf-8').write('\n'.join(L) + '\n')
print('\n'.join(L))
