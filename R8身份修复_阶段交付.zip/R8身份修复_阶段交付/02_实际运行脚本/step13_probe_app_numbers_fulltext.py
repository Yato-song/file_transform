#!/usr/bin/env python3
'''R8 step13: 只读。全文检索fdadrug_26/22/24及Paxil相关文件中的NDA号，按页给出首个命中位置与上下文。不写决定，不按记忆补号。'''
import json, re, collections, os
B = '/Users/dxm/work/jingya/FDAcheck/'
base = B + 'r8_materials/R8_身份修复任务/'
cat = json.load(open(base + '04_原文目录/FDA原文与电子资料目录.json', encoding='utf-8'))
TARGET = {'fdadrug_26': 'FDA-e4f1c139b27f', 'fdadrug_22': 'FDA-d5e4a572fd98', 'fdadrug_24': 'FDA-da48d09aca83'}
pat = re.compile(r'(?:NDA|N\.D\.A\.|Application)\s*(?:No\.?|Number|#)?\s*[:\-]?\s*(\d{2}-?\d{3})', re.I)
for name, fid in TARGET.items():
    print('==', name, fid)
    for sub in ['_pdftext', '_ocrtext']:
        p = B + 'r3_full_revision/' + sub + '/' + fid + '.json'
        if not os.path.exists(p):
            print('  ', sub, '无缓存文件'); continue
        j = json.load(open(p, encoding='utf-8'))
        cnt = collections.Counter(); first = {}
        for pg in sorted(j['pages'], key=int):
            t = j['pages'][pg]
            if not isinstance(t, str): continue
            for m in pat.finditer(t):
                num = m.group(1)
                cnt[num] += 1
                first.setdefault(num, (pg, t[max(0, m.start() - 60):m.end() + 60].replace('\n', ' ')))
        print('  ', sub, 'n_pages', j.get('n_pages'), '命中', dict(cnt.most_common(6)))
        for num, (pg, ctx) in list(first.items())[:4]:
            print('     ', num, 'p', pg, '|', ctx)
print('== 目录中Paxil/paroxetine相关文件(仅元数据)')
for c in cat:
    s = c.get('original_name', '')
    if re.search(r'paxil|paroxetine|PAR_', s, re.I):
        print('  ', c['id'], s, '|', c.get('archived_type'))
