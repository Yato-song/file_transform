import json,glob,os,re
B='/Users/dxm/work/jingya/FDAcheck/r3_full_revision/'
BASE='/Users/dxm/work/jingya/FDAcheck/r8_materials/R8_身份修复任务/'
cat=json.load(open(BASE+'04_原文目录/FDA原文与电子资料目录.json',encoding='utf-8'))
j=json.load(open(B+'_pdftext/FDA-9f5adbd403bb.json',encoding='utf-8'))
tx=j['pages']['80']; i=tx.find('5.l.3.3')
print('=== 米氮平 p80 003-023 段(缓存文本,非目视)'); print(tx[i:i+1800])
print('=== 文拉法辛相关文件中 elderly 线索')
vf=[c['id'] for c in cat if re.search(r'effexor|venlafaxine|fdadrug_24',c.get('original_name','')+' '.join(c.get('aliases',[])),re.I) and c['id'].startswith('FDA-')]
print('候选文件',vf)
for fid in vf:
    for sub in ['_pdftext','_ocrtext']:
        p=B+sub+'/'+fid+'.json'
        if not os.path.exists(p): continue
        jj=json.load(open(p,encoding='utf-8'))
        n=0
        for pg,t in jj.get('pages',{}).items():
            if isinstance(t,str) and re.search(r'elderly',t,re.I) and re.search(r'enrolled|patients\s*(?:>=|≥|over)\s*65|aged 65|65 years',t,re.I):
                m=re.search(r'elderly',t,re.I)
                print(fid,sub,'p',pg,'|',t[max(0,m.start()-100):m.end()+220].replace('\n',' ')); n+=1
                if n>=2: break
