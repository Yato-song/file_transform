import json,glob,os,re
BASE='/Users/dxm/work/jingya/FDAcheck/r8_materials/R8_身份修复任务/'
B='/Users/dxm/work/jingya/FDAcheck/r3_full_revision/'
cat=json.load(open(BASE+'04_原文目录/FDA原文与电子资料目录.json',encoding='utf-8'))
byid={c['id']:c for c in cat}
print('catalog rows',len(cat))
rx=re.compile(r'quetiapine|D1448C00014|TGA|CCT|vort14|venlafaxine|effexor|HCEX|elderly|geriatric',re.I)
print('=== 目录中文件名/别名线索(仅目录元数据,非原文核查)')
for c in cat:
    s=c.get('original_name','')+' '+' '.join(c.get('aliases',[]))+' '+(c.get('path') or '')
    if rx.search(s):
        print(c['id'],'|',c.get('original_name'),'|',c.get('archived_type'),'|',c.get('original_use_note'))
print('=== 缓存中精确字符串 D1448C00014 (按文件统计)')
files=sorted(glob.glob(B+'_pdftext/*.json'))+sorted(glob.glob(B+'_ocrtext/*.json'))
cnt={}
ctx={}
for f in files:
    j=json.load(open(f,encoding='utf-8'))
    for pg,tx in j.get('pages',{}).items():
        if isinstance(tx,str) and 'D1448C00014' in tx:
            fid=os.path.basename(f)[:-5]
            cnt.setdefault(fid,[]).append(pg)
            ctx.setdefault(fid,tx[max(0,tx.find('D1448C00014')-150):tx.find('D1448C00014')+250].replace('\n',' '))
for k,v in cnt.items():
    print(k,byid.get(k,{}).get('original_name'),'页',v[:10]);print('   ',ctx[k])
print('=== CCT-004 方案(FDA-d3a42156e6a7) 入组条件/设计线索')
j=json.load(open(B+'_pdftext/FDA-d3a42156e6a7.json',encoding='utf-8'))
print(byid.get('FDA-d3a42156e6a7',{}).get('original_name'),'n_pages',j['n_pages'])
for pg in sorted(j['pages'],key=int):
    tx=j['pages'][pg]
    if re.search(r'years of age|aged|Inclusion Criteria|Study Population|Major Depressive Disorder',tx) and int(pg)<=30:
        for m in re.finditer(r'(years of age|aged \d|Inclusion Criteria|without psychotic|psychotic)',tx):
            print('p',pg,'|',tx[max(0,m.start()-160):m.end()+200].replace('\n',' '));break
