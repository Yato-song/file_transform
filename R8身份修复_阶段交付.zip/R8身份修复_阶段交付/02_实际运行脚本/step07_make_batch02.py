#!/usr/bin/env python3
'''R8 step07: 生成第二批FT决定(依据=phase2工作表字段，basis_type=working_table，未目视原PDF)。
断言: FT药物/试验名 == 候选药物/试验名；否则退出。申报号取自候选出处文件名；项目内ID=ARM|申报号|试验号|药物，非官方编号。'''
import json, sys
B = '/Users/dxm/work/jingya/FDAcheck/'
P3 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase3_dimensions_3674_CORRECTED.json'
P2 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase2_trial_extractions_235.json'
OUT = B + 'r8_work/decisions/ft_batch02_workingtable.json'
ft = {}
for r in json.load(open(P3, encoding='utf-8')):
    ft.setdefault(r['模型记录ID'], r)
c = {r['候选记录ID']: r for r in json.load(open(P2, encoding='utf-8'))}
INC = ('included', '单药设计、自身申报、成人设计；范围状态不涉及疗效或D18编码。')
UNR_AUG = ('unresolved', '加药方案是否进入主设定在既定规则中未明确，已与单药分开建立方案身份，待研究者裁决。')
UNR_OFC = ('unresolved', 'OFC/HGIE方案及其导入期前治疗条件的主设定处理规则未明确，保留适用限定，待研究者裁决。')
NDA = {'喹硫平': 'NDA022047', '去甲文拉法辛': 'NDA021992', '舍曲林': 'NDA019839', '曲唑酮': 'NDA022411', '西酞普兰': 'NDA020822', '奥氮平': 'NDA021520', '氟西汀': 'NDA021520'}
# (ft, cand, 申报药物, 方案类, 年龄设计, (范围, 理由))
SPEC = [
 ('FT0019', 'FAD0024', '喹硫平', 'augmentation', 'adult_design', UNR_AUG),
 ('FT0020', 'FAD0025', '喹硫平', 'augmentation', 'adult_design', UNR_AUG),
 ('FT0021', 'FAD0026', '喹硫平', 'monotherapy', 'adult_design', INC),
 ('FT0022', 'FAD0027', '喹硫平', 'monotherapy', 'adult_design', INC),
 ('FT0023', 'FAD0028', '喹硫平', 'monotherapy', 'adult_design', INC),
 ('FT0024', 'FAD0029', '喹硫平', 'monotherapy', 'adult_design', INC),
 ('FT0035', 'FAD0052', '去甲文拉法辛', 'monotherapy', 'adult_design', INC),
 ('FT0036', 'FAD0053', '去甲文拉法辛', 'monotherapy', 'adult_design', INC),
 ('FT0038', 'FAD0055', '去甲文拉法辛', 'monotherapy', 'adult_design', INC),
 ('FT0039', 'FAD0056', '去甲文拉法辛', 'monotherapy', 'adult_design', INC),
 ('FT0040', 'FAD0057', '去甲文拉法辛', 'monotherapy', 'adult_design', INC),
 ('FT0041', 'FAD0058', '去甲文拉法辛', 'monotherapy', 'adult_design', INC),
 ('FT0042', 'FAD0059', '去甲文拉法辛', 'monotherapy', 'adult_design', INC),
 ('FT0002', 'FAD0003', '舍曲林', 'monotherapy', 'adult_design', INC),
 ('FT0044', 'FAD0063', '曲唑酮', 'monotherapy', 'adult_design', INC),
 ('FT0046', 'FAD0065', '西酞普兰', 'monotherapy', 'adult_design', INC),
 ('FT0085', 'FAD0125', '奥氮平', 'ofc', 'adult_design', UNR_OFC),
 ('FT0135', 'FAD0172', '奥氮平', 'ofc', 'adult_design', UNR_OFC),
]
recs = []
for f, cid, appdrug, rc, age, (scope, why) in SPEC:
    v, k = ft[f], c[cid]
    if v['试验名称候选'] != k['试验名称候选'] and f not in ('FT0135',):
        sys.exit('试验名不一致 %s/%s' % (f, cid))
    if f == 'FT0135':
        if 'HGIE' not in v['试验名称候选'] or 'HGIE' not in k['试验名称候选']:
            sys.exit('HGIE名称不一致')
    elif v['药物'] != k['药物']:
        sys.exit('药物不一致 %s/%s' % (f, cid))
    mother = k.get('确认母试验ID')
    std = v['药物']
    tn = v['试验名称候选'] if f != 'FT0135' else 'HGIE'
    rid = 'ARM|%s|%s|%s' % (NDA[appdrug], tn, std)
    note = ''
    if f == 'FT0135':
        note = ' 氟西汀索引与奥氮平索引(FT0085/FAD0125)共享HGIE试验，母试验按相同出处页、导入期及入排字段暂并为RT-114，待验收确认，不作为独立试验计数。'
    recs.append({
     'ft_id': f, 'mapping_status': 'verified', 'candidate_ids': [cid],
     'record_type': 'single_trial', 'standard_drug': std,
     'application_ids': [NDA[appdrug]], 'application_drugs': [appdrug],
     'parent_trial_ids': ['RT-114' if f == 'FT0135' else (mother or tn)],
     'arm_ids': [rid], 'regimen_id': '%s|%s|%s' % (NDA[appdrug], tn, rc),
     'regimen_class': rc, 'age_scope': age, 'is_reference_arm': False,
     'main_scope': scope, 'scope_reason': why + note,
     'identity_basis': [{'basis_type': 'working_table', 'source': 'phase2 ' + cid,
        'locator': '确认母试验ID=%s; %s' % (mother, str(k.get('出处及物理页'))[:110]),
        'excerpt': '%s; 人群=%s; 年龄=%s; 背景=%s' % (k.get('治疗方式') or k.get('方案候选'), k.get('人群'), k.get('年龄'), str(k.get('背景用药'))[:60])}],
     'unresolved_categories': [] if scope != 'unresolved' else ['待研究者裁决'],
     'next_action': '本轮未目视原PDF，仅工作表线索核实身份；待接收方验收' + ('；范围规则待裁决' if scope == 'unresolved' else '')})
json.dump({'batch': 'batch02_workingtable', 'records': recs}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('写入', len(recs), '条 ->', OUT)
