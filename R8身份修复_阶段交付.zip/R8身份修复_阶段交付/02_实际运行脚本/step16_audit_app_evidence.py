#!/usr/bin/env python3
'''R8 step16: 只读。审计交叉表中每个申报号的依据等级及受影响FT/候选；列出fdadrug_22/26相关候选出处，供补依据或降级。不写决定。'''
import json, collections, re
B = '/Users/dxm/work/jingya/FDAcheck/'
cw = json.load(open(B + 'r8_work/submission/identity_crosswalk.json', encoding='utf-8'))['records']
tiers = {r['nda']: r['tier'] for r in json.load(open(B + 'r8_work/checkpoints/step15_app_map_tiers.json', encoding='utf-8'))}
P2 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase2_trial_extractions_235.json'
cands = {r['候选记录ID']: r for r in json.load(open(P2, encoding='utf-8'))}
by = collections.defaultdict(list)
for r in cw:
    if r['mapping_status'] != 'verified':
        continue
    for a in r['application_ids']:
        by[a].append(r['ft_id'])
print('== 已核实FT按申报号的依据等级')
for a, v in sorted(by.items()):
    print(' ', a, '依据等级', tiers.get(a, '未在固定表/无记录'), 'FT数', len(v), v[:8])
print('== 出处含fdadrug_22/26的候选(出处字段文件名)')
for key in ['fdadrug_22', 'fdadrug_26']:
    ids = [cid for cid, k in cands.items() if key in str(k.get('出处及物理页'))]
    print(' ', key, len(ids), ids[:12])
print('== 帕罗西汀PAR系列候选的申报相关字段样例')
for cid in ['FAD0099', 'FAD0100', 'FAD0103']:
    k = cands[cid]
    print(' ', cid, str(k.get('出处及物理页'))[:120], '|', str(k.get('FDA入排英文原文'))[:100].replace('\n', ' '))
