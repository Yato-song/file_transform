#!/usr/bin/env python3
'''R8 step19: 应用 patches/app_evidence_patch.json 到 submission 交叉表与候选处置，写revision_trace。
应用前备份原版为 *.pre_patch01.json；已备份则不覆盖备份，避免重复应用丢失原版。
注意: step06 会从模板重建submission，重建后需重新运行本脚本(补丁幂等: 以revision_trace中patch_id判断是否已应用)。仅标准库。'''
import json, os, shutil, sys, collections
B = '/Users/dxm/work/jingya/FDAcheck/r8_work/'
S = B + 'submission/'
PID = 'app_evidence_patch_01'
patch = json.load(open(B + 'patches/app_evidence_patch.json', encoding='utf-8'))
assert patch['patch_id'] == PID
for fn in ['identity_crosswalk.json', 'candidate_disposition.json']:
    bak = S + fn.replace('.json', '.pre_patch01.json')
    if not os.path.exists(bak):
        shutil.copy(S + fn, bak)
cw = json.load(open(S + 'identity_crosswalk.json', encoding='utf-8'))
cd = json.load(open(S + 'candidate_disposition.json', encoding='utf-8'))
m = {r['ft_id']: r for r in cw['records']}
cm = {r['candidate_id']: r for r in cd['records']}
applied = collections.Counter()
for p in patch['records']:
    r = m.get(p['ft_id'])
    if r is None:
        sys.exit('补丁FT不存在: ' + p['ft_id'])
    tr = r.setdefault('revision_trace', [])
    if any(t.get('patch_id') == PID for t in tr):
        applied['已应用跳过'] += 1
        continue
    if p['action'] == 'append_basis_note':
        r['identity_basis'].append(p['basis'])
        tr.append({'patch_id': PID, 'action': p['action'], 'added_basis': p['basis']})
    elif p['action'] == 'downgrade_to_unresolved':
        old_cands = list(r['candidate_ids'])
        tr.append({'patch_id': PID, 'action': p['action'], 'old': {k: r[k] for k in ['mapping_status', 'candidate_ids', 'application_ids', 'application_drugs', 'main_scope', 'scope_reason']}, 'reason': p['reason']})
        r['mapping_status'] = 'unresolved'
        r['main_scope'] = 'unresolved'
        r['application_ids'] = []
        r['application_drugs'] = []
        r['candidate_ids'] = []
        r['scope_reason'] = p['reason']
        r['unresolved_categories'] = [p['category']]
        r['next_action'] = p['next_action']
        for c in old_cands:
            d = cm[c]
            d['ft_ids'] = [x for x in d.get('ft_ids', []) if x != p['ft_id']]
            if not d['ft_ids']:
                d['status'] = 'unresolved'
                d['unresolved_category'] = p['category']
                d['reason'] = '原对应FT %s 因申报号无依据降级(%s)，候选待重新核对。' % (p['ft_id'], PID)
    applied[p['action']] += 1
json.dump(cw, open(S + 'identity_crosswalk.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(cd, open(S + 'candidate_disposition.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('应用结果', dict(applied))
print('FT状态', dict(collections.Counter(r['mapping_status'] for r in cw['records'])))
print('候选状态', dict(collections.Counter(r['status'] for r in cd['records'])))
