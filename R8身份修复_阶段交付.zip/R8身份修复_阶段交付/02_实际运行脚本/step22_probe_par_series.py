#!/usr/bin/env python3
'''R8 step22: 只读。诊断帕罗西汀PAR系列FT/候选的出处页与fdadrug_26的NDA 20-031命中页，不写决定。'''
import json, re
B = '/Users/dxm/work/jingya/FDAcheck/'
base = B + 'r8_materials/R8_身份修复任务/'
cands = {r['候选记录ID']: r for r in json.load(open(base + '02_冻结输入/phase2_trial_extractions_235.json', encoding='utf-8'))}
cw = {r['ft_id']: r for r in json.load(open(B + 'r8_work/submission/identity_crosswalk.json', encoding='utf-8'))['records']}
print('== PAR系列FT与候选')
for i in range(65, 79):
    ft = 'FT%04d' % i
    r = cw[ft]
    h = json.load(open(B + 'r8_work/checkpoints/linkage_hints.json', encoding='utf-8'))['hints'][ft]['candidate_hints']
    k = cands[h[0]] if h else {}
    print(ft, r['original_trial_name'], r['mapping_status'], h, '|', k.get('人群'), '|', k.get('年龄'), '|', k.get('方案候选'), '|', str(k.get('出处及物理页'))[:70])
j = json.load(open(B + 'r3_full_revision/_pdftext/FDA-e4f1c139b27f.json', encoding='utf-8'))
print('== fdadrug_26(FDA-e4f1c139b27f) 缓存页数', j['n_pages'])
for pg in sorted(j['pages'], key=int):
    t = j['pages'][pg]
    if isinstance(t, str) and re.search(r'20-031|NDA|Applicant|Paroxetine|PAXIL', t, re.I) and int(pg) <= 12:
        m = re.search(r'20-031|NDA|Applicant|Paroxetine|PAXIL', t, re.I)
        print(' p', pg, '|', t[max(0, m.start() - 80):m.end() + 140].replace('\n', ' '))
