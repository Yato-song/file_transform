#!/usr/bin/env python3
'''R8 step08: 第三批FT决定(依据=phase2工作表字段，basis_type=working_table，未目视原PDF)。
规则: 已有决定的FT跳过；申报号只能由候选出处文件名按固定表提取，提取不到则unresolved；
年龄只按候选人群字段(老年/成人)判定，其余unresolved；加药/OFC/标签汇总一律unresolved；参照臂标true且main_scope=excluded。
项目内ID=ARM|申报号|试验号|药物，非官方编号。仅标准库。'''
import json, re, glob, sys, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
P2 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase2_trial_extractions_235.json'
HINT = B + 'r8_work/checkpoints/linkage_hints.json'
OUT = B + 'r8_work/decisions/ft_batch03_rule_workingtable.json'
SKIP_LOG = B + 'r8_work/checkpoints/batch03_unresolved_reasons.json'
APP_MAP = [('fdadrug_27', 'NDA019839'), ('fdadrug_22', 'NDA018936'), ('fdadrug_26', 'NDA020031'), ('fdadrug_24', 'NDA020151'), ('fdadrug_21', 'NDA020358'),
 ('020415', 'NDA020415'), ('NDA022047', 'NDA022047'), ('021992', 'NDA021992'), ('020699', 'NDA020699'),
 ('021520', 'NDA021520'), ('21520', 'NDA021520'), ('204447', 'NDA204447'), ('021427', 'NDA021427'),
 ('021436', 'NDA021436'), ('018644', 'NDA018644'), ('20-936', 'NDA020936'), ('020822', 'NDA020822'),
 ('21-323', 'NDA021323'), ('022411', 'NDA022411')]
cands = {r['候选记录ID']: r for r in json.load(open(P2, encoding='utf-8'))}
hints = json.load(open(HINT, encoding='utf-8'))['hints']
done = set()
for p in glob.glob(B + 'r8_work/decisions/ft_batch0[12]*.json'):
    done |= {r['ft_id'] for r in json.load(open(p, encoding='utf-8'))['records']}
arm_pat = re.compile(r'^(\S+)\s+(.+?)\s*的(\S+?)臂')
key2c = collections.defaultdict(list)
for c in cands.values():
    key2c[(c['药物'], c['试验名称候选'])].append(c['候选记录ID'])

def app_of(c):
    s = str(c.get('出处及物理页') or '')
    for pat, nda in APP_MAP:
        if pat in s:
            return nda
    return None

def age_of(c):
    p = str(c.get('人群') or '')
    if '老年' in p or '≥65' in p:
        return 'elderly_design'
    if p.startswith('儿少'):
        return 'youth_design'
    if p.startswith('成人MDD') or p == '难治性抑郁（成人）':
        return 'adult_design'
    return None

REG = {'单药': 'monotherapy', '加药': 'augmentation'}
SPECIAL_REFARM = {'FT0106': ('伏硫西汀', '12541A')}
STRATA = re.compile(r'层[）)]|[0-9][ab]$')
recs, reasons = [], {}

def unresolved(ft, h, why, cat, nxt):
    reasons[ft] = {'why': why, 'category': cat}
    recs.append({'ft_id': ft, 'mapping_status': 'unresolved', 'candidate_ids': [], 'record_type': 'unknown',
     'standard_drug': h['drug'], 'application_ids': [], 'application_drugs': [], 'parent_trial_ids': [], 'arm_ids': [],
     'regimen_id': None, 'regimen_class': 'unknown', 'age_scope': 'unknown', 'is_reference_arm': None,
     'main_scope': 'unresolved', 'scope_reason': why, 'identity_basis': [], 'unresolved_categories': [cat], 'next_action': nxt})

for ft, h in sorted(hints.items()):
    if ft in done:
        continue
    if h['method'] == 'none' or not h['candidate_hints']:
        unresolved(ft, h, '无精确线索：药物+试验名在候选集合中无对应，需按来源文件人工定位。', '身份待核', '查目录与PDF，确认该记录对应的试验、申报与方案。')
        continue
    if len(h['candidate_hints']) != 1:
        unresolved(ft, h, '线索为一对多: %s' % h['candidate_hints'], '身份待核', '逐项区分重复来源/分层/不同试验。')
        continue
    cid = h['candidate_hints'][0]
    k = cands[cid]
    if k['药物'] != h['drug']:
        sys.exit('药物不一致 %s/%s' % (ft, cid))
    name = h['trial_name']
    if STRATA.search(name):
        unresolved(ft, h, '分层或a/b子试验：与母试验及兄弟记录的关系未核，不冒充独立试验，也不与兄弟记录合并计数。', '尚未核完', '回原文确认是独立试验还是同一方案的分层/子试验，再定母试验ID。')
        continue
    m = arm_pat.match(name)
    if ft in SPECIAL_REFARM:
        m = True
    is_ref = bool(m)
    parent_c = None
    if is_ref:
        if ft in SPECIAL_REFARM:
            pd, pt = SPECIAL_REFARM[ft]
        else:
            pd, pt, ad = m.groups()
        ps = key2c.get((pd, pt), [])
        if len(ps) != 1:
            unresolved(ft, h, '参照臂的父试验候选数=%d: %s' % (len(ps), ps), '身份待核', '确认该参照臂所属申报试验。')
            continue
        parent_c = cands[ps[0]]
    if name.startswith('标签'):
        unresolved(ft, h, '标签汇总行：汇总内试验数与子试验身份未确定，不冒充单项试验。', '尚未核完', '回标签原文核对汇总所含试验，保留集合身份。')
        continue
    src = parent_c if is_ref else k
    nda = app_of(src)
    if not nda:
        unresolved(ft, h, '申报号无法从出处字段按固定表提取: %s' % str(src.get('出处及物理页'))[:80], '尚未核完', '查来源文件首页确认申报号。')
        continue
    age = age_of(src)
    reg = REG.get(src.get('方案候选'))
    if age is None or reg is None:
        unresolved(ft, h, '年龄或方案无法由字段确定: 人群=%s 方案候选=%s' % (src.get('人群'), src.get('方案候选')), '尚未核完', '读原文确认年龄设计与方案。')
        continue
    appdrug = src['药物']
    tn = pt if is_ref else name
    std = h['drug']
    mother = src.get('确认母试验ID') or tn
    if is_ref:
        scope, why = 'excluded', '参照臂：属于%s申报试验%s，主设定仅纳入自身申报，保留供扩展设定。' % (appdrug, tn)
    elif age == 'elderly_design':
        scope, why = 'excluded', '候选人群字段为老年设计，按既定主设定排除；不据此推断个体年龄。'
    elif age == 'youth_design':
        scope, why = 'excluded', '儿少设计，主设定排除。'
    elif reg == 'augmentation':
        scope, why = 'unresolved', '加药方案主设定处理规则未明确，待裁决。'
    else:
        scope, why = 'included', '自身申报、成人设计、单药；范围状态不涉及疗效或D18编码。'
    arm_drug = std
    recs.append({'ft_id': ft, 'mapping_status': 'verified', 'candidate_ids': [cid],
     'record_type': 'reference_arm' if is_ref else 'single_trial', 'standard_drug': std,
     'application_ids': [nda], 'application_drugs': [appdrug], 'parent_trial_ids': [mother], 'arm_ids': ['ARM|%s|%s|%s' % (nda, tn, arm_drug)],
     'regimen_id': '%s|%s|%s%s' % (nda, tn, reg, '_comparator_arm' if is_ref else ''), 'regimen_class': reg, 'age_scope': age,
     'is_reference_arm': is_ref, 'main_scope': scope, 'scope_reason': why,
     'identity_basis': [{'basis_type': 'working_table', 'source': 'phase2 ' + cid + (' (父试验线索 %s)' % h['parent_hints'] if is_ref else ''),
        'locator': '确认母试验ID=%s; %s' % (k.get('确认母试验ID'), str(src.get('出处及物理页'))[:110]),
        'excerpt': '人群=%s; 年龄=%s; 方案候选=%s' % (src.get('人群'), src.get('年龄'), src.get('方案候选'))}],
     'unresolved_categories': [] if scope != 'unresolved' else ['待研究者裁决'],
     'next_action': '本轮未目视原PDF，仅工作表线索核实；待接收方验收' + ('；范围规则待裁决' if scope == 'unresolved' else '')})
json.dump({'batch': 'batch03_rule_workingtable', 'records': recs}, open(OUT, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(reasons, open(SKIP_LOG, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
st = collections.Counter(r['mapping_status'] for r in recs)
print('写入', len(recs), '条', dict(st))
print('verified范围', dict(collections.Counter(r['main_scope'] for r in recs if r['mapping_status'] == 'verified')))
print('unresolved原因类别', dict(collections.Counter(v['category'] for v in reasons.values())))
