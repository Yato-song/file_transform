#!/usr/bin/env python3
'''R8 step21: 依据已目视(fdadrug_22 物理28/139/159页均写NDA 18-936，申报方Eli Lilly)，恢复step19因“无申报号依据”降级的氟西汀FT。
断言: 仅恢复revision_trace中有patch_01降级记录、且候选出处字段含fdadrug_22的FT；恢复值取自trace旧值，不重新推断。
幂等: 以restore_patch_01是否已在trace中判断。仅标准库。'''
import json, sys, collections
B = '/Users/dxm/work/jingya/FDAcheck/'
S = B + 'r8_work/submission/'
PID = 'restore_nda018936_01'
P2 = B + 'r8_materials/R8_身份修复任务/02_冻结输入/phase2_trial_extractions_235.json'
cands = {r['候选记录ID']: r for r in json.load(open(P2, encoding='utf-8'))}
cw = json.load(open(S + 'identity_crosswalk.json', encoding='utf-8'))
cd = json.load(open(S + 'candidate_disposition.json', encoding='utf-8'))
cm = {r['candidate_id']: r for r in cd['records']}
BASIS = {'basis_type': 'original', 'source': 'd5e4a572fd98_fdadrug_22.pdf', 'locator': '物理28页(印刷142)、物理139页(效力评审封面)、物理159页(Summary Basis of Approval)',
         'excerpt': 'Orig: NDA 18-936; REVIEW AND EVALUATION OF EFFICACY DATA NDA 18-936 PROZAC (FLUOXETINE HYDROCHLORIDE) Sponsor: Eli Lilly; NDA 18-936 Applicant: Eli Lilly and Company. 本轮目视渲染页。该文件属NDA 18-936；单个试验是否在该文件内以候选出处字段为准，未逐试验目视。'}
n = collections.Counter()
for r in cw['records']:
    tr = r.get('revision_trace', [])
    down = [t for t in tr if t.get('action') == 'downgrade_to_unresolved' and t.get('old', {}).get('application_ids') == ['NDA018936']]
    if not down:
        continue
    if any(t.get('patch_id') == PID for t in tr):
        n['已恢复跳过'] += 1
        continue
    old = down[-1]['old']
    cids = old['candidate_ids']
    for c in cids:
        if 'fdadrug_22' not in str(cands[c].get('出处及物理页')):
            sys.exit('候选出处不含fdadrug_22，不恢复: %s/%s' % (r['ft_id'], c))
    for k in ['mapping_status', 'candidate_ids', 'application_ids', 'application_drugs', 'main_scope', 'scope_reason']:
        r[k] = old[k]
    r['unresolved_categories'] = []
    r['next_action'] = '待接收方验收；申报号已有原件目视依据，单试验是否在文件内以候选出处字段为准。'
    r['identity_basis'].append(BASIS)
    tr.append({'patch_id': PID, 'action': 'restore', 'restored_from': 'step19 trace old', 'added_basis': BASIS})
    for c in cids:
        d = cm[c]
        d['status'] = 'mapped'
        d['ft_ids'] = sorted(set(d.get('ft_ids', []) + [r['ft_id']]))
        d['reason'] = '由已核实FT的交叉表反向对应(申报号依据已恢复,%s)' % PID
        d.pop('unresolved_category', None)
    n['恢复'] += 1
json.dump(cw, open(S + 'identity_crosswalk.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump(cd, open(S + 'candidate_disposition.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('恢复结果', dict(n))
print('FT状态', dict(collections.Counter(r['mapping_status'] for r in cw['records'])))
print('候选状态', dict(collections.Counter(r['status'] for r in cd['records'])))
