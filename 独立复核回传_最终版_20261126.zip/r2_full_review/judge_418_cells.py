#!/usr/bin/env python3
"""418格实质判定 - 研究讨论和用药建议"""
import json, re

def normalize_drug_name(drug):
    """标准化药物名称，移除剂量、联用等修饰"""
    if not drug:
        return drug
    # 移除括号内容和特殊符号
    import re
    drug = re.sub(r'[（\(].*?[）\)]', '', drug)
    drug = re.sub(r'[→＋\+].*', '', drug)
    return drug.strip()

def has_research_discussion(stmt):
    """判断是否有研究讨论"""
    # 任何证据等级的研究提及
    if stmt.get('type') == 'GRADE_table':
        return True

    text = stmt.get('excerpt', '') + stmt.get('context', '')

    research_keywords = [
        'study', 'trial', 'research', 'evidence', 'RCT',
        '研究', '试验', '证据', 'meta分析', '系统评价'
    ]

    return any(kw in text for kw in research_keywords)

def has_drug_recommendation(stmt):
    """判断是否有用药建议"""
    text = stmt.get('excerpt', '') + stmt.get('context', '')

    recommendation_keywords = [
        'recommend', 'should', 'suggest', 'consider',
        '推荐', '建议', '可以', '应该', '优选', '首选'
    ]

    # 检查推荐等级
    grade_patterns = [
        r'Grade\s*[123A-C]',
        r'Level\s*[123A-C]',
        r'[一二三]级推荐',
        r'强推荐',
        r'弱推荐'
    ]

    has_rec_keyword = any(kw in text for kw in recommendation_keywords)
    has_grade = any(re.search(pat, text, re.IGNORECASE) for pat in grade_patterns)

    return has_rec_keyword or has_grade

def main():
    # 加载资源
    guideline_stmts = json.load(open('phase1_extraction/all_guideline_statements.json'))
    cells_framework = json.load(open('calculation/418_cells_framework.json'))

    # 建立陈述索引 - 标准化药物名称
    stmts_by_drug = {}
    for stmt in guideline_stmts:
        drug = stmt.get('drug', '')
        if drug:
            normalized = normalize_drug_name(drug)
            if normalized not in stmts_by_drug:
                stmts_by_drug[normalized] = []
            stmts_by_drug[normalized].append(stmt)

    # 逐格判定
    cells = cells_framework['cells']
    judged_cells = {}

    for cell_id, cell_info in cells.items():
        drug = cell_info['drug']
        dimension = cell_info['dimension']

        # 查找相关陈述 - 标准化药物名称匹配
        normalized_drug = normalize_drug_name(drug)
        relevant_stmts = stmts_by_drug.get(normalized_drug, [])

        # 判定
        has_research = False
        has_recommendation = False
        supporting_stmts = []

        for stmt in relevant_stmts:
            if has_research_discussion(stmt):
                has_research = True
                supporting_stmts.append({
                    'stmt_id': stmt.get('stmt_id'),
                    'type': 'research',
                    'source': stmt.get('source_id')
                })

            if has_drug_recommendation(stmt):
                has_recommendation = True
                if not any(s['stmt_id'] == stmt.get('stmt_id') for s in supporting_stmts):
                    supporting_stmts.append({
                        'stmt_id': stmt.get('stmt_id'),
                        'type': 'recommendation',
                        'source': stmt.get('source_id')
                    })

        judged_cells[cell_id] = {
            'drug': drug,
            'dimension': dimension,
            'has_research': has_research,
            'has_recommendation': has_recommendation,
            'historical_93': cell_info['historical_93'],
            'supporting_stmts': supporting_stmts,
            'status': '已判定' if relevant_stmts else '无相关陈述'
        }

    # 统计
    with_research = sum(1 for c in judged_cells.values() if c['has_research'])
    with_recommendation = sum(1 for c in judged_cells.values() if c['has_recommendation'])
    historical_verified = sum(1 for c in judged_cells.values()
                            if c['historical_93'] and (c['has_research'] or c['has_recommendation']))

    result = {
        'cells': judged_cells,
        'total': len(judged_cells),
        'with_research': with_research,
        'with_recommendation': with_recommendation,
        'historical_93_verified': historical_verified
    }

    with open('calculation/418_cells_judged.json', 'w') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f'418格判定完成')
    print(f'  总格数: {len(judged_cells)}')
    print(f'  有研究讨论: {with_research}格')
    print(f'  有用药建议: {with_recommendation}格')
    print(f'  历史93格验证: {historical_verified}/93')

if __name__ == '__main__':
    main()
