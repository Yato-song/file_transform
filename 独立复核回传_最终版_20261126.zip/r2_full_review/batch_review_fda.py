#!/usr/bin/env python3
"""批量审核FDA试验，修复上轮文件定位问题"""
import json, sys, os, re

def find_fda_files(trial_name, drug, fda_catalog, fda_cache_index):
    """通过试验名、药物名、申请号等多种方式定位FDA文件"""
    matches = []

    # 构建搜索词：试验名、药物、常见别名
    search_terms = [trial_name, drug]

    # 添加常见试验名变体
    if trial_name:
        search_terms.append(trial_name.replace('-',''))
        search_terms.append(trial_name.replace(' ',''))
        # 提取数字部分
        nums = re.findall(r'\d+', trial_name)
        search_terms.extend(nums)

    # 在目录中搜索
    for item in fda_catalog:
        item_text = (item.get('original_name','') + ' ' +
                     ' '.join(item.get('aliases',[])) + ' ' +
                     ' '.join(item.get('urls',[])))

        for term in search_terms:
            if term and len(term)>2 and term.lower() in item_text.lower():
                matches.append({
                    'file_id': item['id'],
                    'path': item['path'],
                    'sha256': item['sha256'],
                    'type': item.get('archived_type',''),
                    'match_term': term
                })
                break

    return matches

def extract_trial_details(file_id, cache_base, trial_name, drug):
    """从缓存文本中提取试验详情"""
    cache_dir = os.path.join(cache_base, file_id)
    if not os.path.exists(cache_dir):
        return None

    # 读取所有页面（不限前3页）
    pages = []
    for txt_file in sorted(os.listdir(cache_dir)):
        if txt_file.endswith('.txt'):
            pg_num = int(re.search(r'\d+', txt_file).group())
            with open(os.path.join(cache_dir, txt_file)) as f:
                pages.append((pg_num, f.read()))

    if not pages:
        return None

    # 查找关键章节
    result = {
        'file_id': file_id,
        'pages_total': len(pages),
        'trial_found': False,
        'fda_judgment': None,
        'inclusion_criteria': None,
        'exclusion_criteria': None,
        'population': None,
        'results': None
    }

    # 搜索试验提及
    for pg, txt in pages:
        if trial_name and trial_name.lower() in txt.lower():
            result['trial_found'] = True
            result['first_mention_page'] = pg

            # 提取FDA判断关键词
            if any(w in txt.lower() for w in ['positive', 'demonstrated efficacy', 'statistically significant']):
                result['fda_judgment'] = 'positive_indication'
            elif any(w in txt.lower() for w in ['failed to demonstrate', 'not establish', 'negative']):
                result['fda_judgment'] = 'failed_indication'

            # 提取人群信息
            if 'inclusion criteria' in txt.lower():
                start = txt.lower().find('inclusion criteria')
                result['inclusion_criteria'] = txt[start:start+500]

            if 'exclusion criteria' in txt.lower():
                start = txt.lower().find('exclusion criteria')
                result['exclusion_criteria'] = txt[start:start+500]

            # 提取结果
            if any(w in txt.lower() for w in ['primary endpoint', 'hamd', 'madrs', 'response rate']):
                result['results'] = txt[max(0,txt.lower().find('primary')-100):txt.lower().find('primary')+400]

            break

    return result

def review_fda_record(record_id, fda_table, headers, fda_catalog, cache_base):
    """审核单条FDA记录"""
    # 查找该记录
    row = None
    for r in fda_table['rows']:
        if r[0] == record_id:
            row = r
            break

    if not row:
        return {'record_id': record_id, 'status': '未找到记录'}

    drug = row[headers.index('药物')]
    trial_name = row[headers.index('试验名称候选')]

    # 定位文件
    matches = find_fda_files(trial_name, drug, fda_catalog, None)

    if not matches:
        return {
            'record_id': record_id,
            'drug': drug,
            'trial_name': trial_name,
            'status': '未找到匹配文件',
            'search_attempted': True
        }

    # 提取详情
    details = None
    for match in matches[:5]:  # 检查前5个匹配
        details = extract_trial_details(match['file_id'], cache_base, trial_name, drug)
        if details and details['trial_found']:
            break

    return {
        'record_id': record_id,
        'drug': drug,
        'trial_name': trial_name,
        'status': '已提取' if (details and details['trial_found']) else '文件已定位但未找到试验提及',
        'matched_files': len(matches),
        'details': details
    }

if __name__ == '__main__':
    record_ids = json.load(open(sys.argv[1]))  # 记录ID列表
    output_file = sys.argv[2]

    # 加载资源
    template = json.load(open('../review_extract_R1/指南与FDA独立复核包_20261125_R1/01_任务与回传/回传字段模板.json'))
    fda_catalog = json.load(open('../review_extract_R1/指南与FDA独立复核包_20261125_R1/01_任务与回传/FDA原文与电子资料目录.json'))

    tables = {t['name']:t for t in template['tables']}
    fda_table = tables['FDA源表候选235']
    headers = fda_table['headers']

    cache_base = '/Users/dxm/work/jingya/FDAcheck/review_work/text_cache/fda'

    results = []
    for i, record_id in enumerate(record_ids, 1):
        result = review_fda_record(record_id, fda_table, headers, fda_catalog, cache_base)
        results.append(result)

        if i % 20 == 0:
            print(f'已审核{i}/{len(record_ids)}')

    with open(output_file, 'w') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 统计
    found = sum(1 for r in results if r.get('details') and r['details'].get('trial_found'))
    matched = sum(1 for r in results if r.get('matched_files',0)>0)
    print(f'\\n完成{len(results)}条FDA记录')
    print(f'  找到匹配文件: {matched}条')
    print(f'  成功提取试验信息: {found}条')
