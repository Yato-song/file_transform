#!/usr/bin/env python3
"""改进FDA试验提取 - 修复试验名匹配和详细信息提取"""
import json, os, re

def normalize_trial_name(name):
    """标准化试验名，移除常见变体"""
    if not name:
        return []

    variants = [name.strip()]
    # 移除连字符
    variants.append(name.replace('-', ''))
    variants.append(name.replace(' ', ''))
    # 提取数字
    nums = re.findall(r'\d+', name)
    variants.extend(nums)
    # 提取字母数字组合
    alphanum = re.findall(r'[A-Z]+\d+', name, re.IGNORECASE)
    variants.extend(alphanum)

    return list(set(v.lower() for v in variants if len(v) > 2))

def deep_search_trial(trial_name, drug, cache_dir):
    """深度搜索试验信息"""
    if not os.path.exists(cache_dir):
        return None

    variants = normalize_trial_name(trial_name)
    result = {
        'trial_found': False,
        'pages_checked': 0,
        'mentions': [],
        'inclusion_criteria': None,
        'exclusion_criteria': None,
        'primary_endpoint': None,
        'fda_judgment': None
    }

    # 读取所有页面
    pages = []
    for txt_file in sorted(os.listdir(cache_dir)):
        if txt_file.endswith('.txt'):
            pg_num = int(re.search(r'\d+', txt_file).group())
            with open(os.path.join(cache_dir, txt_file)) as f:
                pages.append((pg_num, f.read()))

    result['pages_checked'] = len(pages)

    # 搜索试验提及
    for pg, txt in pages:
        txt_lower = txt.lower()

        # 检查试验名变体
        for variant in variants:
            if variant in txt_lower:
                result['trial_found'] = True
                result['mentions'].append({
                    'page': pg,
                    'variant': variant,
                    'context': txt[max(0, txt_lower.find(variant)-100):txt_lower.find(variant)+200]
                })

                # 提取关键信息
                if 'inclusion criteria' in txt_lower and not result['inclusion_criteria']:
                    start = txt_lower.find('inclusion criteria')
                    result['inclusion_criteria'] = txt[start:start+800]

                if 'exclusion criteria' in txt_lower and not result['exclusion_criteria']:
                    start = txt_lower.find('exclusion criteria')
                    result['exclusion_criteria'] = txt[start:start+800]

                if any(ep in txt_lower for ep in ['primary endpoint', 'primary outcome', 'hamd', 'madrs']):
                    if not result['primary_endpoint']:
                        for ep_key in ['primary endpoint', 'primary outcome']:
                            if ep_key in txt_lower:
                                start = txt_lower.find(ep_key)
                                result['primary_endpoint'] = txt[start:start+500]
                                break

                # FDA判断关键词
                if any(w in txt_lower for w in ['demonstrated efficacy', 'statistically significant improvement', 'positive study']):
                    result['fda_judgment'] = 'positive'
                elif any(w in txt_lower for w in ['failed to demonstrate', 'did not meet', 'negative study']):
                    result['fda_judgment'] = 'negative'

                break

        if result['trial_found']:
            break

    return result

def main():
    # 加载资源
    fda_records = json.load(open('phase1_extraction/all_fda_records.json'))
    template = json.load(open('../review_extract_R1/指南与FDA独立复核包_20261125_R1/01_任务与回传/回传字段模板.json'))
    fda_catalog = json.load(open('../review_extract_R1/指南与FDA独立复核包_20261125_R1/01_任务与回传/FDA原文与电子资料目录.json'))

    tables = {t['name']:t for t in template['tables']}
    fda_table = tables['FDA源表候选235']
    headers = fda_table['headers']

    cache_base = '/Users/dxm/work/jingya/FDAcheck/review_work/text_cache/fda'

    improved_records = []
    success_count = 0

    for i, record in enumerate(fda_records, 1):
        record_id = record['record_id']

        # 如果已经有匹配文件，深度提取
        if record.get('matched_files', 0) > 0:
            matched_file_ids = []
            # 重新查找匹配的文件ID
            trial_name = record.get('trial_name', '')
            drug = record.get('drug', '')

            for catalog_item in fda_catalog:
                item_text = (catalog_item.get('original_name', '') + ' ' +
                           ' '.join(catalog_item.get('aliases', [])))

                if any(term in item_text.lower()
                      for term in normalize_trial_name(trial_name) + [drug.lower()]):
                    matched_file_ids.append(catalog_item['id'])

            # 深度搜索前3个匹配文件
            best_result = None
            for file_id in matched_file_ids[:3]:
                cache_dir = os.path.join(cache_base, file_id)
                details = deep_search_trial(trial_name, drug, cache_dir)

                if details and details['trial_found']:
                    best_result = details
                    best_result['file_id'] = file_id
                    success_count += 1
                    break

            record['details_v2'] = best_result if best_result else {
                'trial_found': False,
                'reason': '文件已匹配但未找到试验提及'
            }

        improved_records.append(record)

        if i % 50 == 0:
            print(f'已处理 {i}/{len(fda_records)}')

    # 保存改进结果
    with open('phase1_extraction/all_fda_records_v2.json', 'w') as f:
        json.dump(improved_records, f, ensure_ascii=False, indent=2)

    print(f'\nFDA试验提取改进完成')
    print(f'  成功提取: {success_count}/{len(fda_records)}条')
    print(f'  成功率: {success_count*100//len(fda_records)}%')

if __name__ == '__main__':
    main()
