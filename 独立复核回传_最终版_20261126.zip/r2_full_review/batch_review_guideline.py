#!/usr/bin/env python3
"""批量审核指南陈述，修复上轮问题：
1. WHO逐结局提取效应量、CI、研究数、GRADE
2. 其他指南修复中英文药名检索、读取完整页面和表格
3. 逐条提取原文、判定研究讨论和用药建议
"""
import json, sys, os, re

def extract_grade_cell(page_text, drug, outcome, start_marker=None):
    """从WHO GRADE表提取单个结局的完整信息"""
    # 查找表格行：药物名、结局名、数值
    lines = page_text.split('\n')

    # 寻找结局标题行
    outcome_markers = {
        'change_symptoms': 'Change in depressive symptoms',
        'response': 'Response (efficacy)',
        'dropout_all': 'All-cause dropout',
        'dropout_ae': 'Dropout due to adverse events',
        'suicide': 'Suicide',
        'qol': 'QAL and functioning'
    }

    result = {
        'outcome': outcome,
        'found': False,
        'effect_size': None,
        'ci_lower': None,
        'ci_upper': None,
        'n_studies': None,
        'n_patients': None,
        'certainty': None,
        'raw_text': None
    }

    # 提取SMD或OR行
    for i, line in enumerate(lines):
        if outcome_markers.get(outcome, outcome) in line:
            # 往后找数值行
            for j in range(i, min(i+15, len(lines))):
                txt = lines[j]
                # 匹配SMD -0.27 [CI -0.34 to -0.21] 或 OR 1.67 [CI 1.49 to 1.87]
                smd_match = re.search(r'SMD\s+([-\d.]+)\s+\[CI\s+([-\d.]+)\s+to\s+([-\d.]+)\]', txt)
                or_match = re.search(r'OR\s+([\d.]+)\s+\[CI\s+([\d.]+)\s+to\s+([\d.]+)\]', txt)

                if smd_match:
                    result['effect_size'] = smd_match.group(1)
                    result['ci_lower'] = smd_match.group(2)
                    result['ci_upper'] = smd_match.group(3)
                    result['found'] = True
                elif or_match:
                    result['effect_size'] = or_match.group(1)
                    result['ci_lower'] = or_match.group(2)
                    result['ci_upper'] = or_match.group(3)
                    result['found'] = True

                # 提取研究数和人数（如24b、4872b）
                n_match = re.search(r'(\d+)\s*b?\s+RCT', txt)
                if n_match:
                    result['n_studies'] = n_match.group(1)

                pat_match = re.search(r'(\d{3,})\s*b?\s*$', txt)
                if pat_match:
                    result['n_patients'] = pat_match.group(1)

                # 提取GRADE等级
                if 'LOW' in txt and 'VERY' not in txt:
                    result['certainty'] = 'LOW'
                elif 'VERY LOW' in txt:
                    result['certainty'] = 'VERY LOW'
                elif 'MODERATE' in txt:
                    result['certainty'] = 'MODERATE'
                elif 'HIGH' in txt:
                    result['certainty'] = 'HIGH'

                # 检查Not available
                if 'Not available' in txt or 'not available' in txt:
                    result['found'] = True
                    result['certainty'] = 'NOT_AVAILABLE'
                    result['raw_text'] = 'Not available'
                    break

                if result['found']:
                    result['raw_text'] = txt.strip()
                    break

            if result['found']:
                break

    return result

def review_who_statement_detailed(stmt_id, drug, old_page, cache_dir):
    """WHO DEP1逐结局详细审核"""
    # 映射页码
    drug_pages = {
        '西酞普兰': (19,20), '艾司西酞普兰': (21,22), '氟西汀': (23,24),
        '帕罗西汀': (27,28), '舍曲林': (29,30), '阿米替林': (31,32),
        '合并SSRIs': (35,), '合并TCAs': (36,), '舍曲林': (48,)  # S0143产后
    }

    pages = drug_pages.get(drug, [])
    if old_page == '48':  # S0143特殊处理
        pages = (48,)

    full_text = []
    for pg in pages:
        txt_file = os.path.join(cache_dir, f'p{pg:04d}.txt')
        if os.path.exists(txt_file):
            with open(txt_file) as f:
                full_text.append((pg, f.read()))

    # 判断是GRADE表还是叙述（检查更多标志）
    combined_text = '\n'.join(txt for _, txt in full_text)
    is_grade_table = ('GRADE Table' in combined_text or
                      'Certainty assessment' in combined_text or
                      ('SMD' in combined_text and 'RCT' in combined_text))

    if is_grade_table:
        # 逐结局提取
        outcomes = ['change_symptoms', 'response', 'dropout_all', 'dropout_ae', 'suicide', 'qol']
        results = {}
        for outcome in outcomes:
            for pg, txt in full_text:
                cell = extract_grade_cell(txt, drug, outcome)
                if cell['found']:
                    results[outcome] = cell
                    break

        return {
            'type': 'GRADE_table',
            'pages': [p for p,_ in full_text],
            'outcomes': results,
            'status': '已完成逐结局提取'
        }
    else:
        # 叙述型证据
        combined = '\n'.join(txt for _, txt in full_text)
        return {
            'type': 'narrative',
            'pages': [p for p,_ in full_text],
            'excerpt': combined[:1000],
            'status': '已提取叙述'
        }

def review_other_guideline(stmt_id, source, drug, old_page, cache_dir):
    """其他指南审核，修复药名检索和表格读取"""
    # 中英文药名映射
    drug_names = {
        '舍曲林': ['sertraline','舍曲林'], '米氮平': ['mirtazapine','米氮平'],
        '氟西汀': ['fluoxetine','氟西汀'], '艾司西酞普兰': ['escitalopram','艾司西酞普兰'],
        '度洛西汀': ['duloxetine','度洛西汀'], '文拉法辛': ['venlafaxine','文拉法辛'],
        '去甲文拉法辛': ['desvenlafaxine','去甲文拉法辛'], '西酞普兰': ['citalopram','西酞普兰'],
        '帕罗西汀': ['paroxetine','帕罗西汀'], '安非他酮': ['bupropion','安非他酮'],
        '伏硫西汀': ['vortioxetine','伏硫西汀'], '奥氮平': ['olanzapine','奥氮平'],
        '喹硫平': ['quetiapine','喹硫平'], '阿立哌唑': ['aripiprazole','阿立哌唑'],
        '曲唑酮': ['trazodone','曲唑酮'], '阿米替林': ['amitriptyline','阿米替林']
    }

    # 提取基础药物名
    base_drug = re.sub(r'[（(].*?[）)]|＋.*|（.*', '', drug)
    search_names = drug_names.get(base_drug, [base_drug])

    # 解析页码范围
    pages = []
    if old_page:
        nums = re.findall(r'\d+', old_page)
        if len(nums) == 1:
            pages = [int(nums[0])]
        elif len(nums) >= 2:
            pages = list(range(int(nums[0]), int(nums[-1])+1))

    # 读取所有相关页面（不限前3页）
    found_pages = []
    for pg in pages:
        txt_file = os.path.join(cache_dir, f'p{pg:04d}.txt')
        if os.path.exists(txt_file):
            with open(txt_file) as f:
                txt = f.read()
                # 检查是否提及药物
                if any(name.lower() in txt.lower() for name in search_names):
                    found_pages.append((pg, txt))

    if not found_pages:
        return {
            'status': '未找到药物提及',
            'pages_checked': pages,
            'search_names': search_names
        }

    # 提取关键信息
    combined_text = '\n'.join(txt for _, txt in found_pages)

    return {
        'status': '已提取原文',
        'pages': [p for p, _ in found_pages],
        'excerpt': combined_text[:2000],
        'drug_mentions': sum(txt.lower().count(name.lower()) for _, txt in found_pages for name in search_names)
    }

if __name__ == '__main__':
    source_id = sys.argv[1]  # F026 or F003等
    output_file = sys.argv[2]

    # 读取该来源的所有陈述
    by_source = json.load(open('guideline_by_source.json'))
    stmt_ids = by_source[source_id]

    template = json.load(open('../review_extract_R1/指南与FDA独立复核包_20261125_R1/01_任务与回传/回传字段模板.json'))
    tables = {t['name']:t for t in template['tables']}
    stmts_table = tables['指南陈述626']
    headers = stmts_table['headers']

    # 建立ID到行的映射
    stmt_dict = {r[0]: r for r in stmts_table['rows'] if r[0]}

    # 确定缓存目录 - 使用绝对路径
    base_cache = '/Users/dxm/work/jingya/FDAcheck/review_work/text_cache'
    if source_id == 'F026':
        cache_dir = os.path.join(base_cache, 'guidelines/F026__WHO_mhGAP_2023_DEP1_Antidepressants_Evidence_Profile')
        is_who = True
    elif source_id == 'F038':
        cache_dir = os.path.join(base_cache, 'guidelines_ocr/F038')
        is_who = False
    else:
        # 查找匹配的缓存目录
        guideline_cache = os.path.join(base_cache, 'guidelines')
        if os.path.exists(guideline_cache):
            cache_dirs = [d for d in os.listdir(guideline_cache) if d.startswith(source_id)]
            if cache_dirs:
                cache_dir = os.path.join(guideline_cache, cache_dirs[0])
                is_who = False
            else:
                print(f"未找到{source_id}的缓存目录")
                sys.exit(1)
        else:
            print(f"缓存目录不存在: {guideline_cache}")
            sys.exit(1)

    results = []
    for stmt_id in stmt_ids:
        row = stmt_dict[stmt_id]
        drug = row[headers.index('候选药物或方案')]
        old_page = row[headers.index('旧定位页_待核实')]

        if is_who:
            result = review_who_statement_detailed(stmt_id, drug, old_page, cache_dir)
        else:
            result = review_other_guideline(stmt_id, source_id, drug, old_page, cache_dir)

        result['stmt_id'] = stmt_id
        result['source'] = source_id
        result['drug'] = drug
        results.append(result)

        if len(results) % 10 == 0:
            print(f"已审核{len(results)}/{len(stmt_ids)}")

    with open(output_file, 'w') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"完成{source_id}: {len(results)}条")
