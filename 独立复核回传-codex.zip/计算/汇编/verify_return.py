"""Validate extraction fingerprints, physical page bounds, all denominator sets and the nine-table return."""
from first import OUT,read,save,readset,sid
from guide_aligned import extensions
from collections import Counter,defaultdict
from pathlib import Path
import hashlib, re, json,sys,subprocess,argparse
import pypdfium2 as pdf
V=OUT/'验证';C=OUT/'计算';G=OUT/'第二阶段/指南比较'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(pkg):
    V.mkdir(exist_ok=True);errors=[];limits=[];seen={};evidence=set()
    for r in read(OUT/'第一阶段冻结清单.json')['files']:
        p=OUT/r['path']
        if not p.exists() or sha(p)!=r['sha256']:errors.append(['冻结',r['path']])
    raw=read(OUT/'最终回传表.json');rows={}
    for t in raw['tables']:
        rows[t['name']]=[dict(zip(t['headers'],v)) for v in t['rows']]
    files={}
    for sub in ['指南原文目录','FDA原文与电子资料目录']:
        for r in read(C/('输入/'+sub+'.json')):files[r['sha256']]=pkg/r['path']
    for d in (OUT/'新增原件',OUT/'phase1/guide_a/new_sources',OUT/'phase1/guide_b/new_sources'):
        for f in d.rglob('*'):
            if f.is_file() and not f.name.startswith('.'):files[sha(f)]=f
    def pages(text):
        if isinstance(text,int):return [text]
        if not text:return []
        text=str(text)
        if re.fullmatch(r'[\d\s、,，；;和及和页至到–—~\-]+',text):return list(map(int,re.findall(r'\d+',text)))
        return [int(n) for m in re.finditer(r'物理(?:页)?\s*(\d+(?:[–—~\-、，,]\d+)*)',text) for n in re.findall(r'\d+',m[1])]
    def check(id_,sh,pg):
        if sh not in files:errors.append([id_,'未知SHA',sh]);return
        path=files[sh]
        if sh not in seen:
            if not path.is_file() or sha(path)!=sh:errors.append([id_,'原件丢失或SHA不符',str(path)]);return
            if path.suffix.lower()=='.pdf':
                with pdf.PdfDocument(path) as doc:seen[sh]=len(doc)
            else:seen[sh]=None
        nums=pages(pg)
        if seen[sh] is not None:
            if nums:
                for n in nums:
                    if n<=0 or n>seen[sh]:errors.append([id_,sh,n,seen[sh]])
                    evidence.add((sh,n))
            else:limits.append([id_,'页段使用文字或另附文件定位',str(pg)])
    for s in rows['指南陈述626']:
        check(s['陈述ID'],s['原件SHA256'],s['准确物理页'])
    def walk(x,id_=''):
        if isinstance(x,dict):
            id_=x.get('id') or x.get('候选记录ID') or x.get('模型记录ID') or x.get('ft') or x.get('问题ID') or id_
            sh=x.get('sha256',x.get('SHA256',''))
            if re.fullmatch(r'[a-f0-9]{64}',str(sh)) and ('physical_page' in x or 'page' in x or '物理页' in x):
                check(id_,sh,x.get('physical_page',x.get('page',x.get('物理页'))))
            for v in x.values():walk(v,id_)
        elif isinstance(x,list):
            for y in x:walk(y,id_)
    for p in [OUT/'phase1/fda_a/field_evidence.json',OUT/'phase1/fda_b/field_evidence.json',OUT/'phase1/fda_a/candidates.json',OUT/'phase1/fda_b/mapping.json',C/'FDA/pediatric_25.json',OUT/'第二阶段/FDA定向补证附录.json',OUT/'第二阶段/艾司西酞普兰延长与维持两项补证.json',OUT/'第二阶段/Well84A具名FDA决定与设计.json',OUT/'第二阶段/PAR五项母试验定向补证.json',OUT/'第二阶段/FDA重点差异及纠偏.json',C/'FDA/adjudication_cases.json',OUT/'第二阶段/原文复看_裁决建议与逐条补证.json']:walk(read(p))
    label=read(OUT/'第二阶段/伏硫西汀标签总述原页核查.json')
    walk(label)
    for r in rows['FDA试验维度3674']:
        if r['核查状态']!='已完成':continue
        sh=re.findall(r'(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])',r['证据文件及SHA'])
        if len(set(sh))==1:check(r['模型记录ID']+'-'+r['维度'],sh[0],r['物理页与印刷页'])
        elif not sh:limits.append([r['模型记录ID']+'-'+r['维度'],'字段证据为交叉索引，另查逐项提取',r['证据文件及SHA']])
    dims=rows['FDA试验维度3674'];assert len(dims)==3674 and all(n==22 for n in Counter(x['模型记录ID'] for x in dims).values())
    tmpl=read(C/'输入/回传字段模板.json')
    oldids=[(r[0],r[5]) for r in tmpl['tables'][2]['rows'] if r[5]]
    assert len(oldids)==93 and sorted(oldids)==sorted((r['格ID'],r['历史ID']) for r in rows['指南418格'] if r['历史ID'])
    g=rows['指南418格'];st={x['陈述ID'] for x in rows['指南陈述626']}
    assert st=={f'S{i:04}' for i in range(1,627)}|{f'NEW-S{i:04}' for i in range(1,61+len(extensions()))}
    for x in g:
        for lab in ['研究','建议']:
            f='研究讨论' if lab=='研究' else '用药建议'
            if x[f+'_是或否或未确定']=='是':assert x[lab+'依据ID'] and set(x[lab+'依据ID'])<=st
    search=defaultdict(list)
    catalog={s['id']:s['sha256'] for s in read(C/'输入/指南原文目录.json')}
    for r in read(C/'guide/两药37份_命中与低文本页核对.json'):
        assert r['pattern'] and r['pages'] and catalog[r['source']]==r['sha256']
        search[r['drug']].append(r['source'])
    for p in G.glob('*/37源逐药命中与上下文.json'):
        for r in read(p):
            assert r['检索式'] and r['检索实际页数或DOCX内容单元'] and catalog[r['来源ID']]==r['SHA256']
            search[r['药物']].append(r['来源ID'])
    assert set(search)=={x['药物或方案'] for x in g}
    assert all(len(v)==37 and set(v)==set(catalog) for v in search.values())
    by_scope=defaultdict(set)
    for r in read(G/'现行有效陈述映射.json'):
        assert r['原文'] and r['印刷页及表段'] and r['适用限制'] and r['原件SHA256']==catalog[r['来源ID']]
        check(r['格ID']+' '+r['陈述ID'],r['原件SHA256'],r['物理页'])
        for f in ('研究讨论','用药建议'):
            if r[f]:by_scope[r['格ID'],f].add(r['陈述ID'])
    for x in g:
        for f,k in [('研究讨论','研究依据ID'),('用药建议','建议依据ID')]:
            assert set(x[k])==by_scope[x['格ID'],f]
            assert bool(x[k])==(x[f+'_是或否或未确定']=='是')
            if x[f+'_是或否或未确定']=='否':assert x['已审来源及页段']
    pending=read(OUT/'未完成ID与原因.json')
    assert all(r['ID'] and r['原因'] and r['需补'] for r in pending)
    for tbl in raw['tables'][:6]:
        expected={r[tbl['headers'][0]]+('-'+r['维度'] if tbl['name']=='FDA试验维度3674' else '') for r in rows[tbl['name']] if r['核查状态']!='已完成'}
        assert expected=={r['ID'] for r in pending if r['类型']==tbl['name']}
    ptr=read(C/'输入/FDA235接收字段_阶段二.json')
    assert sha(pkg/ptr['相对文件名'])==ptr['sha256']
    paired=read(OUT/'第二阶段/FDA235源表候选与接收原行对照.json')
    assert len(paired)==len(ptr['rows'])==235
    for r in paired:
        source=ptr['rows'][r['候选记录ID']]
        assert r['当前引用位置']==[ptr['相对文件名'],ptr['sha256'],source['工作表'],source['原表行']]
    stats=read(G/'既定口径计数.json')
    for gname,nr in [('全418',418),('历史93',93)]:
        x=stats[gname];assert sum(x[k] for k in ['both','research_only','advice_only','neither','uncertain','na'])==nr==sum(x['states'].values())
    grid=scored=0
    for name,p in [('纯独立_原文先审',C/'FDA/scenarios.json'),('现行口径_6项原表补证',C/'现行口径定向重算/19设定8360格.json'),('独立_补证后',C/'补证后独立/scenarios.json')]:
        a=read(p);b=read(C/('指南FDA对应/'+name+'_全部C或D.json'))
        expected={(r['scenario'],r['id']) for r in a if r['letter'].rstrip('*†‡') in ('C','D')}
        assert expected=={(r['方案'],r['FDA重算候选格ID']) for r in b} and len(b)==len(expected)
        assert len({(r['scenario'],r['id']) for r in a})==8360==len(a) and list(set(Counter(r['scenario'] for r in a).values()))==[440]
        main=[r for r in a if r['scenario']=='主设定' and (r.get('dim') or r.get('dimension')) not in ['D16a','D16b','D18']]
        assert len(main)==380 and len([r for r in main if r['letter'] not in ['—','n/a']])==320
        grid+=len(a);scored+=len(expected)
    control=read(C/'FDA/comparison_8360.json');ret=read(C/'现行口径定向重算/19设定8360格.json')
    base={(r['scenario'],r['id']):r for r in control}
    for r in ret:assert base[r['scenario'],r['id']]['verified_observations']==r['letter']
    # Recompute the FDA-named 84A contribution using the independent aggregation against the isolated received replay.
    sys.path.insert(0,str(C/'FDA'))
    from compare import baseline_items,update_support,letter_from
    from calculate import effective
    from verify import read_back_grade
    trials=read(C/'FDA/independent_inputs.json');by=defaultdict(dict)
    for t in trials:by[t['drug'],t['regimen']][t['trial']]=t
    options={sc:opts for sc,_,opts in read(C/'输入/维度与设定定义.json')['FDA_scenarios']}
    final_models={t['id']:t for t in read(C/'补证后独立/independent_inputs.json')}
    for cell in read(C/'补证后独立/scenarios.json'):
        assert read_back_grade(cell,options[cell['scenario']],final_models)==cell['letter']
    upgraded=next(t for t in read(C/'补证后独立/independent_inputs.json') if t['id']=='FT0100')
    named={(r['scenario'],r['id']):r for r in read(C/'现行口径_含84A具名FDA审评/19设定8360格.json')}
    assert len(named)==8360
    ww=[]
    for original,c in zip(read(C/'FDA/received_inputs.json'),control):
        sc,drug,reg,dim,_,old,_,votes=original
        assert (sc,drug,reg,dim)==(c['scenario'],c['drug'],c['regimen'],c['dimension'])
        want=c['verified_observations'];flag=c['verified_qualifier']
        if drug=='安非他酮' and dim!='D16a':
            opt=options[sc];items=[v for v in baseline_items(votes,by[drug,reg]) if v[0]!='FT0100']
            code,tier,rtype=effective(upgraded,dim,opt)
            items.append(['FT0100','pos',code,upgraded['parent'],rtype])
            want,flag=letter_from(items,opt,dim,old)
        row=named[sc,c['id']]
        assert row['letter']==want,(sc,c['id'],row['letter'],want)
        if want!=c['verified_observations'] or drug=='安非他酮' and flag!=c['verified_qualifier']:
            ww.append(dict(设定=sc,格ID=c['id'],六字段字母=c['verified_observations'],补84A字母=want,六字段注脚=c['verified_qualifier'],补84A注脚=flag))
    save(V/'84A独立聚合与固定引擎对照.json',dict(逐字母一致数=len(named),与六字段层比较的字母或注脚变动=ww))
    label_trial=next(t for t in read(C/'补证后独立/independent_inputs.json') if t['id']==label['ft'])
    label_rows=[]
    for original,c in zip(read(C/'FDA/received_inputs.json'),control):
        sc,drug,reg,dim,_,old,_,votes=original
        if drug!='伏硫西汀' or dim not in {u['dimension'] for u in label['updates']}:continue
        items=[v for v in baseline_items(votes,by[drug,reg]) if v[0]!=label['ft']]
        code,_,rtype=effective(label_trial,dim,options[sc])
        if options[sc]['label'] and code!='?':items.append([label['ft'],'pool',code,None,rtype])
        letter,flag=letter_from(items,options[sc],dim,old)
        assert letter==named[sc,c['id']]['letter'] and flag==c['verified_qualifier']
        label_rows.append(dict(设定=sc,格ID=c['id'],标签补入后的字母=letter,注脚=flag,项目层代码=code))
    assert len(label_rows)==57
    save(V/'伏硫西汀标签三维与现行重算.json',dict(比较='19设定 × 3维度；仅调整FT0092标签项目贡献，其余逐格同现行84A层。',字母和注脚异动=0,rows=label_rows))
    for name,p in [('现行口径_加84A',C/'现行口径_含84A具名FDA审评/19设定8360格.json'),('方法敏感性_PAR支持性角色',C/'PAR支持性角色敏感性/19设定8360格.json')]:
        a=read(p);matches=read(C/('指南FDA对应/'+name+'_全部C或D.json'))
        assert {(r['scenario'],r['id']) for r in a if r['letter'] in ('C','D')}=={(r['方案'],r['FDA重算候选格ID']) for r in matches}
    checkproc=subprocess.run([sys.executable,str(C/'输入/核验回传.py'),str(OUT/'最终回传表.json')],capture_output=True,text=True)
    result=json.loads(checkproc.stdout);save(V/'回传结构.json',result)
    assert checkproc.returncode==0 and not result['structural_issues']
    assert len({q['id'] for q in read(OUT/'第二阶段/FDA问题逐项.json')})==201
    report=dict(原包路径=str(pkg),冻结条数=len(read(OUT/'第一阶段冻结清单.json')['files']),实际重新比对内容SHA原件数=len(seen),检验到不同PDF物理页数=len(evidence),
                页界校验含义='检查引用页在相应PDF范围，未自动判断原文语义。电子注册/HTML/DOCX使用表段字段；多文件混合或纯文字页段留人工复核。',
                文字或复合定位例外数=len(limits),指南逐药检索资料对=sum(map(len,search.values())),FDA候选配对原表行数=len(paired),三层已核候选格=grid,三层按设定重新对应C_D格数=scored,六字段独立及原版引擎逐字母一致=8360,
                补证后独立输入重读原始贡献复判一致格数=8360,接收星号例外=read(C/'FDA/comparison_summary.json')['signed_display_discrepancies'],错误=errors,通过=not errors)
    save(V/'原件定位与计数.json',report);save(V/'页界检查文字定位.json',limits)
    print(json.dumps(report,ensure_ascii=False))
    if errors:raise SystemExit(1)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--package',type=Path,default=OUT.parent);main(parser.parse_args().package.resolve())
