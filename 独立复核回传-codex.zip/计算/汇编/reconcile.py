"""Record the post-freeze source review separately; facts verified on original rendered pages."""
from first import OUT,read,save
from pathlib import Path
from collections import Counter
C=read(OUT/'计算/输入/FDA原文与电子资料目录.json')
catalog=lambda k:next(a for a in C if a['sha256'].startswith(k))
edits=[]
def item(ft,d,code,sub,lev,key,p,printloc,quote,why,act):
 src=catalog(key)
 edits.append(dict(ft=ft,dimension=d,code=code,r_type=sub,level=lev,source=src['path'],sha256=src['sha256'],page=p,locator=printloc,quote=quote,why=why,apply_to_retained=act))
for ft,n,printloc,excerpt in [('FT0040',56,'印8 表3.1','DVS SR 200 to 400 mg (n=117) … Range … 18.0 to 73.0'),('FT0041',57,'印9 表3.2','DVS SR 200–400 mg (n=110) … Min-max … 18.0–68.0'),('FT0042',58,'印10 表3.3','DVS SR 200–400 mg (n=117) … Min, Max … 19.0, 70.0'),('FT0153',56,'印8 表3.1','Venlafaxine ER 75 to 150 mg (n=127) … Range … 23.0 to 70.0'),('FT0154',57,'印9 表3.2','ven ER 150–225 mg (n=115) … Min-max … 21.0–73.0')]:
 item(ft,'D16b','R','doc','1','bf99',n,printloc,excerpt,'FDA统计审评分开报告本药/参照药ITT实际年龄；≥65至少一人，不能确定人数、代表性或亚组疗效。',True)
item('FT0149','D11','R','doc','1','63c8',60,'印19 表C-2.8.2后/基线共病','Unspecified anxiety was present in 6% of subjects in the citalopram group compared to 3% and 1% in the placebo and escitalopram groups respectively.','99003参照西酞普兰组自身6%；适用S6。',True)
item('FT0032','D11','R','doc','1','63c8',60,'印19 表C-2.8.2后/基线共病','6% of subjects in the citalopram group compared to 3% and 1% in the placebo and escitalopram groups respectively.','99003本药艾司西酞普兰组1%，既有R获支持。',False)
item('FT0031','D11','?','','1','63c8',55,'印14 表C-1.8.2后/基线共病','Unspecified anxiety was present in 12% of subjects in the placebo group and 7% of subjects in the citalopram group','99001同页表头及下一节用Escitalopram；原句却印citalopram，保存文本冲突，暂不更动v43，查CSR。',False)
for ft,n,maxscore,nn,tab in [('FT0061',9,34,184,3),('FT0062',17,31,191,14)]:
 item(ft,'D15','R','doc','1','f922',n,'印'+str(n-1)+' 表'+str(tab),'HAM-D17 Total Score … Aripiprazole (N='+str(nn)+') … Min-Max 14.0–'+str(maxscore)+'.0','阶段B结束进入随机增效，最低14。原文先审所摘初期HAMD≥18属较早阶段。原A/R保留；单列S11中8–13的定义。',False)
for ft,k,p,pl,qt in [('FT0090','dc9d',5,'2065','Vortioxetine 15 mg … 21–75; Vortioxetine 20 mg … 19–72'),('FT0091','1a2e',4,'578','Vortioxetine 10 mg … 18–68; Vortioxetine 20 mg … 18–75'),('FT0096','d0ce',5,'587','Vortioxetine 10 mg … 20–74; Vortioxetine 15 mg … 18–72'),('FT0138','dc9d',5,'2065','Duloxetine 60 mg (n=152) … Range … 19–72')]:
 item(ft,'D16b','R','doc','3a',k,p,'期刊'+pl+'，表1',qt,'本药/参照臂实际随机组最高年龄可证明纳入，3a；不能当成FDA，限允许3a的设定。',False)
item('FT0016','D17','R','design','1','9f5a',80,'印7 §5.1.3.2','this is a negative study for mirtazapine and positive study for the active control','003-021：FAD0020第一阶段摘要中本药和参照药均不支持的措辞需纠正，自己的单药阴性不变，FREF0013阿米替林参照LOCF阳性。',False)
for ft in ['FT0035','FT0036','FT0038','FT0039','FT0040','FT0041','FT0042']:
 item(ft,'D18','X','','1','4c5a',76,'印26 §6.1','The indication sought in each of the seven placebo-controlled trials is the acute treatment of Major Depressive Disorder (single or recurrent episode, without psychotic features) in adults.','另查分卷二附录10.3物理64/印125，入选为门诊单相无精神病性。并列7项，不外推333、332或儿少。',False)
# Appendix is explicitly a joint description with protocol exceptions; do not infer silent N codes from it.
shared=[
 ('D01','P',64,'Current (within 12 months of baseline) DSM-IV-defined: a) psychoactive substance abuse or dependence (including alcohol)','基线前12月；含酒精。'),
 ('D03','P',64,'Current (within 12 months of baseline) … c) obsessive-compulsive, or psychotic disorder.','12月内OCD；不能判为终身排除。'),
 ('D07','P',64,'Personality disorder … severe enough to compromise the investigator’s ability to evaluate the efficacy and safety of the test article.','须严重到损害研究者评价能力。'),
 ('D09','P',64,'Significant risk of suicide at study entry or during the study based on clinical judgment; and/or a score ≥ 5 on the suicidality item of the MADRS scale.','进入或研究期间显著风险，或MADRS自杀项≥5；不能排所有既往未遂。'),
 ('D11','P',64,'Current DSM-IV-defined anxiety disorder that was considered by the investigator as being primary, causing a higher degree of distress or impairment than MDD.','现症、主要且影响超过MDD；另列306/308/309的Covi与Raskin条件。'),
 ('D10','P',65,'History or presence of clinically important hepatic or renal disease or other medical disease that might compromise the study or be detrimental to the subject','包括近6月心梗、3月内重大急病、近2年肿瘤（部分皮癌例外）；不能扩大成所有疾病。')]
for ft in ['FT0035','FT0036','FT0038','FT0039','FT0040','FT0041','FT0042']:
 for d,code,n,qt,why in shared:
  item(ft,d,code,'','1','39ea',n,'印'+str(n+61)+' 附录10.3 Subject Selection Criteria',qt,why+' 七项共用审评概述，个别实施修订须另核。',False)
out=OUT/'第二阶段';save(out/'原文复看_裁决建议与逐条补证.json',edits)
# Identify which of the raw code differences survive R subtype normalization and tier checks.
rows=read(out/'FDA_3674维度逐项对照.json');supp={(e['ft'],e['dimension']):e for e in edits}
for r in rows:
 old='N' if r['v43代码']=='R' and r['v43_R类型']=='permit' else r['v43代码']
 new='N' if r['独立代码']=='R' and '允许' in str(r['独立R类型']) else r['独立代码']
 r['旧按R类型实算']=old;r['独立按R类型实算']=new
 e=supp.get((r['模型记录ID'],r['维度']))
 if e:
  r['复看']=e;r['处理']='原证支持定向修正' if e['apply_to_retained'] else '核对原页；具体处理见复看说明'
 elif not old:r['处理']='按儿少源表独立重建'
 elif new=='?':r['处理']='材料未能独立建立；不覆盖旧判，不算查无'
 elif new==old:r['处理']='按实际参与聚合的代码相同'
 elif r['原文层级'] in ['3b','注册4','注册4（新增）']:r['处理']='注册记录另列；只在来源开关允许的设定使用'
 elif r['维度'] in ['D03','D04a','D05','D14'] and ('现症' in r['限制'] or 'Presence' in r['v43依据'] or '两个足量' in r['限制']):r['处理']='既定时间/疗程仅部分排除，保留v43，初判X不进纠错版'
 else:r['处理']='保留两侧证据及未决；研究者裁决范围、时态或完整度'
save(out/'FDA_3674复看处置.json',rows)
save(out/'FDA逐维处置计数.json',dict(Counter(r['处理'] for r in rows)))
