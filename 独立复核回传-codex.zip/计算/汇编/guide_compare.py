"""Pair the independent source extracts and mappings with the v4 statement, context and grid IDs."""
from first import OUT,read,save,readset,sid
from collections import defaultdict,Counter
from openpyxl import load_workbook
import re
def flag(v):return '是' if v in [True,1,'是','1'] else '否' if v in [False,0,'否','0'] else '未确定'
def compare():
 p=next(OUT.parent.glob('04*/指南*/指南覆盖_逐格数据*.json'));b=read(p)
 old={r['id']:r for r in b['statements']};decs={r['id']:r for r in b['decisions']}
 new={sid(r['陈述ID']):r for r in readset('guide','statements')}
 by=defaultdict(list)
 for r in readset('guide','coverage'):by[sid(r['陈述ID'])].append(r)
 meta={r['id']:r for r in b['records']}
 out=OUT/'第二阶段/指南比较';out.mkdir(exist_ok=True)
 pairs=[]
 for i,r in old.items():
  n=new[i];dec=decs[i]
  rr=n['研究讨论判定'];aa=n['用药建议判定']
  fields=[('物理页',r['pages'],n['准确物理页']),('印刷页或表段',r['printed'],n['印刷页及表段']),('人群',r['population'],n['具体人群及年龄']),('阶段与方案',r['stage'],n['治疗阶段及联合方案']),('证据等级',r['evidence_grade'],n['原证据等级']),('原推荐强度',r['recommendation'],n['原推荐强度']),('具名方案',r['drug'],n['候选药物或方案']),('原文',r['quote'],n['独立原文摘录']),('释义',r['translation'],n['中文释义'])]
  pairs.append(dict(陈述ID=i,来源ID=n['来源ID'],核查状态=n['核查状态'],现版研究建议=[flag(dec['research']),flag(dec['advice'])],独立研究建议=[rr,aa],双变量初筛=('相符' if [rr,aa]==[flag(dec['research']),flag(dec['advice'])] else '取值不同，另核作用层与适用性'),逐字段并列=[dict(字段=f,v4=x,原文先审=y) for f,x,y in fields],适用与处理=n['方向与限制'],原件=n.get('来源文件',n.get('source_path','')),SHA256=n.get('SHA256',n.get('sha256','')),页定位不同=set(map(str,r['pages']))!=set(re.findall(r'\d+',str(n['准确物理页'])))))
 save(out/'626陈述逐字段.json',pairs)
 save(out/'新增60候选与旧出处.json',[dict(ID=i,本地ID=n['陈述ID'],来源=n['来源ID'],摘录=n['独立原文摘录'],页=n['准确物理页'],段=n['印刷页及表段'],药物=n['候选药物或方案'],旧同来源同页陈述=[j for j,r in old.items() if r['source']==n['来源ID'] and set(map(str,r['pages']))&set(re.findall(r'\d+',str(n['准确物理页'])))],说明='候选包括原陈述拆分、同页另项与新增定位。仅有重叠页并不能证明重复。') for i,n in new.items() if i not in old])
 w=load_workbook(next(OUT.parent.glob('04*/指南*/指南覆盖与*.xlsx')),read_only=True,data_only=True)
 v=w['陈述明细'].values;heads=next(v);ctx=[]
 for row in v:
  r=dict(zip(heads,row));i=r['陈述ID'];d=r['情境代码'];n=new[i]
  elig=[x for x in by[i] if x['格ID'] in meta and meta[x['格ID']]['dimension']==d]
  ctx.append(dict(行ID=r['行ID'],陈述ID=i,旧情境=d,旧药物方案=r['药物或完整方案'],旧人群=r['具体人群/亚组'],旧治疗阶段=r['治疗阶段'],独立同维度格=[dict(格=x['格ID'],研究=flag(x.get('研究讨论',x.get('研究讨论判定'))),建议=flag(x.get('用药建议',x.get('用药建议判定')))) for x in elig],情境核对='找到同维度映射；须按完整方案、人群和时序读' if elig else '本次未独立建立同维度映射；含类别/范围外陈述或待查，不能自动撤销',独立原句=n['独立原文摘录'],独立范围=n['方向与限制'],文件=n.get('来源文件',n.get('source_path')),sha256=n.get('SHA256',n.get('sha256')),物理页=n['准确物理页'],表段=n['印刷页及表段']))
 w.close();assert len(ctx)==749 and len({r['行ID'] for r in ctx})==749
 save(out/'749情境逐行.json',ctx)
 cp=OUT/'计算/guide/guide_cells.json'
 counts=dict(陈述=len(pairs),属性取值初筛=dict(Counter(r['双变量初筛'] for r in pairs)),情境=len(ctx),情境对应=dict(Counter(r['情境核对'] for r in ctx)),历史v4=b['stats'])
 if cp.exists():
  a=read(cp);diff=[]
  for n in a:
   m=meta[n['格ID']]
   x=[n.get(k) for k in ['研究讨论_是或否或未确定','用药建议_是或否或未确定']]
   y=[flag(m['research']),flag(m['advice'])] if m['state']!='结构不适用' else ['不适用','不适用']
   diff.append(dict(格ID=m['id'],历史ID=m['original_id'],药物=m['drug'],维度=m['dimension'],v4=y,独立=x,改变的确定阳性=[k for k,(x1,y1) in zip(['研究','建议'],zip(x,y)) if x1=='是' and y1=='否'],v4陈述=[m['research_ids'],m['advice_ids']],独立陈述=n.get('陈述依据ID'),未决=n.get('未决原因',''),独立限制=n.get('具体人群方案阶段限制','')))
  save(out/'418逐格与历史93对照.json',diff);counts['418取值组合']=dict(Counter(str(r['v4'])+' → '+str(r['独立']) for r in diff))
 save(out/'对照范围.json',counts)
if __name__=='__main__':compare()
