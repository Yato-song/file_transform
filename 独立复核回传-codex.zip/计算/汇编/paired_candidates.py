"""Pair the 235 received trial rows with the frozen extraction and final source corrections."""
from first import OUT,read,save
from pathlib import Path
from collections import Counter
import sys,hashlib
C=OUT/'计算/输入';S=OUT/'第二阶段'
def rows(table):
    return [dict(zip(table['headers'],r)) for r in table['rows']]
def extract(root):
    from openpyxl import load_workbook
    p=next(root.glob('04*/FDA*/FDA证据总表*.xlsx'))
    w=load_workbook(p,read_only=True,data_only=True)
    cols={'成人与老年试验':[0,1,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,21,24,93,94,95],
          '儿少试验':[0,1,2,3,4,5,6,7,8,9,10,11,14,15,18,19,20,21,32,33,34],
          '扩展参照臂':[0,1,2,3,4,5,6,7,8,9,31]}
    data={}
    for name in cols:
        rr=iter(w[name].values);header=next(rr)
        data[name]=[{header[j]:v[j] for j in cols[name] if j<len(v) and j<len(header) and v[j] is not None} for v in rr]
    candidates=rows(read(C/'回传字段模板.json')['tables'][3])
    store={}
    for r in candidates:
        worksheet=r['来源工作表'];n=r['原表行']
        data_row=data[worksheet][n-2]
        assert data_row.get('药物',data_row.get('参照药'))==r['药物']
        store[r['候选记录ID']]=dict(工作表=worksheet,原表行=n,接收字段=data_row)
    save(C/'FDA235接收字段_阶段二.json',dict(相对文件名=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rows=store))
def main():
    pointer=read(C/'FDA235接收字段_阶段二.json')
    frozen={r['候选记录ID']:r for r in rows(read(OUT/'phase1/原文先审回传.json')['tables'][3])}
    final=rows(read(OUT/'最终回传表.json')['tables'][3])
    dims=rows(read(OUT/'最终回传表.json')['tables'][4])
    model={}
    for t in read(OUT/'计算/补证后独立/independent_inputs.json'):
        counts=Counter(d['核查状态'] for d in dims if d['模型记录ID']==t['id'])
        model.setdefault(t['candidate'],[]).append(dict(模型ID=t['id'],母试验=t['parent'],角色=t['role'],维度核查状态=dict(counts)))
    fields=['确认母试验ID','比较臂或分层ID','主要结局与时点','分析集与人数','FDA判断原文及页码','纳入原文及页码','排除原文及页码','证据文件及SHA','来源级别及理由']
    out=[]
    for r in final:
        k=r['候选记录ID'];base=pointer['rows'][k];old=frozen[k]
        out.append(dict(候选记录ID=k,当前引用位置=[pointer['相对文件名'],pointer['sha256'],base['工作表'],base['原表行']],接收判断与纳排字段=base['接收字段'],
                        第一阶段独立提取=old,第二阶段独立返回=r,相对冻结实际调整的字段=[key for key,val in r.items() if val!=old[key]],
                        第二阶段未单独提取或未确认字段=[key for key in fields if not r[key]],关联建模记录=model.get(k,[]),
                        角色比较说明='逐试验对照保留接收方与独立原句。具体可计算代码、审核者分歧和母试验去重见模型及试验引言，不能把字符串差异直接判断为临床差异。'))
    assert len(out)==len(frozen)==len(pointer['rows'])==235 and sorted(frozen)==sorted(r['候选记录ID'] for r in out)
    save(S/'FDA235源表候选与接收原行对照.json',out)
if __name__=='__main__':
    if len(sys.argv)>1:extract(Path(sys.argv[1]).resolve())
    main()
