"""Stage-two alignment with the prespecified v4 source version, index role, population and structural boundaries."""
from first import OUT,read,save,readset,sid
from collections import defaultdict,Counter
from copy import deepcopy
from functools import cache
G=OUT/'计算/guide';O=OUT/'第二阶段/指南比较'
R='研究讨论_是或否或未确定';A='用药建议_是或否或未确定'
EXT=O/'扩展阴性核查'
PASS_NAMES=('扩展阴性核查','后续逐药复看A','后续逐药复看B','后续逐药复看C')
def extensions():
 out=[]
 for name in PASS_NAMES:
  path=O/name/'新增具名陈述及来源冲突.json'
  if path.exists():out+=read(path)
  cross=O/name/'另外两药具名D14交叉候选.json'
  if cross.exists():out+=read(cross)
 return out

@cache
def ext_ids():
 ids={v['候选陈述ID']:f'NEW-S{n:04d}' for n,v in enumerate(extensions(),61)}
 assert len(ids)==len(extensions())
 return ids
def extid(value):return ext_ids().get(value,sid(value))
def allowed(k,i):
 if k=='M296' and i=='S0058':return False
 return not(k=="M081" and i==extid("CX-S0006"))

def extend_cells(cells,links,statements):
 decisions=[]
 byid={c['格ID']:c for c in cells}
 new_statements={extid(v['候选陈述ID']):v for v in extensions()}
 for name in PASS_NAMES:
  base=O/name;path=base/'逐格判定.json'
  if not path.exists():continue
  reviewed=read(path);assert (base/'37源逐药命中与上下文.json').is_file()
  for v in reviewed:
   k=v['格ID'];c=byid[k]
   if c['结构适用性']=='不适用':
    assert k in ('M059','M087')
    continue
   limits=v['限制'];scope=v['页段与词表']
   assert limits and scope
   detail={}
   for field,flag,ref in [(R,'研究讨论','研究依据ID'),(A,'用药建议','建议依据ID')]:
    before=c[field];opinion=v[flag]
    assert opinion in ('是','否','未确定')
    refs=[]
    for source_id in v[ref]:
     i=extid(source_id)
     if not allowed(k,i):continue
     # Parallel reviewers may have seen provisional NEW numbering. Restore by local candidate ID.
     if i.startswith('NEW-S') and int(i[5:])>60 and i==source_id:
      approved=any(r['陈述ID']==i and r[flag] for r in links[k])
      if not approved:continue
     if i not in refs:refs.append(i)
    for i in refs if opinion=='是' else []:
     if any(r['陈述ID']==i and r[flag] for r in links[k]):continue
     # A newly assigned positive must point to a clinical statement in the return.
     if i in new_statements:
      z=new_statements[i]
      src,pg,section,quote,sha=(z[key] for key in ['来源ID','物理页','印刷页/表段','独立核得原文','原件SHA256'])
     else:
      z=statements[i]
      src,pg,section,quote=(z[key] for key in ['来源ID','准确物理页','印刷页及表段','独立原文摘录'])
      sha=z.get('SHA256') or z.get('sha256')
     assert sha and quote and (pg or section)
     links[k].append(dict(格ID=k,陈述ID=i,分组原ID=i,来源ID=src,研究讨论=flag=='研究讨论',用药建议=flag=='用药建议',药物或方案=c['药物或方案'],维度=c['维度'],物理页=pg,印刷页及表段=section,原文=quote,原件SHA256=sha,适用限制=limits,陈述核查状态='第二阶段逐药复看'))
    anchors=list(dict.fromkeys(r['陈述ID'] for r in links[k] if r[flag]))
    if opinion=='是':assert refs and set(refs)<=set(anchors), (k,ref,refs)
    after='是' if anchors else opinion
    decision='具名页证支持' if anchors else '依逐药复看范围判定'
    if k=='M236' and flag=='研究讨论':
     decision='S0264明确是≥60岁非缓解患者文拉法辛XR加阿立哌唑的具名研究。指南原规则允许有亚组限制的平行收录；香港18–64岁中60–64实际分母未知。'
    elif anchors and opinion!='是':
     decision='存在单条阳性原文与逐药判断分歧；见并列依据及逐格合并记录，由研究者审定。'
    detail[flag]=dict(合并前=before,逐药判定=opinion,最终=after,逐药依据=refs,最终依据=anchors,理由=decision)
    c[field]=after;c[ref]=anchors
   c['陈述依据ID']='，'.join(dict.fromkeys(c['研究依据ID']+c['建议依据ID']))
   c['具体人群方案阶段限制']=' ｜ '.join(dict.fromkeys([*(r['适用限制'] for r in links[k]),limits]))
   c['已审来源及页段']='第二阶段/指南比较/'+name+'。'+scope
   for r in links[k]:
    locator=f"{r['来源ID']} 物理{r['物理页']} {r['印刷页及表段']}"
    if locator not in c['已审来源及页段']:c['已审来源及页段']+=' ｜ '+locator
   c['核查状态']='已核未决' if '未确定' in (c[R],c[A]) else '已完成'
   c['未决原因']=limits if c['核查状态']=='已核未决' else ''
   decisions.append(dict(格ID=k,来源组=name,双侧处置=detail,限制=limits,检索范围=scope))
 assert len(set(v['格ID'] for v in decisions))==len(decisions)
 save(O/'逐药扩展合并处置.json',decisions)
def run():
 statements={sid(r['陈述ID']):r for r in readset('guide','statements')}
 raw=read(G/'guide_cell_links.json');links=defaultdict(list);log=[]
 cells=read(G/'guide_cells.json')
 corrections={(c['格ID'],c['陈述ID']):c for c in read(O/'交叉_其他映射问题.json')}
 for hit in raw:
  r=dict(hit);i,f,d=r['陈述ID'],r['来源ID'],r['维度'];s=statements[i];reason=''
  if f=='F007' or (f=='F006' and (d in ['D08a','D08b'] or '孕期' in s['具体人群及年龄'] or '哺乳' in s['具体人群及年龄'])):
   reason='CANMAT重叠适应证已由2023成人或2024围产专章替代。旧表仍可审阅；不进入现行覆盖。';r.update(研究讨论=False,用药建议=False)
  elif f=='F004' and d in ['D08a','D08b'] and s['原证据等级'].endswith('Level 4') and r['研究讨论']:
   reason='当前来源表列具名药、非围产疗效和本情境Level 4，未随该行提供目标药目标亚组治疗研究；可执行用药线次保留。';r['研究讨论']=False
  elif d in ['D13a','D13b'] and (i in {'S0170','S0171','S0273','S0235','S0345','NEW-S0022'} or r['适用限制'].startswith(('伴精神病性症状','精神病性抑郁'))):
   reason='精神病性抑郁特定联合或缓解后维持，不转计非精神病性联合格。';r.update(研究讨论=False,用药建议=False)
  elif d in ['D01','D02','D03','D04a','D04b','D05','D06','D07','D10','D11'] and i in {'S0020','S0207','S0208'}:
   reason='儿少抑郁共病研究仅保留儿童/青少年适用范围，不转成人共病格。';r.update(研究讨论=False,用药建议=False)
  if r['格ID']=='M296' and i=='S0058':
   r['研究讨论']=False;reason='PPD试验58人，摘要未确认正在哺乳；哺乳表脚注并不提供试验母亲实际喂养记录。'
  fix=corrections.get((r['格ID'],i))
  if fix:
   reason=fix['理由'];r['研究讨论']=bool(fix['保留研究']);r['用药建议']=bool(fix['保留建议'])
   r.update(原文=fix['证明'],印刷页及表段=fix['原页'],适用限制=hit['适用限制']+' '+fix['理由'])
  if reason:log.append(dict(**hit,处理=reason,复看研究=r['研究讨论'],复看建议=r['用药建议']))
  if r['研究讨论'] or r['用药建议']:links[r['格ID']].append(r)
 # Both components are named for D18 in the v4 rule and source, with the combination explicitly retained.
 x=deepcopy(next(v for v in raw if v['陈述ID']=='S0169' and v['格ID']=='M330'))
 x.update(格ID='M110',药物或方案='氟西汀',研究讨论=True,用药建议=True,物理页='213–214',印刷页及表段='印191–192，推荐框、疗效比较',原文='氟西汀＋奥氮平（1A），文拉法辛＋喹硫平（1A）的证据较为充分。',适用限制='伴精神病性特征时明确两药联合。此索引仅适用于该具名组合，单药和HGIE起始条件均须另查。')
 links['M110'].append(x)
 by_key={c['格ID']:c for c in cells}
 for v in extensions():
  for k in v['格ID']:
   if not allowed(k,extid(v['候选陈述ID'])):
    log.append(dict(格ID=k,陈述ID=extid(v['候选陈述ID']),原文=v['独立核得原文'],处理='Wijkstra 2010仅精神病性抑郁组合，按既定口径计M088的D18，勿转一般合用D13a。'));continue
   research=v['研究讨论']=='是';advice=v['用药建议']=='是'
   if not(research or advice):continue
   c=by_key[k];links[k].append(dict(格ID=k,陈述ID=extid(v['候选陈述ID']),分组原ID=v['候选陈述ID'],来源ID=v['来源ID'],研究讨论=research,用药建议=advice,药物或方案=c['药物或方案'],维度=c['维度'],物理页=v['物理页'],印刷页及表段=v['印刷页/表段'],原文=v['独立核得原文'],原件SHA256=v['原件SHA256'],适用限制=v['适用限制'],陈述核查状态='第二阶段原页复看'))
 for c in cells:
  k=c['格ID'];ls=links[k]
  if k in ['M059','M087']:continue
  if k=='M060':
   c['结构适用性']='适用';c[R]=c[A]='未确定';c['核查状态']='已核未决';c['未决原因']='v4规则仅两格结构不适用。保留该格并待研究者裁决；原文先审提出的第三处结构异议另列。';c['具体人群方案阶段限制']='喹硫平单药 × 合用其他抗精神病药/情感稳定剂；固定G编号保留。';c['已审来源及页段']='既定结构见v4工作簿“口径与规则”；原件有无对应陈述未完成阴性确认。'
  for field,flag,ids in [(R,'研究讨论','研究依据ID'),(A,'用药建议','建议依据ID')]:
   anchors=list(dict.fromkeys(r['陈述ID'] for r in ls if r[flag]));c[ids]=anchors
   if anchors:c[field]='是'
   elif c[field]=='是':c[field]='未确定';c['核查状态']='已核未决';c['未决原因']='仅有历史来源或范围受限依据，仍需在现行规定来源中排查直接依据。'
  c['陈述依据ID']='，'.join(dict.fromkeys(c['研究依据ID']+c['建议依据ID']))
  if k not in ['M060'] and ls:
   c['具体人群方案阶段限制']=' ｜ '.join(dict.fromkeys(r['适用限制'] for r in ls))
  if '未确定' not in (c[R],c[A]):
   c['核查状态']='已完成';c['未决原因']=''
  elif any(q['格ID']==k and q['保留研究'] is None for q in corrections.values()):
   c['核查状态']='已核未决';c['未决原因']='原文能证明用药建议；研究讨论的具体情境或疗效评价未确认，须裁决。'
  if k=='M110':
   c['核查状态']='已完成';c['未决原因']=''
   c['已审来源及页段']='F038 物理213–214，印191–192。精神病性抑郁推荐框与下一页具名比较。'
  c['已审来源及页段']=c['已审来源及页段'].replace('物理物理','物理')
  c.pop('原范围证据明细',None)
 extend_cells(cells,links,statements)
 def counts(g):
  by=Counter((c[R],c[A]) for c in g);return dict(total=len(g),both=by['是','是'],research_only=by['是','否'],advice_only=by['否','是'],neither=by['否','否'],uncertain=sum(n for k,n in by.items() if '未确定' in k),na=by['不适用','不适用'],research=sum(c[R]=='是' for c in g),advice=sum(c[A]=='是' for c in g),states={','.join(k):n for k,n in by.items()})
 n={'全418':counts(cells),'历史93':counts([c for c in cells if c['历史ID']])}
 assert n['全418']['na']==2 and n['历史93']['total']==93
 save(O/'既定口径418格.json',cells);save(O/'既定口径计数.json',n);save(O/'版本与直接性_逐映射复看.json',log)
 save(O/'既定口径_历史93格.json',sorted((c for c in cells if c['历史ID']),key=lambda c:c['历史ID']))
 save(O/'现行有效陈述映射.json',[r for group in links.values() for r in group])
if __name__=='__main__':run()
