"""Compare the frozen extraction with the documented v43 trial-level input, keyed on stable template IDs."""
from first import OUT, read,save,readset
from pathlib import Path
from collections import Counter
def compare():
 base=next(OUT.parent.glob('05*/04_recompute/engine/recalculated.json'))
 v=read(base)
 order=read(OUT/'计算/输入/回传字段模板.json')['tables'][4]['rows'][::22]
 idx={}
 for t,old in zip(order,v['all_trials']+v['s5_trials']):
  assert (t[1],t[2] or '',t[3])==(old['drug'],old['regimen'],old['trial'])
  idx[t[0]]=old
 rows=[]
 for r in readset('fda','dimensions'):
  ft,d=r['模型记录ID'],r['维度'];b=idx[ft]['codes'].get(d)
  a=r['独立代码_R_X_P_N_问号']
  if b is None:state='儿少单独按源表重建' if d=='D16a' else '现版未列此字段'
  elif a=='?':state='本次未独立确定；保留现行，待原件复核'
  elif a==b['code']:state='同码；保留来源与适用限制'
  else:state='代码分歧；须核对双方语义及来源范围'
  rows.append(dict(模型记录ID=ft,药物=r['药物'],方案=r.get('方案候选'),试验=r['试验名称候选'],维度=d,v43母试验=idx[ft]['parent_id'],v43角色=idx[ft]['role'],v43代码=b['code'] if b else '',v43依据=b['basis'] if b else '',v43层级=b['source'] if b else '',v43_R类型=b.get('r_type') if b else '',独立R类型=r.get('R依据类型',''),独立代码=a,独立核查状态=r['核查状态'],独立原文=r.get('原文短摘',''),页或字段=r.get('物理页与印刷页',''),文件和SHA=r.get('证据文件及SHA',''),原文层级=r.get('来源级别'),限制=r.get('排除范围与时态',''),状态=state,未决原因=r.get('未决原因','')))
 assert len(rows)==3674 and len(idx)==167
 out=OUT/'第二阶段'
 save(out/'FDA_3674维度逐项对照.json',rows)
 maps={r['模型记录ID']:r for r in readset('fda','mapping')}
 save(out/'FDA_167模型身份与角色对照.json',[dict(模型记录ID=i,药物=o['drug'],方案=o['regimen'],试验=o['trial'],v43母试验=o['parent_id'],v43角色=o['role'],v43来源=o['level'],v43设计老年=o['elderly'],v43单位=o['unit'],独立母试验=maps[i].get('parent',''),独立角色=maps[i].get('role',''),独立依据=maps[i].get('decision',''),独立原页=maps[i].get('evidence',[])) for i,o in idx.items()])
 save(out/'FDA逐维对照计数.json',dict(Counter(r['状态'] for r in rows)))
if __name__=='__main__':compare()
