from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,hashlib,re
OUT=Path(__file__).resolve().parents[2]
def read(p):return json.loads(Path(p).read_text())
def save(p,a):Path(p).write_text(json.dumps(a,ensure_ascii=False,indent=2))
def readset(domain,name):
 return [r for f in sorted((OUT/'phase1').glob(domain+'_*/'+name+'.json')) for r in read(f)]
def sid(s):
 m=re.fullmatch(r'NEW-([ABC])-(\d+)',s)
 return 'NEW-S%04d'%({'A':0,'B':10,'C':31}[m[1]]+int(m[2])) if m else s
def first():
 t=read(OUT/'计算/输入/回传字段模板.json'); arr=t['tables']
 rec=readset('guide','statements')
 for r in rec:r['陈述ID']=sid(r['陈述ID'])
 for n,data in [(0,readset('guide','sources')),(1,rec),(3,readset('fda','candidates')),(4,readset('fda','dimensions'))]:
  h=arr[n]['headers'];arr[n]['rows']=[[d.get(k,'') for k in h] for d in sorted(data,key=lambda x:(x[h[0]],x.get('维度','')))]
 for i in [6,7,8]:arr[i]['rows']=[]
 return t
if __name__=='__main__':
 if (OUT/'第一阶段冻结清单.json').exists(): raise SystemExit('已冻结。禁止以重跑替换第一阶段。')
 save(OUT/'phase1/原文先审回传.json',first())
 paths=sorted(p for d in ['phase1','新增原件'] for p in (OUT/d).rglob('*') if p.is_file() and not p.name.startswith('.'))
 save(OUT/'第一阶段冻结清单.json',dict(冻结时间=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),阶段='本包04与05内容首次打开之前。固定原文来源、陈述、候选、逐维度、设计和结果锚点。尚未评分的模板格保留空白，后续从这些输入计算。',已知偏倚='同一Codex会话此前参与v43，已知部分历史数字与争议。分工原文先审无法消除既有知识。',files=[dict(path=str(p.relative_to(OUT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size) for p in paths]))
