"""Regenerate links after scoring, preserving the OFC index and separate secondary dimensions."""
from first import OUT,read,save,sid,readset
from collections import defaultdict,Counter
G=OUT/'第二阶段/指南比较';O=OUT/'计算/指南FDA对应'
R='研究讨论_是或否或未确定';A='用药建议_是或否或未确定'
def build():
 O.mkdir(exist_ok=True);cells=read(G/'既定口径418格.json');by={(x['药物或方案'],x['维度']):x for x in cells}
 all_st={sid(x['陈述ID']):x for x in readset('guide','statements')}
 inputs=[('纯独立_原文先审',OUT/'计算/FDA/scenarios.json'),('现行口径_6项原表补证',OUT/'计算/现行口径定向重算/19设定8360格.json')]
 if (OUT/'计算/补证后独立/scenarios.json').exists():inputs.append(('独立_补证后',OUT/'计算/补证后独立/scenarios.json'))
 well=OUT/'计算/现行口径_含84A具名FDA审评/19设定8360格.json'
 if well.exists():inputs.append(('现行口径_加84A',well))
 par=OUT/'计算/PAR支持性角色敏感性/19设定8360格.json'
 if par.exists():inputs.append(('方法敏感性_PAR支持性角色',par))
 compare=OUT/'计算/FDA/comparison_8360.json'
 data=[(name,read(p)) for name,p in inputs]
 a=read(compare)
 for name,letter,qual in [('交叉定向补读子集','independent_after_page_review','independent_after_page_review_qualifier'),('方法敏感性_严格住院起始','strict_inpatient_initiation','strict_inpatient_qualifier'),('方法敏感性_去除两项支持结果','omit_two_supportive_positive_trials','omit_two_supportive_qualifier')]:
  data.append((name,[dict(**r,letter=r[letter],qualifier=r[qual]) for r in a]))
 for name,records in data:
  rows=[];stat={}
  for x in records:
   value=x['letter'].rstrip('*†‡');s=x['scenario'];ft=x['id'];d=x.get('dimension') or x['dim'];drug=x['drug'];reg=x['regimen']
   if value not in ['C','D']:continue
   key='喹硫平'+reg if drug=='喹硫平' else drug
   if reg=='与奥氮平联合起始':
    rs=ad='未确定';refs='';match='OFC不在历史418格，按完整方案、情境及阶段比对。'
    if d=='D14':
     rs=ad='是';refs='S0626，NEW-S0034';match+='中国指南成人难治性抑郁有固定组合依据；未指定与HGIE相同的既往失败次数或同时起始时点。'
    elif d=='D18':
     refs='S0169';match+='F038物理213–214，印191–192，具名氟西汀加奥氮平用于精神病性抑郁，1A。原文没有确认固定配方在同一时点起始。药物对与精神病性情境均有研究与建议；要求固定制剂并同时起始时两侧均未确定。'
    elif d in ['D13a','D13b']:
     match+='有固定组合的证据，新增/同时起始时序不能确认。'
    else:match+='原件定位S0626（F038物理126，印105）与NEW-S0034（物理123、139，印102、118）限成人难治，未证实该特定情境，如轻度抑郁。'
    mid='';note=match
   else:
    m=by[key,d];mid=m['格ID'];rs,ad=m[R],m[A];refs=m['陈述依据ID'];note=m['具体人群方案阶段限制'];match='有同一索引药与维度的陈述；人群、方案及阶段限制见逐条映射，不能推断试验直接代表该患者。' if '是' in [rs,ad] else '已检范围和未完成侧见对应格。'
   row={'对应ID':s+'-'+ft,'FDA重算候选格ID':ft,'药物及完整方案':drug+(' '+reg if reg else ''),'维度':d,'FDA独立重算字母':value,'指南研究讨论':rs,'指南用药建议':ad,'指南陈述ID':refs,'人群方案阶段是否匹配':match,'直接性及适用限制':note,'能否改变原FDA分类及理由':'指南提供临床情境或建议，FDA字母依监管试验及来源资格重算。','复核者':'Codex（AI）','日期':'2026-11-26','方案':s,'矩阵来源':name,'指南格':mid,'成人核心':d not in ['D16a','D16b','D18'],'FDA限制':x.get('qualifier',x.get('flags',''))}
   rows.append(row)
  for s in dict.fromkeys(r['方案'] for r in rows):
   rr=[r for r in rows if r['方案']==s and r['成人核心']];stat[s]=dict(成人缺口=len(rr),有研究=sum(r['指南研究讨论']=='是' for r in rr),有建议=sum(r['指南用药建议']=='是' for r in rr),均有=sum(r['指南研究讨论']==r['指南用药建议']=='是' for r in rr),至少一项未确定=sum('未确定' in [r['指南研究讨论'],r['指南用药建议']] for r in rr))
  save(O/(name+'_全部C或D.json'),rows);save(O/(name+'_成人缺口计数.json'),stat)
if __name__=='__main__':build()
