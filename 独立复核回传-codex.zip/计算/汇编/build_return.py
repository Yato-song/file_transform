"""Build the nine R1 return tables from preserved extractions, reviewer decisions and calculated grids."""
from first import OUT,read,save,readset,sid
from pathlib import Path
from guide_aligned import extid,extensions,allowed
from collections import Counter,defaultdict
import re,json,hashlib
S=OUT/'第二阶段'
G=S/'指南比较'
C=OUT/'计算'
F=C/'补证后独立'
R='研究讨论_是或否或未确定';A='用药建议_是或否或未确定'
who='Codex（AI）';day='2026-11-26'
def short(x):
    return json.dumps(x,ensure_ascii=False,separators=(',',':')) if isinstance(x,(list,dict)) else str(x or '')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(t,rows,extra=()):
    headers=t['headers']
    headers.extend(k for k in extra if k not in headers)
    t['rows']=[[r.get(k,'') for k in headers] for r in rows]
def sources(candidates):
    all_files={}
    for d in [OUT/'新增原件',OUT/'phase1/guide_a/new_sources',OUT/'phase1/guide_b/new_sources']:
        for p in sorted(d.rglob('*')):
            if p.is_file() and not p.name.startswith('.'):all_files[digest(p)]=str(p.relative_to(OUT))
    old={r['sha256']:r['path'] for r in read(C/'输入/指南原文目录.json')}
    out=[]
    def add(domain,ids,name,url,scope,status,use,version='',sha='',loc=''):
        key=f'MAT-{len(out)+1:04d}'
        out.append(dict(记录ID=key,领域=domain,关联记录ID=short(ids),所缺原件或新增来源=name,URL或DOI=url,检索日期=day,
                        检索式及已审范围=scope,取得状态=status,用途与尚不能确认的事实=use,是否属于新版本或新增范围=version,
                        复核者=who,文件路径=all_files.get(sha,''),SHA256=sha,原文页或段=loc))
    for r in read(OUT/'phase1/guide_a/new_source_catalog.json'):
        add('指南',r['对应'],r['文件'],r['URL'],r['性质'],'取得',r['判定'],'另列新材料',r['SHA256'],r['原文定位'])
    for name in ['新增原件/acquisition.json','新增原件/WHO_DEP1底层论文/PMC取得记录.json','新增原件/WHO_DEP1底层论文/access.json','新增原件/WHO_DEP1底层论文/Cao_access.json','新增原件/指南版本核查/WFSBP-acquired.json','新增原件/指南版本核查/search.json','新增原件/指南版本核查/targeted-access.json','新增原件/FDA第二阶段/取得清单.json','phase1/guide_b/new_sources/index.json','phase1/guide_b/new_sources/additional_access.json']:
        for r in read(OUT/name):
            sha=r.get('sha256','');url=r.get('url') or r.get('request_url','')
            use=r.get('reason') or r.get('type') or r.get('title') or r.get('source') or r.get('key') or r.get('file','')
            domain='FDA' if ('FDA' in name or 'NCT' in str(r.get('file')) or 'Effexor' in str(r.get('file'))) else '指南'
            add(domain,r.get('id') or r.get('catalog_key') or r.get('key') or r.get('file',''),r.get('file') or r.get('key') or r.get('filename') or url,url,name,'取得' if sha in all_files else ('与R1原件相同：'+old[sha]) if sha in old else '未确认取得原件',str(use)+'；'+str(r.get('status') or r.get('error') or r.get('err') or ''),'新取得材料或取得记录；不用元数据代替全文',sha,r.get('page',''))
    for p in [OUT/'新增原件/FDA-A/第二阶段定向回查/来源.json',OUT/'新增原件/FDA计算/来源.json']:
        r=read(p);add('FDA',r.get('id','S9'),r.get('source',all_files.get(r['sha256'],'')),r['url'],str(p.relative_to(OUT)),'取得',r.get('role',r.get('stage')),'第二阶段新取得',r['sha256'],'帕罗西汀329/377/701按交叉复核的试验原页；Turner见工作表fda_pos_neg')
    for p in sorted((OUT/'新增原件/FDA-A').glob('NCT*.json')):
        add('FDA',p.stem,p.name,'https://clinicaltrials.gov/study/'+p.stem,'ClinicalTrials.gov 登记记录；与方案别名核对','取得','仅用注册实际提供的字段，依3b来源开关。','新取得登记',digest(p),'studies[].protocolSection')
    for r in read(OUT/'phase1/guide_b/new_source_scope.json')['guideline_candidates']:
        add('指南',r['id'],r['name'],r['url'],r['evidence'],'候选；取得情况详定位',r['scope'],'范围决定待裁决')
    for r in read(OUT/'新增原件/指南版本核查/新增指南候选及限定.json'):
        add('指南',r['候选'],r['候选'],r['正式作者链接'],r['证据'],'按实际材料登记',r['处理'],'范围决定待裁决',r.get('材料SHA256'),r['材料'])
    r=read(S/'IDHS取得记录.json');add('编码',r['id'],'IDHS FY2016原件',r['url'],r['用途'],'未取得',r['结果'])
    for p in sorted(G.glob('后续*/*摘要/*.json')):
        z=read(p)
        if 'resultList' in z and z['resultList'].get('result'):
            hit=z['resultList']['result'][0];pmid=str(hit['id']);title=hit['title']
            scope='Europe PMC API原响应，核对作者摘要中的诊断、分组和治疗时序。'
        elif 'PMID' in z:
            pmid=str(z['PMID']);title=z['题名'];scope='来源元数据及作者摘要摘录，核对诊断、分组和治疗时序。'
        else:continue
        sha=digest(p);all_files[sha]=str(p.relative_to(OUT))
        add('指南','PMID'+pmid,title,'https://pubmed.ncbi.nlm.nih.gov/'+pmid+'/',scope,'取得作者摘要或作者摘要摘录','只用于界定指南所引原研究，与指南原本证据分列。','未静默扩入新的指南',sha,'摘要及书目信息，无PDF物理页')
    save(OUT/'新增原件/引证和取得索引.json',out)
    for r in candidates:
        add('FDA',r['候选记录ID'],r['未决或身份冲突'] or '对应实施版方案、完整CSR和审评人数表','',r['证据文件及SHA'],'需补材料或独立裁决',r['纳入范围及理由'],'不新增试验',loc=r['FDA判断原文及页码'])
    return out
def build():
    tab=read(C/'输入/回传字段模板.json')
    t=tab['tables']
    orig=read(OUT/'phase1/原文先审回传.json')
    def unpack(i):
        w=orig['tables'][i];return [dict(zip(w['headers'],r)) for r in w['rows']]
    src=readset('guide','sources');st=readset('guide','statements')
    for r in src:r['原件SHA256']=r.get('SHA256',r.get('sha256'))
    for r in st:r.update(陈述ID=sid(r['陈述ID']),原件路径=r.get('来源文件',r.get('source_path')),原件SHA256=r.get('SHA256',r.get('sha256')))
    for z in read(G/'交叉_其他映射问题.json'):
        if z['来源ID']!='F038':continue
        for r in st:
            if r['陈述ID']==z['陈述ID']:
                r.update(独立原文摘录=z['证明'],印刷页及表段=z['原页'],方向与限制=z['理由']+' '+r['方向与限制'])
    version={j['来源ID']:j for j in read(OUT/'新增原件/指南版本核查/原件版本复核补充.json')}
    for r in src:
        extra=version.get(r['来源ID'])
        if extra:
            r['同机构版本关系']+='。第二阶段查证：'+extra['版本复核']
            r['原文定位']+='；'+extra['物理页']+' '+extra['摘录']
            if r['来源ID'] in ['F032','F025']:r['核查状态']='已完成';r['是否需要补充来源']='当前所登记版本已核；另列同机构不同治疗阶段的资料。'
    ext_pop={'EXT-S0001':'妊娠期抑郁，一线治疗疗效或耐受性不满意。','EXT-S0002':'初始治疗无应答的老年抑郁患者；未给≥65岁独立效应。',
             **{f'EXT-S{i:04d}':'服用所列药物的哺乳期患者，所引段落评价母乳喂养。' for i in (3,4,5)},
             'EXT-S0006':'肝功能损害患者，分轻、中、重；轻度具体剂量描述冲突。','EXT-S0007':'围产期抑郁共病中至重度焦虑，未确认符合焦虑障碍诊断。',
             **{f'EXT-S{i:04d}':'老年期抑郁急性发作；该表未给具名试验的≥65岁分母。' for i in (8,9,10)},
             'EXT-S0011':'抑郁且有尼古丁依赖，并有戒烟意愿的患者。','EXT-S0012':'抑郁共病神经认知障碍，原句未指定基础病严重度、确切年龄或≥65岁分层。'}
    for z in extensions():
        uncertain=any(x in ('待裁','未确定') for x in [z['研究讨论'],z['用药建议']])
        st.append(dict(陈述ID=extid(z['候选陈述ID']),来源ID=z['来源ID'],候选药物或方案='、'.join(z['药物或方案']),旧定位页_待核实='',核查状态='已核未决' if uncertain else '已完成',独立原文摘录=z['独立核得原文'],准确物理页='、'.join(map(str,z['物理页'])),印刷页及表段=z['印刷页/表段'],中文释义=z['中文释义'],具体人群及年龄=z.get('具体人群及年龄') or (ext_pop.get(z['候选陈述ID']) or z['中文释义']),治疗阶段及联合方案=z['适用限制'],原证据等级=z['原证据等级'],原推荐强度=z['原推荐强度'],研究讨论判定='未确定' if z['研究讨论']=='待裁' else z['研究讨论'],用药建议判定='未确定' if z['用药建议']=='待裁' else z['用药建议'],方向与限制=z['适用限制'],漏项或拆分建议='第二阶段逐药补充，来源组原编号 '+z['候选陈述ID'],复核者=who,日期=day,原件路径=z['文件'],原件SHA256=z['原件SHA256']))
    put(t[0],sorted(src,key=lambda x:x['来源ID']),['原件SHA256']);put(t[1],sorted(st,key=lambda x:x['陈述ID']),['原件路径','原件SHA256'])
    byst={r['陈述ID']:r for r in st}
    g=read(G/'既定口径418格.json');md={c['格ID']:c for c in g}
    put(t[2],g,['研究依据ID','建议依据ID'])
    cand=unpack(3)
    traz=read(S/'曲唑酮速释_新增原件核查.json')
    roles=read(S/'PAR五项母试验定向补证.json')
    candidates={t['id']:t['candidate'] for t in read(F/'independent_inputs.json')}
    extensions_fda={z['id']:z for z in read(S/'艾司西酞普兰延长与维持两项补证.json')}
    well=read(S/'Well84A具名FDA决定与设计.json')
    vort=read(S/'伏硫西汀标签总述原页核查.json')
    for row in cand:
        if row['候选记录ID']==vort['id']:row.update(vort['fields'])
        if row['候选记录ID']==well['id']:row.update(well['fields'])
        if row['候选记录ID'] in extensions_fda:row.update(extensions_fda[row['候选记录ID']]['fields'])
        for r in roles:
            if row['候选记录ID']==candidates[r['ft']]:
                row.update(确认母试验ID=r['parent'],纳入范围及理由=r['role_detail']+' '+r['why'],FDA判断原文及页码=short(r['evidence']),证据文件及SHA=short(sorted({e['path']+' '+e['sha256'] for e in r['evidence']})),来源级别及理由='1 FDA原件，见逐段撰写者身份')

        if row['候选记录ID']=='FAD0064':
            row.update(核查状态='已核未决',确认母试验ID='美国速释标签项目汇总；未给具名母试验',FDA判断原文及页码=traz['quote']+' 物理12 '+traz['locator'],纳入范围及理由=traz['finding'],证据文件及SHA=traz['source']['file']+' '+traz['source']['sha256'],来源级别及理由='2，美国正式标签',未决或身份冲突='缺单项试验随机、实际给药地点与起始时点及分臂分母。')
        if row['候选记录ID']=='FAD0020':
            row['纳入范围及理由']='米氮平未建立疗效；阿米替林活性参照显示优势。判定限各自药物比较。'
            row['FDA判断原文及页码']+='。第二阶段纠正：003-021米氮平未优于安慰剂，阿米替林参照阳性，FDA 9f5adbd403bb，物理80印7。'
        if row['候选记录ID'] in ['FYP0020','FYP0021','FYP0022']:
            note=next(r for r in read(S/'FDA重点差异及纠偏.json') if r['记录ID']==[row['候选记录ID']])
            row['FDA判断原文及页码']+='；第二阶段FDA与CSR对读：'+note['独立发现']+' '+short(note['证据'])
    put(t[3],cand)
    revised=read(F/'independent_inputs.json');tr={r['id']:r for r in revised}
    changes={(x['ft'],x['dimension']) for x in read(F/'逐处补证输入.json')}
    dims=unpack(4)
    for row in dims:
        ft,d=row['模型记录ID'],row['维度']
        if (ft,d) not in changes:continue
        f=tr[ft]['fields'][d]
        row.update(核查状态=f['status'],R依据类型=f['rtype'],排除范围与时态=f['why'],原文短摘=f['quote'],
                   物理页与印刷页=f['page'],证据文件及SHA=f['source'],来源级别=f['tier'],完整性与直接性=f['why'],
                   未决原因=f['why'] if f['code']=='?' else '',本轮阶段='第二阶段补证')
        row['独立代码_R_X_P_N_问号']=f['code']
        if ft=='FT0134' and d=='D16b':
            row['完整性与直接性']+='；按既定“项目汇总”R进入计算，原句未给65岁界限，阈值待核。';row['核查状态']='已核未决';row['未决原因']='缺≥65的年龄界限或分组分母。'
        if ft=='FT0045' and d=='D12':
            row['核查状态']='已核未决';row['未决原因']='按现规则作汇总层R。严格住院起始须补给药时点。'
    put(t[4],dims,['本轮阶段'])
    grid=read(F/'main_cells.json')
    for v in grid:
        if not v['支持比较记录ID']:v['支持比较记录ID']='无可列的具名支持比较，详逐格贡献'
        if not v['不确定性']:v['不确定性']='按当前输入未列缺失贡献；适用条件见该格说明'
    put(t[5],grid)
    links=read(C/'指南FDA对应/独立_补证后_全部C或D.json');put(t[6],[l for l in links if l['方案']=='主设定'],['方案','矩阵来源','指南格','成人核心'])
    dif=[];pending=[]
    def diff(domain,ids,kind,old,new,evidence,effect,method,action,missing=''):
        dif.append(dict(差异ID=f'DIFF-{len(dif)+1:04d}',领域=domain,关联记录ID=short(ids),问题类型=kind,现版位置及原判断_阶段二填写=short(old),独立判断=short(new),原文依据与精确页码=short(evidence),影响的格或试验计数=short(effect),是否涉及方法改变=method,建议处理=action,证据不足或需裁决事项=missing,复核者=who,日期=day))
    diff('FDA',[well['id'],well['ft']],'母试验归属/来源层级','接收版按Trial 3标签与3a的Well 84A多特征匹配；冻结层身份未定',well['fields']['纳入范围及理由'],well['evidence'],'同一项已计比较，以1级FDA原件重算各设定','否','保留各时间层及来源限制',well['fields']['未决或身份冲突'])
    diff('FDA',[vort['id'],vort['ft'],'Q041-19'],'项目汇总、来源及治疗阶段','接收源表旧说明称D12仅依赖标签，接收矩阵实际为B；未给出项目年龄分母。',vort['fields']['分析集与人数']+' '+vort['updates'][0]['why'],vort['evidence'],'D12、D16b与D17；标签不重复计母试验','否','区分急性与维持，保留项目与臂级分母。',vort['fields']['未决或身份冲突'])
    for z in extensions_fda.values():
        f=z['fields']
        diff('FDA',z['id'],'试验身份/范围/分析分母','接收版排除急性层；第一阶段尚未确认身份',f['纳入范围及理由']+' '+f['分析集与人数'],z['evidence'],'维持或延长，不入急性与S6。','否','以具名FDA表注及申办方原表核定。',f['未决或身份冲突'])
    for q in read(S/'FDA重点差异及纠偏.json'):
        diff('FDA',q['记录ID'],q['字段'],q['v43具体判断'],q['独立发现'],q['证据'],q['影响'],'否；限相应字段',q['处理建议'])
    idx={(r['模型记录ID'],r['维度']):r for r in read(S/'FDA_3674复看处置.json')}
    for k in sorted(changes):
        ft,d=k;x=idx[k];f=tr[ft]['fields'][d]
        diff('FDA',ft+'-'+d,'纳排事实或维度；补证',x['v43代码']+'；'+x['v43依据'],f['code']+' '+f['rtype']+' '+f['why'],
             [f['source'],f['page'],f['quote']],ft+'-'+d,'否；汇总和范围条件另列','见定向六字段与独立层的分别计算')
    for j in read(C/'FDA审评原页_103与85027等级分歧.json'):
        diff('FDA',j['候选模型'],'结果判定',j['母试验']+'，v43已纳入阳性侧',j['审阅'],j['原文'],'替代情境另算','是，仅明确阳性时','保留两处原话与区别')
    for j in read(C/'FDA/comparison_summary.json')['signed_display_discrepancies']:
        diff('FDA',j['scenario']+'-'+j['id'],'聚合注脚',j['workbook'],j['reconstructed'],'接收修正版各设定矩阵；试验贡献见计算/FDA/received_inputs.json；该格阳性均X，机器flag为空。','仅*显示','否','核对显示层')
    for q in roles:
        diff('FDA',[q['ft'],candidates[q['ft']]],'结果判定/母试验',next(x for x in read(S/'FDA_167模型身份与角色对照.json') if x['模型记录ID']==q['ft'])['v43角色'],q['role_detail']+' '+q['why'],q['evidence'],'母试验与比较数见计算/补证后独立/summary.json','沿用阳性/支持合并','保留分审评人意见')
    for z in read(S/'FDA定向补证附录.json')['记录']:
        diff('FDA',[z['问题ID'],*z['候选试验记录']],'定向原页补证',z['原问题'],z['本次所见'],z['原文'],z['试验'],'见问题原登记','按原始分析集保留限定；不以事后结果代替主要分析。')
    for j in read(C/'guide/CANMAT_2017勘误_独立于原37来源.json'):
        if '原证据等级' not in j:
            diff('指南',j['陈述ID'],'新增来源', '旧表未有相同条目',j['独立解释'],j,j['格ID'],'新来源范围','仅在采用勘误的单列范围评估');continue
        diff('指南',j['陈述ID'],'来源/版本',j['原证据等级']+'；'+j['原推荐线次'],j['更正结论'],[j['原SHA256'],j['页段'],j['原文摘录'],j['SHA256'],j['印刷页及表段'],j['新版原句']],'晚年用药表6等级或线次','新取得正式勘误','原版与勘误并列，待研究者确定是否更新纳入版本。')
    for j in read(OUT/'新增原件/WHO_DEP1底层论文/24项逐效应对照.json'):
        if not j['是否同值']:diff('指南',j['陈述ID'],'来源冲突/区间',j['原指南短摘'],j['底层估计'],j,'不改变有无研究或建议','否','并列两值并注明CI/CrI；不擅自改WHO原表')
    for j in read(OUT/'新增原件/WHO_DEP1底层论文/Cao结局效应尺度待裁决.json'):
        diff('指南',j['陈述ID'],'来源冲突/效应尺度',j['WHO表原文'],j['解释'],j,'效应单位及对照；覆盖不变','需作者资料',j['处理'],j['解释'])
        pending.append(dict(类型='底层估计',ID=j['陈述ID'],原因=j['解释'],需补='分析模型、原始对比与WHO证据表转换说明'))
    bycell=defaultdict(list)
    for v in read(G/'现行有效陈述映射.json'):bycell[v['格ID']].append(v)
    pair=[]
    for x in read(G/'418逐格与历史93对照.json'):
        k=x['格ID'];c=md[k];now=[c[R],c[A]];e=bycell[k];oldids=sum(x['v4陈述'],[])
        evidence=[dict(陈述ID=i,文件=byst[i]['原件路径'],SHA256=byst[i]['原件SHA256'],物理页=byst[i]['准确物理页'],段=byst[i]['印刷页及表段'],原文=byst[i]['独立原文摘录']) for i in dict.fromkeys(oldids) if i in byst]
        pair.append(dict(格ID=k,历史ID=c['历史ID'],v4=x['v4'],复核=now,现版陈述=x['v4陈述'],复核陈述=c['陈述依据ID'],复核页证=e,旧依据的原文提取=evidence,未决=c['未决原因']))
        if now!=x['v4'] and (('是','否') in zip(now,x['v4']) or ('否','是') in zip(now,x['v4'])):
            diff('指南',k+' '+c['历史ID'],'映射/药物角色',x['v4'],now,e or evidence,c['情境'],'按现口径','限定'+c['具体人群方案阶段限制'],c['未决原因'])
    save(G/'最终418逐格与v4对照.json',pair)
    for v in read(G/'交叉裁决建议.json'):
        if v['维度'] in ('D13a','D13b','D18'):
            d=v['维度'];decision='v4口径与规则明确精神病性组合只计D18，保留D18并在D13另作范围建议' if d!='D18' else '具名组合限D18，使用相应比较研究和推荐；不转给单药。'
            diff('指南',v['格ID']+' '+v['陈述ID'],'联合方案索引',md[v['格ID']]['情境'],v['原因'],v['证明'],v['格ID'],'非D18映射需改方法' if d!='D18' else '否',decision)
    for j in read(G/'交叉_其他映射问题.json'):
        diff('指南',[j['格ID'],j['陈述ID']],j['类型'],'参见626逐字段和阶段一快照',j['理由'],[j['原件SHA256'],j['原页'],j['证明']],j['格ID'],'按既定条件或留待研究者裁决','按所引段落分别判断讨论和建议')
    for j in extensions():
        statement=extid(j['候选陈述ID'])
        in_scope=[k for k in j['格ID'] if allowed(k,statement)]
        diff('指南',[statement,*j['格ID']],'新增依据或来源冲突','见对应格当前陈述',j['中文释义'],[j['原件SHA256'],j['物理页'],j['印刷页/表段'],j['独立核得原文']],in_scope,'沿用原规则；需裁判的单列',j['适用限制'])
    for cell,statement,reason in [
        ('M081',extid('CX-S0006'),'Wijkstra 2010只招募精神病性抑郁患者。证据计入M088的D18，不贡献M081的D13a；该格有其他具名依据。'),
        ('M296','S0058','产后抑郁试验未报告58位受试者是否正在哺乳。哺乳表脚注可定位试验，但不足以确认喂养方式；M296双侧未定。'),
        ('M236','S0264','保留文拉法辛XR基础治疗后阿立哌唑增效的具名研究，仅适用于≥60岁非缓解患者；不能据此得出香港60–64岁实际人数或疗效。')]:
        source=byst[statement]
        where=[source[k] for k in ['原件路径','原件SHA256','准确物理页','印刷页及表段','独立原文摘录']]
        diff('指南',[cell,statement],'人群、治疗阶段与组合索引','见逐药候选与第一阶段陈述',reason,where,cell,'沿用原口径',reason)
    put(t[7],dif);material=sources(cand);put(t[8],material,['文件路径','SHA256','原文页或段'])
    for i in range(6):
        w=t[i];h=w['headers']
        for line in w['rows']:
            d=dict(zip(h,line));status=d['核查状态']
            if status=='已完成':continue
            key=line[0]+('-'+d['维度'] if i==4 else '')
            reasons=['同机构版本关系','漏项或拆分建议','未决原因','未决或身份冲突','未决原因','不确定性']
            reason=d[reasons[i]] or d.get('方向与限制') or d.get('完整性与直接性') or d.get('适用限制')
            pending.append(dict(类型=w['name'],ID=key,状态=status,原因=reason,范围=d.get('情境') or d.get('试验名称候选') or d.get('指南及版本'),需补=d.get('是否需要补充来源') or (d.get('适用限制') if i==5 else '见逐项原文及适用条件')))
    for q in read(S/'FDA问题逐项.json'):
        pending.append(dict(类型='原问题及新增问题/研究者核验',ID=q['id'],状态=q['独立核查状态'],原因=q['独立对照结论'],需补=q['后续所需'],人工签字=''))
    for u in pending:
        reason=short(u['原因'])+' '+short(u.get('需补'))
        categories=[]
        if any(k in reason for k in ['冲突','裁决','不一致','不符','语义','需核','并列','差异']) or u['类型']=='原问题及新增问题/研究者核验':
            categories.append('研究者裁决或签核')
        if any(k in reason for k in ['尚未完成','未能独立','未完成','未审','未逐','未核实','待核对','未独立','未查','补核']):
            categories.append('本轮语义或来源审阅尚未完成')
        if any(k in reason for k in ['未取得','方案','CSR','原件','分母','人数','来源资格','缺','需补','官网','原始对比']):
            categories.append('待取得或定位材料')
        u['处理类别']=categories or ['本轮尚无充分依据；按记录限制继续核实']
    save(OUT/'最终回传表.json',tab);save(OUT/'未完成ID与原因.json',pending)
    save(OUT/'差异清单_附页证.json',dif)
    return tab,pending
if __name__=='__main__':build()
