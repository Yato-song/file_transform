"""Write the Chinese report and machine-readable run summary from the delivered results."""
from first import OUT,read,save
from guide_aligned import extensions,PASS_NAMES
from collections import Counter
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,platform,hashlib
C=OUT/'计算';V=OUT/'验证';G=OUT/'第二阶段/指南比较';S=OUT/'第二阶段'
def dump(path,data):path.write_text(data,encoding='utf-8')
def sec(d):return '、'.join(f'{k} {v}' for k,v in d.items())
def main():
    now=datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(timespec='seconds')
    freeze=read(OUT/'第一阶段冻结清单.json');st=read(V/'回传结构.json')['coverage']
    gd=read(G/'既定口径计数.json');i=read(C/'补证后独立/summary.json');orig=read(C/'FDA/summary.json')
    ret=read(C/'现行口径定向重算/19设定计数.json')
    cross={p.name.split('_成人缺口计数')[0]:read(p) for p in sorted((C/'指南FDA对应').glob('*_成人缺口计数.json'))}
    model=read(C/'FDA/comparison_summary.json');pm=read(C/'PAR支持性角色敏感性/设定总计.json')
    fmain=i['主设定']['statistics'];adult=fmain['成人核心19'];ix=i['主设定']['trial_counts']
    raw=orig['主设定']['statistics']['成人核心19'];reg=ret['主设定']
    counts=read(S/'FDA原问题覆盖范围.json')['本轮状态'];vf=read(V/'原件定位与计数.json');nb=read(C/'补证后独立/stability.json')
    wb=read(C/'现行口径_含84A具名FDA审评/19设定计数.json')
    td=read(OUT/'最终回传表.json')['tables'];gap=cross['现行口径_加84A']['主设定']
    gp=cross['独立_补证后']['主设定'];a,b=gd['全418'],gd['历史93']
    dstat=st['FDA试验维度3674']['states'];cstat=st['FDA源表候选235']['states'];gstat=st['指南来源37']['states']
    extras=G/'扩展阴性核查/逐格判定.json'
    path=OUT/'phase1/原文先审回传.json';freeze_sha=hashlib.sha256(path.read_bytes()).hexdigest()
    meta=read(OUT/'审核者及运行信息_模板.json') if (OUT/'审核者及运行信息_模板.json').exists() else dict(package_id='HK-INDEPENDENT-20261125-R1',scope_requested='指南与FDA试验证据全量独立核查',source_cutoff='2026-11-25')
    meta.update(reviewer_or_model='Codex（GPT-6），同一AI系统分工原文提取、交叉查页和计算，曾参加FDA v43',run_started='2026-11-26 约10:24 Asia/Shanghai（解包工作区时间）',run_finished=now,
                scope_actually_completed={w:dict(返回=v['returned'],状态=v['states']) for w,v in st.items()},
                baseline_first_opened_at='2026-11-26 11:11:06 +08:00',first_stage_locked_at=freeze['冻结时间'],
                tools_and_versions=['Python '+platform.python_version(),'Python标准库 / openpyxl 3.1 / python-docx / pypdfium2 / 临时OCR、视觉核页 / 文件SHA-256 / 发布者公开下载及监管网页、注册API'],source_first_snapshot_sha256=freeze_sha,
                remaining_record_ids='未完成ID与原因.json，逐ID列出字段、范围及理由，含194+7待人工核验索引。',limitations=['既有FDA项目知识；不能视作独立双人复核或盲法。','标签无方案号、注册及OCR不等同完整实施版方案、确诊人群或逐臂实际分母。','回传的正负覆盖均受来源范围限定，存在单侧未完成。'])
    save(OUT/'审核者及运行信息.json',meta)
    save(OUT/'独立汇总结果.json',dict(交接号=meta['package_id'],指南=gd,原文先审指南探索=read(C/'guide/guide_counts.json'),
        最终补证独立FDA=i,冻结提取条件重算=orig,六字段现行输入重算=ret,六字段再加入84A具名审评=wb,成人母试验去重=read(C/'现行口径定向重算/执行验证.json')['去重计数'],
        角色和方法敏感性_全部设定=model['by_scenario'],PAR支持性角色_现行输入=pm,
        FDA缺口与指南_按各设定重新取成员=cross,问题状态=counts,表格结构=st,未完成清单='未完成ID与原因.json'))
    report=f"""指南与FDA试验证据独立复核报告
HK-INDEPENDENT-20261125-R1  |  Codex  |  2026年11月26日

一、研究者现在可以核验哪些结果

FDA接收修正版的成人主分析有320个可评分格，其中C 6格、D 82格，共88格（27.5%）。仅把六处有原表依据的字段更新到接收底稿后，这三个数相同。去甲文拉法辛的老年格FM08-D16b由B改为A，主设定和除S9外的17个敏感性设定均受影响。21个设定×格的证据明细变化，其中18个更换字母。另在FDA决定函中核到安非他酮84A的具名疗效意见及其纳排，将该试验从标签层还原至FDA审评层。两次事实修正叠加后成人主分析仍为88/320；严格D规则S8的成人C/D由80/320改为79/320。唯一因此改字母的成人格为安非他酮D13a，D→E；同一设定的次要维度D18也由D→E。

从本次独立取得的试验字段出发，补证后成人C/D为{adult['gap']}/320，其中E有{adult['counts']['E']}格。缺乏可用阳性试验条款时，计算会给E，故两个分子相差的部分不能解释成新增试验证据覆盖。回传表的FDA候选440格采用补证后独立计算。若要决定是否修订原项目，则看“现行口径定向重算”及有明确原页的逐条差异。

指南按v4既定来源、分组和角色口径，418格中已定位{a['research']}格有研究讨论、{a['advice']}格有具名用药建议，{a['both']}格两者都有；{a['uncertain']}格有至少一侧未确定。历史93格分别为{b['research']}、{b['advice']}、{b['both']}与{b['uncertain']}格。单侧覆盖即可构成“有研究”或“有建议”，两侧均已确定才可写“仅研究”或“仅建议”。19种方案包括分别索引的喹硫平单药和加药。精神病性维度保留在矩阵，香港成人主队列年龄为18–64岁，排除精神病性抑郁。包中没有可据以重新识别每名香港患者的个体数据。

二、审阅顺序和实际覆盖

37份指南登记原件包含正文、附表和循证证据概况，不可用作独立指南数量。第一阶段以原目录和空模板检索原件并存证，{freeze['冻结时间']}固定111份文件的指纹，11:11:06才首次打开本次R1中的04/05。原始快照的SHA-256为{freeze_sha}。同一Codex会话此前参与FDA v43，知道部分旧数字。同系统的分支复看与程序复算均记录为AI工作；人工签核栏为空。

指南原626条均在原ID下回传，608条达到第一阶段陈述级完成标准，18条待定。第一阶段另提取60个候选陈述；第二阶段扩展查页再登记{len(extensions())}个具名候选，包括拆分、注解与同页重叠项。旧ID及第一阶段文件保留。对v4的749条情境行已经逐行配对，并留存候选差异和页证。后续针对引文与人群的交叉抽查覆盖90格、136条有效映射、156个陈述ID。37个来源的最终状态为{sec(gstat)}，部分最新版边界尚未取得权威确认。新取得的Cipriani补充PDF、Cao附录、CANMAT勘误等与原37份区分登记。资料发表/更新截止2026-11-25，实际检索日为2026-11-26。

FDA源表全部235行均有去向（成人/老年179、儿少25、扩展参照31），不是235个独立试验。167条模型记录含163条常规和4条S5补充，各有22个维度。最终3674字段的状态为{sec(dstat)}；235个候选整项状态为{sec(cstat)}。试验身份、结果、一个实际年龄或单个排除条件有页证时，可关闭那个字段；其余实施条款、随机/用药/分析分母、亚组和结果归属分列未决。两项第一阶段未能确认的记录已查明。FDA医审分卷三物理31、印18表1注1与注7，分别点名99002为99001/99003延长、11D收11A/B/C应答者。申办方CTD物理1–4、印1522–1525确认99002为52周单队列（登记593、给药590、FAS 588）；11D为16周开放稳定后52周双盲维持，CTD物理55–61、印925–931列随机204、给药203、ITT 202。FDA早期快报的194是中间截点。两项均排除急性分析；11D最终复发效应仅以申办方结果登记。25个儿少候选另以年龄、人群、结果和来源核算D16a。

三、指南的四状态与主要分歧

集合          都有    仅研究    仅建议    两项均未定位    至少一侧未定    结构不适用
全部418        {a['both']}       {a['research_only']}        {a['advice_only']}          {a['neither']}                {a['uncertain']}             {a['na']}
历史93         {b['both']}       {b['research_only']}        {b['advice_only']}          {b['neither']}                {b['uncertain']}             {b['na']}

两侧均未定位要求37文件规定范围内的词表、命中页和语义复核。对米安色林、黛力新另保留扫描低文本页检查。{('其余17个方案的记录在“扩展阴性核查”和“后续逐药复看A、B、C”。四组逐药记录保留真实已读页、术语、引用和未决原因；同一药的单药和增效索引保持分开。' if extras.exists() else '其余药物如未查遍相关命中及扫描页，缺乏肯定证据的一侧标未确定。')}历史G编号原样保留。M059、M087沿用结构不适用。M060的第三格结构异议单列。每个覆盖格均可按M号→陈述ID→原件SHA、物理页和表段查回。

• F038物理291、303（印269、281）给出妊娠期疗效或耐受不满意后改换列名SNRI的2C建议。既往治疗失败格仅计“疗效不满意”。F038物理301（印279）列伏硫西汀等服药时可哺乳；物理295给出标签转引，应与CANMAT并列。F016物理64明确抑郁合并尼古丁依赖且有戒烟意愿可考虑安非他酮，所引结局是戒烟成功。F024物理138的老年起始剂量注明索引和方案；使用剂量表不证明≥65亚组抑郁疗效。
• WHO DEP1与Cipriani等原始荟萃的24个逐药估计中23个一致。S0136的WHO表7（物理31）写OR 2.13，CI 1.89–2.14；Cipriani网络荟萃附录物理147、印146为2.13，95% CrI 1.89–2.41。两处原值并列。另有7个Cao功能结局，WHO表写SMD、论文摘要写加权均差，补充DOCX eTable 3/6 与 eFigure 3各有不同的比较类型。保留WHO原等级，将对照或量纲登记待裁决。
• CANMAT晚年用药表6旧版F006物理11、印598，随后正式勘误印356重列步骤和等级。15个原陈述逐一对照，另含2个勘误新增药物。S0249度洛西汀旧表同时出现Level 1和2，勘误初阶列Level 1。S0252/S0253在勘误中有药物限定。年龄门槛保留原文，≥60岁不转成≥65岁患者疗效。现行集合未静默添入历史外版本。
• S0169在中国2025指南物理213–214、印191–192明确氟西汀加奥氮平治疗精神病性抑郁（1A）。两种成分在D18分别索引并保留完整方案；现行规则不从D18外推至非精神病性D13。S0626（物理126、印105）另涉固定OFC及成人难治条件。两处不能证明HGIE试验同样的人群、制剂和起始时点。
• S0026仅就该四臂试验报告戒酒和重饮结局。F011物理10、印47下一段抑郁结局出于另一项美沙酮试验。从M001移除这一研究贡献，保留同格其他原文依据。S0097、S0099、S0102、S0103（ESMO补表F018）涉及确诊MDD与预防、疲劳或亚组界限，未按具名目标治疗确证。旧CANMAT一般成人及围产期被替代条款、仅安全性和仅类别意见均有逐映射记录。
• M219中，F038物理126、印105明确“不再推荐”黛力新，但“循证证据不足”未注明专指疗效。用药建议保留，研究侧待裁决。原有微观陈述与格级用途分别保存。v4底稿的109个研究格、128个建议格和87个交集是比较值；现次证据状态受未定单侧影响，不能把数值差直接当作错格数。

四、FDA原页对研究解释的影响

1. FDA统计审评bf99e08c6a4c物理56–58、印8–10表3.1–3.3逐臂给年龄极值。去甲文拉法辛309、317、320的ITT本药臂分别117、110、117人，最高年龄73、68、70岁。309、317的文拉法辛参照臂分别127、115人，最高70、73岁。另在99003的FDA医审63c87e9b9267物理60、印19，西酞普兰参照组有6%基线未特指焦虑。这六个R取自实际参加的对应药物臂。无法从最高年龄推知≥65岁人数或亚组疗效。99001物理55、印14群名和表头冲突，不按99003外推。
2. 阿立哌唑增效试验FT0061/FT0062随机阶段的HAM-D最低14（f9227a615d2d物理9、17，印8、16表3、14）。初筛≥18不能替代导入结束时的实际评分。主设定按实际入组保留R，S11的8–13定义另算。曲唑酮缓释04ACL3-001 FDA医审物理26、印20写“Presence of”并把治疗失败定义到两个足量疗程各至少1个月。速释DESYREL新取得美国标签物理12 §14只写住院/门诊试验，不能确定住院开始给药。按现行汇总层规则保留带限制的R；严格住院起始的单项替代指示，成人89/320。
3. 西酞普兰87A FDA医审P2物理23、印47列51人随机，三个臂各17，完成5/4/4；HAM-D17 LOCF p=.093，试验提前停止。纳入单相重性或双相抑郁，缺诊断分层。主任/医学未建立的结论及FDA病例叙述可支持现行D12格C；不能将17名本药接受者全部识别为单相MDD。CIT-MD-18去除9名可能揭盲者的事后分析，申办方CSR物理38、印70写p=.052，FDA备忘录印3写p=.52。主要分析均p=.038。两个小数均已原样登记。
4. 舍曲林老年主动对照FDA医学总结c3e1641beda0物理148、印31明确105（美国9中心、103人）和325（欧洲12中心、77人），每个方案内部的药物臂共用母试验。舍曲林103的FDA统计记录物理125、印32说明只有部分主要变量获支持，同卷物理148、印31医学总结仍列103与104；米氮平85027的主任与统计对阳性/失败意见不一（9f5adbd403bb物理79、331）。单独去掉这两个支持性阳性输入的替代计数为90/320。
5. HGIE的整体样本主要分析未达到目标，FDA团队只在本次发作两次失败的事后亚组给予支持性评价（a15d8b469151物理178、181，统计设计物理296–297）。氟西汀和奥氮平两个索引共用一项母试验；文拉法辛5–9天减停限该方案。伏硫西汀14178A为单相单次/复发MDD，EMA物理115列DSM-IV-TR 296.2x/296.3x，留S5。CCT-004的申办方CTD与PMDA独立评估分列，后者物理44–45、48（印41–42、45），随机493，FAS 489，Holm校正p=.0080/.0023；未升级为FDA自身证据。
6. 帕罗西汀五项母试验从未决回到原审评。01-001未建立，02-002医审肯定、统计组长认作支持，03-002失败，03-004支持但医审称统计结果模棱，固定剂量PAR 09辅助支持其余试验。见NDA 20-031原卷e4f1c139b27f物理3、49、71、87、94、98、104–105。03-004与PAR 09在v43按未建立处理，纳入“支持性”是否足以更换角色须研究者裁决。只调整这些角色时，在六字段现行重算上的主字母仍为88/320，成人比较分别会从60/58改为62/56。补证后独立层可归属的成人母试验是{ix['named_count']}项。FT0100已用独立FDA原页补足身份。1989-03-24决定函物理243点名84A，医审物理306–310列6周门诊、300mg/日、随机112/112、疗效110/106、安全110/109。美国标签物理27–28的Trial 3是唯一对应门诊试验，剂量和两臂疗效分母完全相符。FDA第309页同时保留分中心结果及少量精神药违约。补证后的主分析仅计一项。两份人数不能相加，也无法从试验数量推断患者代表性。
7. 补查的FDA帕罗西汀儿少医审与329/377/701的CSR端点、ITT/随机人数和退出定义分列。完整去重表的主设定有116个已识别或按旧规则匹配的成人母试验、5条成人汇总，扩展目录31条参照比较。独立模型补证后有{ix['adult_comparisons']['pos']}个阳性/支持性成人比较、{ix['adult_comparisons']['neg']}个未建立比较及{ix['adult_comparisons']['pool']}条成人汇总；标签和具名审评的对应依据逐项保留。去重以共同协议/母试验为依据，采用独立计算的跨申报参照还须单独核对试验本药、真实臂分母和S6开关。

8. 伏硫西汀美国标签（2025年3月版）物理17、§8.5记载项目中286/2616名受试者≥65岁。物理24、§14合述六项急性及一项维持研究的住院与门诊人群，无法据此识别哪一急性试验在住院期间起始。物理25的老年Study 6实际年龄范围为64–88岁。FDA主任医审物理2、印1列全部提交的10项短期研究，6项至少一个剂量获支持。标签总述只计项目证据；逐研究实际分臂人数见各研究。旧源表备注称D12的A来自标签，但接收矩阵的实际主字母为B。复核中补入项目年龄和索引药单药设计，住院起始仍为未确定。19套设定中这三维的现行字母与注脚均维持原值，见“验证/伏硫西汀标签三维与现行重算.json”。

五、设定重算及指南对应

表中为成人核心19维度的C+D/可评分格。每设定20×22=440个候选格，成人候选380格；儿少D16a、老年D16b、精神病性D18各20格另外报告。B−、E、不评分、结构不适用、*及†分别保留。
设定      冻结独立输入    补证后独立输入    六字段现行输入    加84A原审评
"""
    for k in i:
        p=orig[k]['statistics']['成人核心19'];q=i[k]['statistics']['成人核心19'];o=ret[k]['可评分成人']
        report+=f"{k:7}   {p['gap']}/{p['rated']}              {q['gap']}/{q['rated']}               {o['gap']}/{o['cells']}               {wb[k]['可评分成人']['gap']}/{wb[k]['可评分成人']['cells']}\n"
    report+=f"""
严格住院起始、去掉两项支持研究、PAR支持性解释均已另作全19套，并重新提取C/D成员。独立初次输入共{raw['gap']}个成人C/D，先补16项选择性原页后为57，再补分卷二附录、适用时态及五个PAR角色后为51，加入84A具名FDA原件后为{adult['gap']}。这些数的差别来自不同批次证据与对初始提取的纠偏。最终{len(nb['scenarios'])}套保持同一组320可评分格的设定中，{nb['stable']}格字母稳定、{nb['variable']}格变化（依据当前独立输入）。S6、S7须用各自分母。接收版8,360个基础字母全部可回放；S5 FM17-D13a显示D*，按该格阳性均为X、机器flag空，应显示D，计数不受影响。

补证后独立主设定的次要维度分别为：
"""
    for k,v in fmain.items():
        if k!='成人核心19':report+=f"{k}  {sec(v['counts'])}，可评分{v['rated']}。\n"
    report+=f"""
在现行六字段及84A原页版本的88个成人C/D格上，指南已有{gap['有研究']}格具名研究讨论、{gap['有建议']}格用药建议、{gap['均有']}格兼有，{gap['至少一项未确定']}格至少一侧尚待核。补证后独立计算的{gp['成人缺口']}个成人C/D另行对应，分别为{gp['有研究']}、{gp['有建议']}、{gp['均有']}，{gp['至少一项未确定']}格至少一侧待核。每种方法的缺口成员都从该次输出重新产生。OFC在418之外；精神病性抑郁可找到具名药物对，而固定制剂且同时起始的证据仍须单列。指南的阴性研究、监测或避免用药也可能构成相应侧的覆盖。

六、未决与回传原项目的顺序

原194题加新增7题均有独立去向，问题层为{sec(counts)}。11项额外定向核页、20条引文以及五项PAR补证都在第二阶段单列，和问题表用ID连接。优先回看支持性角色、87A诊断界限、HGIE限亚组、米氮平003系列及曲唑酮IR住院起始、未提供实施版方案的排除清单、≥65逐臂人数、99001组名冲突及儿少分析分母。应由研究者签名的人工作业未执行。完整未决文件为“未完成ID与原因.json”；同一试验可同时出现于试验、字段、问题和格级，勿跨表相加。

逐条差异页证见“差异清单_附页证.json”，完整逐格、626个陈述字段、749情境、原问题及所有试验维度对照见“第二阶段”。在提取记录只给电子登记字段、网页全文或DOCX图表时，按原载体定位。不能落实的印刷页用物理页及表/段说明。有{vf['检验到不同PDF物理页数']}个不同PDF物理页通过与所引原件配对的页界检查，文件指纹和页界通过不替代引文内容核验。原R1的980个清单文件完整。

七、供原项目修订proposal的具体位置与英文建议

完整版清洁稿v24第28、33段及简版v21第17、34段（成人矩阵及图1说明），建议补充：
“Under the received specification, 88 of 320 applicable adult cells were classified C or D. Six arm-specific corrections and identification of the FDA review for Study 84A left that count unchanged. Under the strict-D sensitivity rule, the adult count decreased from 80 to 79 of 320. Actual enrolment of participants aged 65 years or older changed the separate desvenlafaxine older-adult cell from B to A.”
若提及独立层，单列 “The source-first reconstruction remained incomplete, with {adult['counts']['E']} adult cells graded E after supplementary review.”

完整版第29、36段及简版第37段（指南及图2说明），建议按本轮范围补充：
“Within the prespecified guideline set, the review located named treatment research in {a['research']} cells and actionable medication advice in {a['advice']}, with both in {a['both']}. At least one component remained unresolved in {a['uncertain']} of the 418 cells. The historical subset retained its original 93 members.”
如说明FDA对应：“Among the 88 adult C/D cells in the received specification, {gap['有研究']} had a located guideline discussion of named treatment research and {gap['有建议']} had medication advice. {gap['均有']} had both.” 最终引用时还应标出适用亚组、基础药与增效药及阶段。

完整版第47、96、106–120段及简版第17段（核验与历史条目），建议追加：
“All 194 inherited queries and seven later queries have a recorded disposition. Trial-level missing protocols, subgroup denominators and disagreements between reviewers remain open for investigator adjudication.” 历史版本说明应保留当时的时间点；S6、S7使用各自可评分分母。

完整版第75段与简版第25段（香港样本量），保留18–64岁及患者层重算要求：
“Patient counts for the revised 18–64-year cohort require a new extraction from the Hong Kong data.” 试验格、比较、母试验计数不可用来更新实际患者数。这些均为建议措辞；正式proposal的原文件指纹已核对。

"""
    dump(OUT/'中文复核报告.txt',report)
if __name__=='__main__':main()
