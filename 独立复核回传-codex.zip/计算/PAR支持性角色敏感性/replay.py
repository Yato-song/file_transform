"""Isolate how paroxetine supportive-role decisions affect the received grid after six factual updates."""
import sys,json
from collections import defaultdict,Counter
from pathlib import Path
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'FDA'))
from calculate import load,grade,GRADES
from compare import baseline_items,update_support,letter_from
out=here.parents[1]
def save(name,x):(here/name).write_text(json.dumps(x,ensure_ascii=False,separators=(',',':')))
def main():
    source=here.parent/'FDA';trials=load(source/'independent_inputs.json');records=defaultdict(dict)
    for t in trials:records[t['drug'],t['regimen']][t['trial']]=t
    ids={r['ft']:r['role'] for r in load(out/'第二阶段/PAR五项母试验定向补证.json')}
    changes={(r['ft'],r['dimension']):r for r in load(source/'adjudication_cases.json')['observations'] if r['apply_to_retained']}
    ops={s:o for s,_,o in load(here.parent/'输入/维度与设定定义.json')['FDA_scenarios']}
    comp={(r['scenario'],r['drug'],r['regimen'],r['dimension']):r for r in load(source/'comparison_8360.json')}
    rows=[];counts=defaultdict(Counter);deltas=[]
    for scenario,drug,reg,dim,show,old,mflag,raw in load(source/'received_inputs.json'):
        key=(scenario,drug,reg,dim);control=comp[key];letter=control['verified_observations'];flag=control['verified_qualifier'];new=letter;sign=flag
        if drug=='帕罗西汀' and dim!='D16a' and not ops[scenario].get('turner'):
            items,_=update_support(baseline_items(raw,records[drug,reg]),dim,changes)
            check,_=letter_from(items,ops[scenario],dim,old)
            assert check==letter
            for r in items:r[1]=ids.get(r[0],r[1])
            new,sign=letter_from(items,ops[scenario],dim,old)
        v=dict(scenario=scenario,id=control['id'],drug=drug,regimen=reg,dimension=dim,letter=new,qualifier=sign,before=letter,original_flag=flag)
        rows.append(v)
        if (letter,flag)!=(new,sign):deltas.append(v)
        if dim not in ['D16a','D16b','D18']:counts[scenario][new]+=1
    assert len(rows)==8360
    save('19设定8360格.json',rows);save('逐格变动.json',deltas)
    save('设定总计.json',{s:dict(成人字母=dict(c),可评分=sum(c[g] for g in GRADES),缺口=c['C']+c['D'],字母异动=sum(r['scenario']==s and r['letter']!=r['before'] for r in deltas)) for s,c in counts.items()})
if __name__=='__main__': main()
