"""按已保存的独提陈述和格级直接性重算指南418格；适用于本包的目录结构。"""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
PHASE = OUT.parent.parent / "phase1"
SCOPE = OUT / "两药37份_命中与低文本页核对.json"
TEMPLATE = OUT.parent / "输入" / "回传字段模板.json"
if not TEMPLATE.exists():
    TEMPLATE = OUT.parent.parent.parent / "01_任务与回传" / "回传字段模板.json"
STUDY = "研究讨论_是或否或未确定"
ADVICE = "用药建议_是或否或未确定"
OFFSETS = {"A": 0, "B": 10, "C": 31}
# 仅列由方案名与维度直接矛盾的结构，避免把另一药缺乏研究误记为结构不适用。
STRUCTURE = {
    ("喹硫平单药", "D13a"): "单药方案与同时合用抗抑郁药矛盾。",
    ("喹硫平单药", "D13b"): "单药方案与同时合用其他抗精神病药或情感稳定剂矛盾。",
    ("喹硫平加药", "D17"): "加药方案以正在使用基础治疗为前提。",
}


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(name, data):
    path = OUT / name
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def uid(raw):
    match = re.fullmatch(r"NEW-([ABC])-(\d{4})", raw)
    if not match:
        return raw
    return f"NEW-S{OFFSETS[match[1]] + int(match[2]):04d}"


def yes(value):
    if value not in (True, False, "是", "否", "未确定"):
        raise ValueError(f"不识别的判定 {value!r}")
    return value is True or value == "是"


def unique(items):
    return list(dict.fromkeys(items))


def audit_counts(rows):
    pairs = Counter((x[STUDY], x[ADVICE]) for x in rows)
    direct = Counter((x[STUDY] == "是", x[ADVICE] == "是") for x in rows if x[STUDY] != "不适用")
    return {
        "总格数": len(rows),
        "已确定的四类": {
            "两项皆是": pairs["是", "是"], "仅研究": pairs["是", "否"],
            "仅建议": pairs["否", "是"], "均未定位": pairs["否", "否"],
        },
        "未确定格数": sum(n for pair, n in pairs.items() if "未确定" in pair),
        "研究已定位但建议未确定": pairs["是", "未确定"],
        "建议已定位但研究未确定": pairs["未确定", "是"],
        "两项均未确定": pairs["未确定", "未确定"],
        "结构不适用": pairs["不适用", "不适用"],
        "研究讨论已证实（含单侧未确定）": sum(x[STUDY] == "是" for x in rows),
        "用药建议已证实（含单侧未确定）": sum(x[ADVICE] == "是" for x in rows),
        "交集": pairs["是", "是"],
        "已提取直接证据下界，另一侧可能未定": {
            "有双侧直接依据": direct[True, True], "只定位到研究依据": direct[True, False],
            "只定位到建议依据": direct[False, True], "尚无任一直接依据（含真阴性及未定）": direct[False, False],
        },
        "未确定格ID": [x["格ID"] for x in rows if "未确定" in (x[STUDY], x[ADVICE])],
        "均未定位格ID": [x["格ID"] for x in rows if (x[STUDY], x[ADVICE]) == ("否", "否")],
        "结构不适用格ID": [x["格ID"] for x in rows if x[STUDY] == "不适用"],
    }


def main():
    table = next(t for t in read(TEMPLATE)["tables"] if t["name"] == "指南418格")
    cells = [dict(zip(table["headers"], row)) for row in table["rows"]]
    by_id = {c["格ID"]: c for c in cells}
    keys = {(c["药物或方案"], c["维度"]): c["格ID"] for c in cells}
    assert len(cells) == len(by_id) == len(keys) == 418
    hist = [c["历史ID"] for c in cells if c["历史93标记"] == "是"]
    assert len(hist) == len(set(hist)) == 93
    inputs = [TEMPLATE, SCOPE]
    sources, statements, evidence = {}, {}, defaultdict(list)
    for branch in "abc":
        sub = PHASE / f"guide_{branch}"
        for fname in ("sources.json", "statements.json", "coverage.json"):
            inputs.append(sub / fname)
        for item in read(sub / "sources.json"):
            assert item["来源ID"] not in sources
            sources[item["来源ID"]] = item
        for item in read(sub / "statements.json"):
            sid = uid(item["陈述ID"])
            assert sid not in statements
            statements[sid] = item
        for x in read(sub / "coverage.json"):
            sid = uid(x["陈述ID"])
            m = x["格ID"]
            assert m in by_id and sid in statements
            for k in ("药物或方案", "维度"):
                assert k not in x or x[k] == by_id[m][k]
            evidence[m].append((sid, yes(x.get("研究讨论", x.get("研究讨论判定"))),
                                yes(x.get("用药建议", x.get("用药建议判定"))),
                                x.get("具体人群方案阶段限制", x.get("适用限制", ""))))
    assert set(f"S{n:04d}" for n in range(1, 627)) <= set(statements)
    assert len(sources) == 37
    # 中国来源新增页包含完整独提，最初的coverage只列既有S号。
    # 用具名、具体维度的终点和限制补上这些独提的格引用。OFC独列。
    for n in [1, 2, *range(4, 30)]:
        sid = uid(f"NEW-C-{n:04d}")
        st = statements[sid]
        drug = st["候选药物或方案"]
        dim = {1: "D15", 2: "D16b"}.get(n, "D10")
        note = st["具体人群及年龄"] + "；" + st["治疗阶段及联合方案"]
        if n == 2:
            note += "；仅为原文未定下限的老年用药提醒，不能据此声称≥65岁人群有疗效研究。"
        evidence[keys[drug, dim]].append((sid, False, True, note))
    hits = read(SCOPE)
    for drug in ("黛力新", "米安色林"):
        assert {r["source"] for r in hits if r["drug"] == drug} == set(sources)
        assert all(r["低文本页原图补核"] for r in hits if r["drug"] == drug and r["low_text_pages"])
    # 对氟西汀等间接换药、ESMO混合治疗/预防行保留单条未确定，不升格。
    pending = defaultdict(list)
    for sid, st in statements.items():
        if st["核查状态"] != "已核未决":
            continue
        if sid in {"S0317","S0318","S0319","S0428","S0429","S0430","S0431"}:
            pending[keys[st["候选药物或方案"].removeprefix("改换"), "D14"]].append(sid)
        elif sid in {"S0097","S0099","S0102","S0103"}:
            pending[keys[st["候选药物或方案"], "D10"]].append(sid)
    all_refs = []
    for c in cells:
        m, drug, dim = c["格ID"], c["药物或方案"], c["维度"]
        complete_search = drug in {"黛力新", "米安色林"}
        no_hit = "否" if complete_search else "未确定"
        links = []
        for sid, research, advice, note in evidence[m]:
            st = statements[sid]
            links.append({
                "格ID": m, "陈述ID": sid, "分组原ID": st["陈述ID"], "来源ID": st["来源ID"],
                "研究讨论": research, "用药建议": advice, "药物或方案": drug, "维度": dim,
                "物理页": st["准确物理页"], "印刷页及表段": st["印刷页及表段"],
                "原文": st["独立原文摘录"], "原件SHA256": st.get("SHA256", st.get("sha256")),
                "适用限制": note, "陈述核查状态": st["核查状态"],
            })
        all_refs.extend(links)
        tag = STRUCTURE.get((drug, dim))
        if tag and links:
            raise ValueError(f"矛盾的结构判定与直接证据 {m}")
        terms = "两药37份_命中与低文本页核对.json" if complete_search else "guide_a/全文药名页索引.json；guide_b/source_search_scope.json；guide_c/sources.json及statements.json"
        if tag:
            rr = aa = "不适用"
        else:
            rr = "是" if any(x["研究讨论"] for x in links) else no_hit
            aa = "是" if any(x["用药建议"] for x in links) else no_hit
        why = ""
        if "未确定" in (rr, aa):
            why = "所列原文提取未证实该侧。F018–F037完成全文药名词检及已提取条款语义核对；其余命中和中国扫描本的此药全来源逐情境语义审阅尚未完成。"
            if pending[m]:
                why += " 需裁决相关条目 " + "、".join(pending[m]) + "。"
        ids = unique(x["陈述ID"] for x in links)
        loc = unique(f"{x['来源ID']} 物理{x['物理页']}，{x['印刷页及表段']}" for x in links)
        note = unique(x["适用限制"] for x in links if x["适用限制"])
        c.update({"核查状态":"已核未决" if why else "已完成","结构适用性":"不适用" if tag else "适用",
                  STUDY:rr, ADVICE:aa,"陈述依据ID":"，".join(ids),
                  "具体人群方案阶段限制":tag or " ｜ ".join(note) or "限已审版本中的具名抑郁治疗研究及可执行用药意见。",
                  "已审来源及页段":" ｜ ".join(loc + ["检索范围见"+terms]),
                  "未决原因":why,"复核者":"Codex，AI独立原文核查与汇总","日期":"2026-11-26",
                  "研究依据ID":unique(x["陈述ID"] for x in links if x["研究讨论"]),
                  "建议依据ID":unique(x["陈述ID"] for x in links if x["用药建议"]),
                  "单条待裁判定":pending[m], "原范围证据明细":links})
    totals = {"全418":audit_counts(cells),"历史93":audit_counts([c for c in cells if c["历史93标记"]=="是"]),
              "依据来源文件数":len(sources),"既有陈述":626,"新增陈述（包内既有原文）":len(statements)-626,
              "格引用数":len(all_refs),"口径":"研究/建议平行判定，已足以证明一条即该侧为是；其他药未核完的无阳性侧写未确定。两个全件查过的具名方案按两药专表可填否。反对和限制均可为建议。D16b保留来源年龄界限；不把模糊年龄改成≥65岁的直接证据。原有历史成员不变。新增来源勘误只作并列。",
              "输入SHA256":{str(p.relative_to(OUT.parent.parent)) if p.is_relative_to(OUT.parent.parent) else p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}}
    for group in ("全418","历史93"):
        row=totals[group]
        assert row["总格数"] == sum(row["已确定的四类"].values())+row["未确定格数"]+row["结构不适用"]
    save("guide_cells.json", cells)
    save("guide_counts.json", totals)
    save("guide_cell_links.json", all_refs)
    save("历史93格.json",[c for c in cells if c["历史93标记"] == "是"])
    corr=read(PHASE/"guide_a"/"新增正式勘误_分条对照_与包内分析分开.json")
    save("CANMAT_2017勘误_独立于原37来源.json", corr)


if __name__ == "__main__":
    main()
