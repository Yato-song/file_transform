"""Reaggregate the independently extracted trial data after second-pass page review."""
from pathlib import Path
import sys, json, shutil
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'FDA'
OUT=HERE.parents[1]
sys.path.insert(0,str(SOURCE))
import calculate as calc
from compare import supplement

def reviewed_inputs():
    source=calc.load(SOURCE/'independent_inputs.json')
    new=calc.load(SOURCE/'adjudication_cases.json')['observations']
    reviewed=supplement(source,new)
    index={r['id']:r for r in reviewed}
    log=[dict(**f,stage='交叉审阅；汇总R只在既定允许的层级及维度有效') for f in new]
    def apply(ft,d,code,level,rtype,quote,why,locator,source,timing=None):
        field=index[ft]['fields'][d]
        field.update(code=code,tier=level,rtype=rtype,why=why,quote=quote,source=source,page=locator,
                     status='已完成' if code!='?' else '已核未决',time_only=timing)
        log.append(dict(ft=ft,dimension=d,code=code,level=level,rtype=rtype,why=why,
                        quote=quote,source=source,page=locator,time_only=timing,stage='第二阶段逐页补证'))
    for f in calc.load(OUT/'第二阶段/原文复看_裁决建议与逐条补证.json'):
        reason=f['why'];d=f['dimension']
        timing=d in ('D01','D03') if f['code']=='P' and f['ft'] in ('FT0035','FT0036','FT0038','FT0039','FT0040','FT0041','FT0042') else None
        apply(f['ft'],d,f['code'],f['level'],{'doc':'实际入组','design':'设计要求','':''}[f['r_type']],
              f['quote'],reason,'物理'+str(f['page'])+'；'+f['locator'],f['source']+' SHA256 '+f['sha256'],timing)
    for r in calc.load(OUT/'第二阶段/FDA_3674复看处置.json'):
        ft,d=r['模型记录ID'],r['维度']
        if not r['处理'].startswith('既定时间'):continue
        if ft in ('FT0032','FT0149'):
            loc='物理58（印17，99003: The inclusion and exclusion criteria are the same as that for study 99001）与物理78（印37，99001附录）；详见复看记录'
        else:loc=r['页或字段']
        quote=('Patients who currently meet the DSM-IV criteria for Mania or any Bipolar Disorder, Schizophrenia or any psychotic disorder, Obsessive-Compulsive Disorder, current eating disorders' if ft!='FT0044' else
              'History of treatment refractory major depressive episodes defined as incomplete or no therapeutic response to two prior courses of at least one month of conventional antidepressant drug treatment in adequate dosages.' if d=='D14' else
              'Presence of any of the following DSM-IV Axis I disorders: generalized anxiety disorder, panic disorder, social phobia, obsessive-compulsive disorder, post-traumatic stress disorder, eating disorder')
        apply(ft,d,'P','1','',quote,'排除现症；无终身排除依据。' if d!='D14' else '两个足量疗程各至少一月；未排除所有既往一次治疗失败。',loc,r['文件和SHA'],d!='D14')
    f=index['FT0044']['fields']['D03']
    apply('FT0044','D08b','P','1','','DSM-IV Major Depressive Disorder Specifiers: (a) With Catatonic Features; (b) With Postpartum Onset; (c) With Seasonal Pattern;',
          'FDA排产后起病MDD，未涵盖全部产后/哺乳；注册另写排哺乳。高层级已有部分条件，注册不扩成所有产后。',f['page'],f['source'],False)
    # The trial papers add an actual arm maximum. US review still establishes age eligibility when 3a is off.
    original={r['id']:r for r in source}
    for ft in ('FT0090','FT0091','FT0096','FT0138'):
        f=original[ft]['fields']['D16b']
        assert f['tier']=='1' and f['code']=='N'
        index[ft]['fields']['D16b']['without_3a']=f
    roles=calc.load(OUT/'第二阶段/PAR五项母试验定向补证.json')
    for f in roles:
        t=index[f['ft']]
        assert t['trial']==f['trial'] and f['role'] in ('pos','neg','unresolved')
        t.update(role=f['role'],parent=f['parent'],original_role=f['role_detail'],reason=f['why'])
        for u in f.get('dimension_updates',[]):
            ev=u['evidence'];loc='，'.join(e['sha256'][:12]+' 物理'+str(e['page'])+' '+e['locator'] for e in ev)
            apply(t['id'],u['dimension'],u['code'],u['level'],'',' ｜ '.join(e['quote'] for e in ev),u['why'],
                  loc,' ｜ '.join(dict.fromkeys(e['path']+' SHA256 '+e['sha256'] for e in ev)),False)
    well=calc.load(OUT/'第二阶段/Well84A具名FDA决定与设计.json')
    tw=index[well['ft']]
    tw.update(parent=well['parent'],role=well['role'],label=False,original_role='FDA具名支持',reason=well['fields']['纳入范围及理由'])
    for u in well['updates']:
        ev=[well['evidence'][i] for i in u['evidence_indices']]
        apply(tw['id'],u['dimension'],u['code'],'1',u['rtype'],' ｜ '.join(e['quote'] for e in ev),u['why'],
              '；'.join(e['sha256'][:12]+' 物理'+str(e['page'])+' '+e['locator'] for e in ev),
              ' ｜ '.join(dict.fromkeys(e['path']+' SHA256 '+e['sha256'] for e in ev)),False)
    for ft,dimension,reason in [('FT0134','D16b','依项目汇总R进入计算；原句未给≥65界限或分组分母。'),('FT0045','D12','按既定规则使用汇总R；缺住院期间开始给药的准确时点。')]:
        field=index[ft]['fields'][dimension]
        field.update(status='已核未决',why=field['why']+' '+reason)
    label=calc.load(OUT/'第二阶段/伏硫西汀标签总述原页核查.json')
    for u in label['updates']:
        ev=[label['evidence'][i] for i in u['refs']]
        apply(label['ft'],u['dimension'],u['code'],'2',u['rtype'],' ｜ '.join(v['quote'] for v in ev),u['why'],
              '；'.join('物理'+str(v['page'])+' '+v['locator'] for v in ev),
              ev[0]['path']+' SHA256 '+ev[0]['sha256'])
    return reviewed,log

def main():
    inputs,log=reviewed_inputs()
    calc.HERE=HERE
    calc.save('independent_inputs.json',inputs)
    calc.save('逐处补证输入.json',log)
    shutil.copyfile(SOURCE/'pediatric_25.json',HERE/'pediatric_25.json')
    original_effective=calc.effective
    def effective_with_retained_observation(trial,dim,options):
        f=trial['fields'][dim]
        if 'without_3a' in f and not calc.permits(f['tier'],options):
            trial=dict(trial,fields={**trial['fields'],dim:f['without_3a']})
        return original_effective(trial,dim,options)
    calc.effective=effective_with_retained_observation
    try:calc.run()
    finally:calc.effective=original_effective
    original=calc.load(SOURCE/'scenarios.json')
    new=calc.load(HERE/'scenarios.json')
    diffs=[dict(scenario=a['scenario'],id=a['id'],before=a['letter'],after=b['letter'],
                old_qualifier=a['qualifier'],new_qualifier=b['qualifier'],contributions=b['contributions'])
           for a,b in zip(original,new) if (a['letter'],a['qualifier'])!=(b['letter'],b['qualifier'])]
    calc.save('与冻结输入矩阵差异.json',diffs)
    received={(v['scenario'],v['id']):v for v in calc.load(SOURCE/'comparison_8360.json')}
    from compare import display_mark
    comparison=[]
    for v in new:
        b=received[v['scenario'],v['id']]
        display=display_mark(v['letter'],v['qualifier'],v['drug'],v['regimen'],v['dimension'])
        comparison.append(dict(scenario=v['scenario'],id=v['id'],dimension=v['dimension'],drug=v['drug'],regimen=v['regimen'],
                         independent=display,received=b['received_display'],letter_changed=v['letter']!=b['received'],
                         qualifier_changed=(display[len(v['letter']):]!=b['received_display'][len(b['received']):]),
                         traced_fields=[r[0]+'-'+v['dimension'] for r in v['contributions']],pending=v['unknown_or_unresolved'],
                         distinct_parents=v['distinct_parents']))
    calc.save('最终与接收修正矩阵8360逐格对照.json',comparison)
    value={(t['id'],d):f for t in inputs for d,f in t['fields'].items()}
    dimrows=[]
    for r in calc.load(OUT/'第二阶段/FDA_3674复看处置.json'):
        d=r['维度'];f=value[r['模型记录ID'],d];dimrows.append(dict(ft=r['模型记录ID'],dimension=d,
            before=r['v43代码'],baseline_effective=r['旧按R类型实算'],initial_independent=r['独立代码'],final_code=f['code'],
            final_r_type=f['rtype'],final_effective='N' if f['code']=='R' and '仅允许' in f['rtype'] else f['code'],
            tier=f['tier'],source=f['source'],locator=f['page'],why=f['why'],quote=f['quote'],status=f['status'],
            secondary=f.get('without_3a'),registry_option=f['registry']))
    calc.save('最终3674字段代码对照.json',dimrows)
if __name__=='__main__':main()
