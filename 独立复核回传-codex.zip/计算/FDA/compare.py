"""Rebuild the received evidence matrix and compare distinct evidence and methods."""
from collections import Counter, defaultdict
from copy import deepcopy
from calculate import HERE, INPUT, GRADES, grade, independent_cell, load, save


def baseline_items(old, records):
    items = []
    for status, trial, code, level, summary, origin in old:
        t = records[trial]
        pooled = t["role"] == "pool" or t["id"] == "FT0045"
        role = "pool" if pooled else "pos" if status == "阳性" else "neg"
        # Explicit v43 alias; the first-pass independent assessment leaves this identity unconfirmed.
        parent = t["parent"] or ("安非他酮|Well 84A" if t["id"] == "FT0100" else t["drug"] + "|" + t["trial"])
        items.append([t["id"], role, code, None if pooled else parent, summary])
    return items


def letter_from(items, options, dim, structural):
    if structural in {"—", "n/a"}:
        return structural, ""
    if dim == "D16a":
        return ("A" if any(x[1] == "pos" for x in items) else "C" if items else "D"), ""
    return grade(items, options)


def supplement(trials, facts):
    revised = deepcopy(trials)
    indexed = {t["id"]: t for t in revised}
    for f in facts:
        t = indexed[f["ft"]]
        if "role" in f:
            t["role"] = f["role"]
        if "label" in f:
            t["label"] = f["label"]
        t["fields"][f["dimension"]].update(code=f["code"], tier=f["level"], rtype=f["rtype"], why=f["why"],
            quote=f["quote"], source=f["source"]+" SHA256 "+f["sha256"], page=str(f["page"])+" "+f["locator"],
            status="已完成", time_only=False)
    return revised


def display_mark(letter, flag, drug, regimen, dim):
    limited = drug == "氟西汀" and regimen == "与奥氮平联合起始" and dim in {"D13a", "D13b"}
    return letter + ("*" if "*" in flag else "") + ("†" if limited else "")


def update_support(rows, dim, changes):
    result = [r.copy() for r in rows]
    modifications = []
    for r in result:
        f = changes.get((r[0], dim))
        if f:
            modifications.append([r[0], r[2], f["code"]])
            r[2], r[4] = f["code"], f["rtype"]
    return result, modifications


def trial_differences(old, new, missing, dim, trials, children):
    original = {r[0]: r[1:3] for r in old}
    extracted = {r[0]: r[1:3] for r in new}
    changed = {}
    for ident in sorted(original.keys() | extracted.keys()):
        before, after = original.get(ident), extracted.get(ident)
        if before == after:
            continue
        if after is None:
            cause = "独立角色或字段未决" if ident in missing else "两层的来源、角色或设定纳入不同"
        elif before is None:
            cause = "独立证据新增可用比较或角色"
        elif before[0] != after[0]:
            cause = "试验结果角色或来源分层有别"
        elif after[1] == "?":
            cause = "独立来源未落实该维度"
        elif before[1] == "?":
            cause = "独立来源补到可编码资料"
        else:
            cause = "不同条款事实、适用范围或判码"
        if dim == "D16a":
            locator = children[ident]["id"]
        else:
            locator = trials[ident]["fields"][dim]["page"]
        changed[ident] = [before, after, cause, locator]
    return changed


def run():
    trials = load(HERE / "independent_inputs.json")
    children = load(HERE / "pediatric_25.json")
    facts = load(HERE / "adjudication_cases.json")["observations"]
    changes = {(f["ft"], f["dimension"]): f for f in facts if f["apply_to_retained"]}
    received_index, revised_index = defaultdict(dict), defaultdict(list)
    for t in trials:
        received_index[t["drug"], t["regimen"]][t["trial"]] = t
    for t in supplement(trials, facts):
        revised_index[t["drug"], t["regimen"]].append(t)
    pure = {(r["scenario"], r["drug"], r["regimen"], r["dimension"]): r for r in load(HERE / "scenarios.json")}
    options = {s: o for s, n, o in load(INPUT / "维度与设定定义.json")["FDA_scenarios"]}
    child_data = {r["id"]:r for r in children}
    child_ids = {(r["drug"], r["trial"]): r["id"] for r in load(HERE / "candidate_dispositions.json") if r["id"] in child_data}
    child_ids["米氮平", "标签 儿少两项"] = "FYP0004"
    trial_data = {r["id"]:r for r in trials}
    complete, differences, control_errors, annotation_errors, supplemental_traces = [], [], [], [], []
    old_named = defaultdict(set)
    diagnostics = []
    tally = defaultdict(Counter)
    for sc, drug, reg, dim, display, received, machine_flag, old in load(HERE / "received_inputs.json"):
        opt = options[sc]
        first = pure[sc, drug, reg, dim]
        if dim == "D16a":
            base = [[child_ids[drug,t[1]], "pos" if t[0] == "阳性" else "neg", t[2], t[1], ""] for t in old]
        else:
            base = baseline_items(old, received_index[drug, reg])
        if sc == "主设定" and dim not in {"D16a", "D16b", "D18"}:
            for ident, role, code, parent, typ in base:
                if parent and role != "pool":
                    old_named[parent].add(ident)
        control, flag = letter_from(base, opt, dim, received)
        ctrl_display = display_mark(control, flag, drug, reg, dim)
        if control != received:
            control_errors.append([sc, first["id"], control, received])
        if ctrl_display != display:
            annotation_errors.append(dict(scenario=sc, id=first["id"], workbook=display,
                reconstructed=ctrl_display, machine_flag=machine_flag))
        accepted, updates = update_support(base, dim, changes)
        verified, verified_flag = letter_from(accepted, opt, dim, received)
        strict = [r.copy() for r in accepted]
        for r in strict:
            if r[0] == "FT0045" and dim == "D12":
                r[2] = "?"
        inpatient, inpatient_flag = letter_from(strict, opt, dim, received)
        narrower = [r for r in accepted if r[1] != "pos" or r[0] not in ("FT0001", "FT0012")]
        restricted, restricted_flag = letter_from(narrower, opt, dim, received)
        second, second_flag, items, pending, _ = independent_cell(drug, reg, dim, opt, revised_index[drug, reg], children)
        new_support = [[x[0], x[1], x[2]] for x in items]
        if first["contributions"] != new_support or first["unknown_or_unresolved"] != pending:
            supplemental_traces.append(dict(scenario=sc, id=first["id"], letter=second, qualifier=second_flag,
                contributions=new_support, unknown_or_unresolved=pending))
        layers = dict(pure=first["letter"], received=received, independent_after_page_review=second,
                      verified_observations=verified, strict_inpatient_initiation=inpatient,
                      omit_two_supportive_positive_trials=restricted)
        rec = dict(scenario=sc, id=first["id"], drug=drug, regimen=reg, dimension=dim,
            received_display=display, received=received, reconstructed_control=control,
            control_display=ctrl_display, independent=first["letter"], independent_qualifier=first["qualifier"],
            independent_status=first["status"], independent_after_page_review=second,
            independent_after_page_review_qualifier=second_flag,
            verified_observations=verified, verified_qualifier=verified_flag,
            strict_inpatient_initiation=inpatient, strict_inpatient_qualifier=inpatient_flag,
            omit_two_supportive_positive_trials=restricted, omit_two_supportive_qualifier=restricted_flag,
            verified_trial_updates=updates)
        complete.append(rec)
        if any(value != received for value in layers.values()) or ctrl_display != display or updates:
            differences.append(rec)
        if first["letter"] != received:
            input_changes = trial_differences(base, first["contributions"], first["unknown_or_unresolved"],
                dim, trial_data, child_data)
            diagnostics.append(dict(scenario=sc, id=first["id"], received=received, independent=first["letter"],
                trial_changes=input_changes, unresolved=first["unknown_or_unresolved"],
                distinct_independent_parents=first["distinct_parents"]))
        stats = tally[sc]
        stats["total"] += 1
        for key, letter in layers.items():
            stats[key + "_letter_differences"] += received != letter
            if dim not in {"D16a", "D16b", "D18"}:
                stats[key + "_" + letter] += 1
                stats[key + "_rated"] += letter in GRADES
                stats[key + "_gap"] += letter in {"C", "D"}
    if len(complete) != 8360 or control_errors:
        raise ValueError(f"Control failed: {len(complete)} cells; {control_errors[:5]}")
    save("comparison_8360.json", complete)
    save("letter_differences.json", differences)
    save("page_review_contribution_changes.json", supplemental_traces)
    save("independent_difference_causes.json", diagnostics)
    main_core = [r for r in complete if r["scenario"] == "主设定" and r["dimension"] not in {"D16a","D16b","D18"}]
    layers = ("received","independent","independent_after_page_review","verified_observations",
              "strict_inpatient_initiation","omit_two_supportive_positive_trials")
    save("main_gap_members_by_layer.json",{name:[dict(id=r["id"],drug=r["drug"],regimen=r["regimen"],
        dimension=r["dimension"],letter=r[name]) for r in main_core if r[name] in {"C","D"}] for name in layers})
    independent_parents = set(load(HERE / "summary.json")["主设定"]["trial_counts"]["named_adult_parent_ids"])
    details = [dict(received_parent=k, model_ids=sorted(old_named[k]),
                independent_decision=[trial_data[i]["reason"] or "角色/身份提取未落实" for i in sorted(old_named[k])])
               for k in sorted(old_named.keys()-independent_parents)]
    save("named_parent_reconciliation.json", dict(received_count=len(old_named), independent_count=len(independent_parents),
        received_only=details, independent_only=sorted(independent_parents-old_named.keys()),
        note="限主成人具名；汇总记录、儿少、设计老年、跨申报参照和S5专属比较不入此数。"))
    save("comparison_summary.json", dict(by_scenario=tally, control_mismatches=control_errors,
        signed_display_discrepancies=annotation_errors,
        note="接收工作簿排版与按贡献复算符号分别保存；差异保留于逐格记录。"))
    print(f"{len(complete)} received grades reproduced; {len(annotation_errors)} signed-display exceptions.")


if __name__ == "__main__":
    run()
