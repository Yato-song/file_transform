"""Check the matrices against the neutral grid, independent contributions and cross-engine controls."""
from collections import Counter
from hashlib import sha256
from itertools import product
from calculate import HERE, INPUT, MAIN, GRADES, load, save


def require(value, message):
    if not value:
        raise ValueError(message)


def read_back_grade(row, options, models):
    dim, entries = row["dimension"], row["contributions"]
    if row["letter"] in {"—", "n/a"}:
        require(not entries, "Structural cell has trial evidence")
        return row["letter"]
    if dim == "D16a":
        return "A" if any(t[1] == "pos" for t in entries) else "C" if entries else "D"
    pos = {e[2] for e in entries if e[1] in ("pos", "pool")}
    negative_enrolled = any(e[1:] == ["neg", "R"] for e in entries)
    if "R" in pos:
        result = "A"
    elif "N" in pos:
        result = "B"
    elif "P" in pos:
        result = "B−"
    elif pos == {"?"}:
        result = "E"
    else:
        result = "C" if negative_enrolled else "D"
    if options["strict"] and result == "D" and "?" in pos:
        return "E"
    if options.get("s14") and result in {"A", "B", "B−"}:
        covering = {models[i]["parent"] for i,role,code in entries
                    if role == "pos" and code in {"R","N","P"} and models[i]["parent"]}
        if len(covering) < 2:
            return "C" if negative_enrolled else "D"
    return result


def run():
    trials = load(HERE/"independent_inputs.json")
    models = {r["id"]:r for r in trials}
    pediatric = load(HERE/"pediatric_25.json")
    ids = set(models) | {r["id"] for r in pediatric}
    candidates = load(HERE/"candidate_dispositions.json")
    raw = load(INPUT/"回传字段模板.json")
    table = next(t for t in raw["tables"] if t["name"] == "FDA候选440格")
    expected = {r[table["headers"].index("候选格ID")] for r in table["rows"]}
    dim = load(INPUT/"维度与设定定义.json")
    opts = {s:o for s,n,o in dim["FDA_scenarios"]}
    require(len(expected) == 440 and len(opts) == 19, "Grid definition mismatch")
    require(len(models) == 167 and all(set(t["fields"]) == set(dim["FDA_dimensions"]) for t in trials), "Trial dimensions incomplete")
    require(len({r["id"] for r in candidates}) == len(candidates) == 235, "Candidate count mismatch")
    require(Counter(r["id"][:4] for r in candidates) == {"FAD0":179, "FYP0":25, "FREF":31}, "Candidate partitions differ")
    require(len({r["id"] for r in pediatric}) == len(pediatric) == 25 and all(r["evidence"] for r in pediatric), "Pediatric gap")
    require(sum(r["turner"] is not None for r in trials) == 83, "Turner model linkage differs")
    rows = load(HERE/"scenarios.json")
    key = lambda r:(r["scenario"],r["id"])
    require(len(rows) == len(set(map(key, rows))) == 8360 and set(map(key, rows)) == set(product(opts, expected)), "Scenario grid differs")
    markers = Counter()
    for r in rows:
        require(all(e[0] in ids for e in r["contributions"]) and set(r["unknown_or_unresolved"]) <= ids, f"Broken evidence key {key(r)}")
        require(read_back_grade(r, opts[r["scenario"]], models) == r["letter"], f"Independently re-rated value differs {key(r)}")
        limited = r["drug"] == "氟西汀" and r["regimen"] == "与奥氮平联合起始" and r["dimension"] in ("D13a","D13b")
        require(("†" in r["qualifier"]) == limited, f"OFC restriction mismatch {key(r)}")
        markers[r["letter"]] += 1
    main = load(HERE/"main_cells.json")
    require(len(main) == 440 and {r["候选格ID"] for r in main} == expected and all(set(r) == set(table["headers"]) for r in main), "Main template columns/IDs changed")
    by_id = {r["候选格ID"]:r for r in main}
    for r in rows:
        if r["scenario"] == MAIN:
            require(by_id[r["id"]]["独立字母或NA或不评分"] == r["letter"], "Main letter differs")
    summ = load(HERE/"summary.json")
    for sc in opts:
        subset = [r for r in rows if r["scenario"] == sc]
        for group, restricted in (("儿少D16a","D16a"),("老年D16b","D16b"),("精神病性D18","D18"),("成人核心19",None)):
            g = [r for r in subset if (r["dimension"] == restricted if restricted else r["dimension"] not in ("D16a","D16b","D18"))]
            stats = summ[sc]["statistics"][group]
            c = Counter(r["letter"] for r in g)
            require(len(g) == (20 if restricted else 380) and c == stats["counts"] and
                    sum(c[t] for t in GRADES) == stats["rated"] and c["C"] + c["D"] == stats["gap"], "Stratum count differs")
    comp = load(HERE/"comparison_8360.json")
    require(len(comp)==8360 and set(map(key,comp)) == set(map(key,rows)), "Comparator keys differ")
    require(all(r["received"] == r["reconstructed_control"] for r in comp), "Received letter mismatch")
    ar = [r for r in comp if r["received_display"] != r["control_display"]]
    require([(r["scenario"],r["id"],r["received_display"],r["control_display"]) for r in ar] == [("S5","FM17-D13a","D*","D")], "Unexplained display marker")
    changes = load(HERE/"independent_difference_causes.json")
    require({key(r) for r in changes} == {key(r) for r in comp if r["received"] != r["independent"]} and
            all(r["trial_changes"] for r in changes), "Missing trial-level differences")
    external = HERE.parent/"现行口径定向重算"/"19设定8360格.json"
    crosschecked = None
    if external.exists():
        ext = {key(r): r["letter"] for r in load(external)}
        require(len(ext)==8360 and all(r["verified_observations"] == ext[key(r)] for r in comp), "Six-field cross-engine difference")
        crosschecked = len(ext)
    unknown = sum(f["code"] == "?" for t in trials for f in t["fields"].values())
    source = HERE.parents[1]/"新增原件"/"FDA计算"/"Turner2022_S2_Data.xlsx"
    receipt = load(source.parent/"来源.json")
    require(sha256(source.read_bytes()).hexdigest()==receipt["sha256"], "Turner source checksum failed")
    require(len(summ[MAIN]["trial_counts"]["named_adult_parent_ids"])==110, "Named denominator mismatch")
    st = load(HERE/"stability.json")
    require(len(st["scenarios"])==17 and st["stable"]+st["variable"]==320, "Stability grouping differs")
    def digests():
        files=sorted(p for p in HERE.iterdir() if p.suffix in (".json",".py",".txt") and p.name != "validation.json")
        return {p.name:sha256(p.read_bytes()).hexdigest() for p in files}
    save("validation.json",dict(template_cells=440,scenarios=19,trial_models=167,trial_fields=3674,unknown_normalized_fields=unknown,
        independent_grades_recomputed=len(rows), independent_differences_with_trial_causes=len(changes),
        received_grades_recomputed=len(comp), received_display_reproduced=len(comp)-len(ar),
        signed_display_exception=[{k:ar[0][k] for k in ("scenario","id","received_display","control_display")}],
        six_observation_matrix_matches_second_engine=crosschecked, candidate_entries=len(candidates),
        pediatric_entries=len(pediatric), turner_s2_trial_matches=83, normalized_and_output_sha256=digests()))
    print("Validated 8360 independent grades, 8360 received grades, four strata per scenario and supporting inputs.")


if __name__ == "__main__":
    run()
