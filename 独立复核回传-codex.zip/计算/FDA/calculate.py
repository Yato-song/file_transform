"""Calculate the R1 matrix directly from normalized independent trial observations."""
from collections import Counter, defaultdict
from pathlib import Path
import json
import re

HERE = Path(__file__).resolve().parent
INPUT = HERE.parent / "输入"
MAIN = "主设定"
GRADES = ("A", "B", "B−", "C", "D", "E")
NA = {("喹硫平","单药","D13a"),("喹硫平","加药","D17"),("氟西汀","与奥氮平联合起始","D17")}
NO_PLACEBO = {"FT0081","FT0083","FT0085","FT0135"}
DIAGNOSIS = {"D01","D03","D04a","D04b","D05","D07","D11"}
AUTHOR = "Codex（AI，既往参与过v43）"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(name, data):
    (HERE/name).write_text(json.dumps(data,ensure_ascii=False,separators=(",", ":")), encoding="utf-8")


def permits(tier, options):
    return tier=="1" or bool(options.get({"1b":"b1","2":"label","3a":"l3a","3b":"l3b"}.get(tier,"")))


def record_role(t, options):
    if t["s5"] and not options["sens"] or t["reference"] and not options["refarm"]:
        return None
    if t["label"] and not options["label"] or not options["hdao2"] and t["id"] in NO_PLACEBO:
        return None
    if options.get("turner") and t["turner"]:
        return t["turner"]["role"]
    return t["role"]


def effective(t, dim, opt):
    f=t["fields"][dim]
    c, level, rtype, why=f["code"], f["tier"], f["rtype"], f["why"]
    if not permits(level,opt):
        c="?"
    # The registry is a fill only when the approved higher-tier observation is absent.
    reg=f["registry"]
    timing=f["time_only"]
    if c=="?" and opt["l3b"] and reg:
        c,level,rtype,why,timing=reg["code"],"3b",reg.get("rtype",""),reg.get("reason",""),reg.get("timing")
    if c=="R" and ("仅允许" in rtype or opt.get("s15") and "汇总" in rtype):
        c="N"
    if opt.get("s11") and dim=="D15" and (c=="P" or (c=="R" and t["id"] in {"FT0030","FT0061","FT0062"})):
        c="X"
    if opt.get("s12") and dim=="D15" and c=="X":
        long_scale=re.search(r"(?:HAM-?D[- ]?(?:21|24)|前18项)[^；。]{0,9}(?:≥|>=)\s*(\d+)",why,re.I)
        if long_scale and int(long_scale[1])<=18 and not re.search("中度|CGI|前17项",why):
            c="P"
    if opt.get("s16") and dim=="D04b" and c=="X" and re.search("原发|主要诊断",why):
        c="P"
    # Independently extracted silence is '?' unless completeness and directness were established.
    if opt.get("s17") and c=="N" and re.search("概述|清单不完整|选择性清单",why):
        c="?"
    if opt.get("s18") and c=="X" and dim in DIAGNOSIS:
        if not re.search(r"当前|目前|现患|现症|既往|终生|过去|本次|current|history|prior|past|lifetime|previous",why+" "+f["quote"],re.I):
            c="P"
    if opt.get("s19") and c=="P":
        if timing is None:
            timing=dim=="D01" and bool(re.search("6个月内物质滥用或依赖|6个月内酒精或物质滥用|DSM-IV过去12个月",why))
            timing |= bool(re.search("过去6个月排MDD之外DSM-IV Axis I障碍",why))
        if timing:
            c="X"
    return c,level,rtype


def grade(items,opt):
    positives=[r for r in items if r[1] in ("pos","pool") and not (r[1]=="pool" and r[2]=="?")]
    negatives=[r for r in items if r[1]=="neg"]
    p={r[2] for r in positives}
    cover={r[3] for r in positives if r[2] in {"R","N","P"} and r[1]!="pool" and r[3]}
    neg_r=any(r[2]=="R" for r in negatives)
    result=next((g for code,g in (("R","A"),("N","B"),("P","B−")) if code in p),None)
    if result is None:
        result="E" if p=={"?"} else "C" if neg_r else "D"
    flag=""
    if result=="A" and all("汇总" in r[4] for r in positives if r[2]=="R"):
        flag="*汇总层面"
    if result in {"C","D"} and "?" in p:
        flag="*部分阳性未报告"
    if opt["strict"] and result=="D" and "?" in p:
        result="E"
    if opt.get("s14") and result in ("A","B","B−") and len(cover)<2:
        result="C" if neg_r else "D"
    return result,flag


def unavailable(drug,reg,dim,opt):
    if drug in ("米安色林","黛力新") or drug=="阿米替林" and not opt["refarm"]:
        return "—"
    if (drug,reg)==("氟西汀","与奥氮平联合起始") and not opt["hdao2"]:
        return "—"
    if (drug,reg,dim) in NA:
        return "n/a"
    return ""


def pediatric_items(drug,reg,opt,children):
    if reg=="与奥氮平联合起始":
        return [],[]
    items,missing=[],[]
    for r in children:
        if r["drug"]!=drug or r["reference"] and not opt["refarm"] or r["id"]=="FYP0016" and opt.get("no_cit18"):
            continue
        if r["code"]=="X":
            continue
        if not permits(r["role_tier"],opt) or not permits(r["field_tier"],opt) or r["role"]=="unresolved":
            missing.append(r["id"])
            continue
        items.append([r["id"],r["role"],r["code"],r["parent"],r["rtype"]])
    return items,missing


def independent_cell(drug,reg,dim,opt,trials,children):
    limited=(drug,reg)==("氟西汀","与奥氮平联合起始") and dim in ("D13a","D13b")
    restriction="†仅HGIE文拉法辛5–9日减停" if limited and dim=="D13a" else "†仅奥氮平联合起始" if limited else ""
    nil=unavailable(drug,reg,dim,opt)
    if nil:
        return nil,restriction,[],[],"结构与范围"
    if dim=="D16a":
        items,missing=pediatric_items(drug,reg,opt,children)
        value="A" if any(r[1]=="pos" for r in items) else "C" if any(r[1]=="neg" for r in items) else "D"
        return value,"",items,missing,"儿少试验分列"
    items,missing=[],[]
    for t in trials:
        if t["elderly"] and dim!="D16b":
            continue
        role=record_role(t,opt)
        if role is None:
            continue
        if role=="unresolved":
            missing.append(t["id"])
            continue
        code,level,rtype=effective(t,dim,opt)
        if code=="?":
            missing.append(t["id"])
        if (t["label"] or role=="pool") and code=="?":
            continue
        items.append([t["id"],role,code,t["parent"],rtype])
    letter,flag=grade(items,opt)
    if restriction:
        flag+=restriction
    return letter,flag,items,missing,"逐试验按层级聚合"


def count_cells(rows,gridinfo):
    sets={}
    for name,ids in gridinfo.items():
        counts=Counter(rows[i]["letter"] for i in ids)
        denominator=sum(counts[g] for g in GRADES)
        gap=counts["C"]+counts["D"]
        sets[name]=dict(counts=dict(counts),rated=denominator,gap=gap,
                        gap_pct=100*gap/denominator if denominator else None,
                        E_reassignment_only_gap_count_bounds=[gap,gap+counts["E"]])
    return sets


def candidate_status(letter,items,missing):
    if letter in ("n/a","—"):
        return "已完成","结构不适用或无该设定可评分的申报角色"
    if letter=="A" and any(r[1]=="pos" and r[2]=="R" for r in items):
        return "已完成","已有至少一项阳性比较的设计或实际入组依据；人群亚组疗效另审。"
    if missing or letter=="E":
        return "已核未决","当前来源及已定角色下的条件性字母。未决条款、角色或漏项可改变级别。"
    if not items:
        return "已核未决","在已核范围没有支持性记录；候选目录及判定链可能不全。"
    return "已核未决","给出已核记录下的字母；未纳入的急性候选或完整性不足仍需核对。"


def route_trial_counts(trials,opt):
    chosen=[(t,record_role(t,opt)) for t in trials]
    active=[(t,r) for t,r in chosen if r in {"pos","neg","pool"}]
    adults=[(t,r) for t,r in active if not t["elderly"]]
    adult_parents={t["parent"] for t,r in adults if t["parent"] and r!="pool"}
    own_parents={t["parent"] for t,r in adults if t["parent"] and r!="pool" and not t["reference"]}
    counts=Counter(r for t,r in adults)
    return dict(adult_comparisons=dict(counts),named_adult_parent_ids=sorted(adult_parents),
        named_count=len(adult_parents),named_adult_own_parents=len(own_parents),
        unconfirmed_parent_records=[t["id"] for t,r in adults if r!="pool" and not t["parent"]],
        unresolved_roles=[t["id"] for t,r in chosen if r=="unresolved"],all_reference_comparisons=sum(t["reference"] for t,r in active),
        elderly_design_records=[t["id"] for t,r in active if t["elderly"]],pooled_rows=[t["id"] for t,r in active if r=="pool"])


def run():
    raw=load(INPUT/"回传字段模板.json")
    template=next(t for t in raw["tables"] if t["name"]=="FDA候选440格")
    base=[dict(zip(template["headers"],r)) for r in template["rows"]]
    definition=load(INPUT/"维度与设定定义.json")
    trials=load(HERE/"independent_inputs.json")
    byrow=defaultdict(list)
    for t in trials:
        byrow[(t["drug"],t["regimen"])].append(t)
    children=load(HERE/"pediatric_25.json")
    report,all_cells,full_main,unresolved={},[],[],[]
    grouped={"成人核心19":[],"儿少D16a":[],"老年D16b":[],"精神病性D18":[]}
    for i,r in enumerate(base):
        dim=r["维度"]
        group={"D16a":"儿少D16a","D16b":"老年D16b","D18":"精神病性D18"}.get(dim,"成人核心19")
        grouped[group].append(i)
    cells_by_scenario={}
    for scenario,description,options in definition["FDA_scenarios"]:
        rows=[]
        for b in base:
            key=(b["药物"],b["方案候选"],b["维度"])
            letter,flag,items,missing,method=independent_cell(*key,options,byrow[key[:2]],children)
            status,scope=candidate_status(letter,items,missing)
            parents=sorted({x[3] for x in items if x[3] and x[1]!="pool"})
            support=[x[0] for x in items if x[2]!="?"]
            row=dict(scenario=scenario,id=b["候选格ID"],drug=key[0],regimen=key[1],dimension=key[2],
                     letter=letter,qualifier=flag,status=status,contributions=[[x[0],x[1],x[2]] for x in items],
                     distinct_parents=parents,unknown_or_unresolved=missing)
            rows.append(row)
            if scenario==MAIN:
                out=dict(b)
                out.update({"核查状态":status,"独立字母或NA或不评分":letter,"支持比较记录ID":"；".join(support),
                     "母试验去重数":len(parents),"适用限制":flag+" "+scope,"不确定性":"；".join(missing),
                     "既定规则下判断":method,"方法异议的敏感性结果":"见scenarios.json；条件性字母不等于确定纠错",
                     "复核者":AUTHOR,"日期":"2026-11-26"})
                full_main.append(out)
                if status=="已核未决":
                    unresolved.append(dict(id=row["id"],letter=letter,reason=scope,pending=missing))
        all_cells.extend(rows)
        cells_by_scenario[scenario]=rows
        report[scenario]=dict(name=description,statistics=count_cells(rows,grouped),
                              trial_counts=route_trial_counts(trials,options))
    if len(full_main)!=440 or len(all_cells)!=8360:
        raise ValueError("Incomplete result grid")
    main=cells_by_scenario[MAIN]
    keys=grouped["成人核心19"]
    rated={i for i in keys if main[i]["letter"] in GRADES}
    fixed=[s for s,rows in cells_by_scenario.items() if {i for i in keys if rows[i]["letter"] in GRADES}==rated]
    stable=[main[i]["id"] for i in sorted(rated) if len({cells_by_scenario[s][i]["letter"] for s in fixed})==1]
    save("stability.json",dict(scenarios=fixed,stable=len(stable),variable=len(rated)-len(stable),
                               stable_cell_ids=stable,variable_cell_ids=[main[i]["id"] for i in sorted(rated) if main[i]["id"] not in stable]))
    save("main_cells.json",full_main)
    save("unresolved_cells.json",unresolved)
    save("scenarios.json",all_cells)
    save("summary.json",report)


if __name__=="__main__":
    run()
