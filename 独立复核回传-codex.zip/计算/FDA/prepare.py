"""Normalize frozen independent extractions and separately extract the received comparator."""
import hashlib
import json
from pathlib import Path
import openpyxl

HERE = Path(__file__).resolve().parent
OUT = HERE.parents[1]
PACKAGE = OUT.parent
PHASE = OUT / "phase1"
INPUT = OUT / "计算" / "输入"
SOURCES = OUT / "新增原件" / "FDA计算"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def tier(value):
    value = str(value)
    if value in ("1","1b","2","3a","3b"):
        return value
    if "FDA" in value:
        return "1"
    if "其他监管" in value:
        return "1b"
    if "标签" in value:
        return "2"
    if "注册" in value:
        return "3b"
    if "3" in value:
        return "3a"
    return ""


def role(label):
    if "未建立" in label:
        return "neg"
    if label in ("阳性","支持","支持性","标签阳性","参照阳性","S5阳性"):
        return "pos"
    if "汇总" in label:
        return "pool"
    return "unresolved"


# Only groups specifically designed as older-population studies are routed here.
ELDERLY = {"FT0006","FT0007","FT0017","FT0028","FT0049","FT0064","FT0087","FT0106",
           "FT0133","FT0134","FT0146","FT0163","FT0164"}


def turner_key(drug, trial):
    """Exact sponsor IDs with explicit formulation and stratum translations."""
    if drug == "度洛西汀" and trial.startswith("F1J-MC-"):
        return "duloxetine", trial[7:-1]+"-"+trial[-1].upper()
    if drug == "米氮平":
        return "mirtazapine", trial+("/3220" if trial.startswith("003-02") else "")
    if drug == "安非他酮" and trial.startswith("SR "):
        return "bupropion_SR", trial[3:]
    if drug == "氟西汀":
        return "fluoxetine", {"62（轻度层）":"62-a (mild)","62（中度层）":"62-b (moderate)"}.get(trial,trial)
    if drug == "帕罗西汀" and trial.startswith("CR "):
        return "paroxetine_CR", trial[3:]
    if drug == "帕罗西汀" and trial.startswith("PAR "):
        return "paroxetine", trial[4:].lstrip("0") if trial in ("PAR 07","PAR 09") else trial[4:]
    if drug == "文拉法辛":
        if "（速释）" in trial:
            return "venlafaxine", "600A-"+trial.split("（")[0]
        if trial.startswith("0600B-"):
            return "venlafaxine_XR", trial.split("-")[1]
    if drug == "去甲文拉法辛":
        return "desvenlafaxine", trial.split("-")[-1]
    if drug == "伏硫西汀":
        return "vortioxetine", trial.split("_")[-1]
    return {"舍曲林":"sertraline","西酞普兰":"citalopram","艾司西酞普兰":"escitalopram"}.get(drug,""),trial


def normalize():
    lock = read(OUT / "第一阶段冻结清单.json")
    for member in lock["files"]:
        if member["path"].startswith("phase1/fda"):
            if hashlib.sha256((OUT / member["path"]).read_bytes()).hexdigest() != member["sha256"]:
                raise ValueError("First-stage freeze mismatch: "+member["path"])
    records, candidates, pediatric = {}, {}, []
    registry = read(PHASE / "fda_b" / "registry_dimension_options.json")
    for group in ("a","b"):
        directory = PHASE / ("fda_"+group)
        candidates.update({r["候选记录ID"]:r for r in read(directory/"candidates.json")})
        fields = {r["id"]:r for r in read(directory/"field_evidence.json")}
        for m in read(directory/"mapping.json"):
            ident = m["模型记录ID"]
            candidate = m.get("候选记录ID") or m.get("candidate")
            index_drug = m["药物"]
            parent_drug = index_drug
            if "参照" in m["role"]:
                parent_drug = m["试验"].split(" ")[0]
                if ident == "FT0106":
                    parent_drug = "伏硫西汀"
            if ident == "FT0135":
                parent_drug = "奥氮平"
            parent = parent_drug+"|"+m["parent"] if m["parent"] else None
            if ident == "FT0100":
                parent = None  # Label Trial 3; Well 84A is an inference, not a confirmed sponsor identity.
            records[ident] = dict(id=ident, candidate=candidate, drug=index_drug, regimen=m["方案"],trial=m["试验"],
                parent=parent, role=role(m["role"]), original_role=m["role"], reason=m["decision"],
                reference="参照" in m["role"], elderly=ident in ELDERLY, s5=ident in {"FT0164","FT0165","FT0166","FT0167"},
                label=m["role"]=="标签阳性" or (role(m["role"])=="pool" and m["试验"].startswith("标签")),
                fields={},turner=None)
        for row in read(directory/"dimensions.json"):
            ident, dim = row["模型记录ID"], row["维度"]
            t=records[ident]
            fact=fields.get(t["candidate"],{}).get("dimensions",{}).get(dim,{})
            t["fields"][dim]=dict(code=row["独立代码_R_X_P_N_问号"],tier=tier(row["来源级别"]),rtype=row["R依据类型"],
                 why=row["排除范围与时态"], quote=row["原文短摘"][:800],source=row["证据文件及SHA"],
                 page=row["物理页与印刷页"],status=row["核查状态"],time_only=fact.get("timing"),
                 registry=registry.get(t["candidate"],{}).get(dim))
        if group=="a":
            for r in read(directory/"pediatric_D16a.json"):
                results=r["independent_result"]
                level=tier(r["evidence"][0]["tier"])
                pediatric.append(dict(id=r["id"],drug=r["drug"],parent=r["parent"],reference=r["role"]=="参照",
                    role="pos" if "阳性" in results else "neg" if "未建立" in results else "unresolved",
                    role_tier=level, field_tier=level, code=r["D16a_code"], rtype=r["basis"],number=r["number"],
                    note=results+"；"+r["limitations"],evidence=r["evidence"]))
        else:
            for q in candidates.values():
                cid=q["候选记录ID"]
                if not cid.startswith("FYP") or cid not in fields:
                    continue
                f=fields[cid]
                d=f["dimensions"]["D16a"]
                pediatric.append(dict(id=cid,drug=q["药物"],parent=q["确认母试验ID"],reference=False,
                    role=role(q["role"]), role_tier="1",field_tier=tier(d["evidence"]["level"]),code=d["code"],
                    rtype=d["rtype"],number=q["分析集与人数"],note=d["reason"]+"；"+q["纳入范围及理由"],
                    evidence=[d["evidence"]]+[x["evidence"] for x in f["facts"]]))
    for path in sorted(PHASE.glob("fda_crosscheck_guide_a*.json")):
        for row in read(path)["记录"]:
            for dim, val in row["逐维度"].items():
                ident=row["模型记录ID"]
                value=records[ident]["fields"][dim]
                reason=val.get("理由",val.get("依据",""))
                rtype=val.get("R依据类型","")
                if not rtype and val.get("code")=="R":
                    rtype="实际入组"
                value.update(code=val.get("代码",val.get("code")),tier="1",rtype=rtype,why=reason,
                             quote=" | ".join(x["原文短摘"] for x in row["证据"]),
                             source=path.name+" / "+ident,page="；".join(str(x["准确物理页"]) for x in row["证据"]),
                             status="已完成",time_only=False)
    # The previous v43 analysis was known to the calculator. Original page checked again after freeze.
    anchor=records["FT0135"]["fields"]["D13a"]
    anchor.update(code="R",tier="1",rtype="设计要求",
        why="仅HGIE文拉法辛5–9日交叉减停，不能推定常规双抗抑郁药合用。",status="已完成",
        source="FDA-a15d8b469151 SHA256 a15d8b469151ea0100cc8925a04180435b8852cb4846002b53cfc771734fdc9f",
        page="物理296–297，统计审评印16–17，Study Period III",
        quote="During the taper phase (Study Period III), patients were assigned randomly ... For patients assigned to any other treatment group than venlafaxine, the venlafaxine dose were tapered off over a 5- to 9- day period.")
    old_keys={r["id"] for r in pediatric}
    if len(pediatric)!=25 or len(old_keys)!=25 or len(records)!=167:
        raise ValueError("Incomplete pediatric or adult input")
    for row in pediatric:
        # Adolescent design and actual counts are distinct; a mixed-age study without an age-stratum minimum
        # does not prove any specified arm enrolled any particular number by age.
        if row["id"] in {"FYP0014","FYP0015"}:
            row["number"]={"FYP0014":"表5全臂合计12–17岁209人","FYP0015":"表6全臂合计12–17岁254人"}[row["id"]]
            row["note"]+="；FDA-0d892db3e4de 物理17，不能从全臂小计推断本药人数。"
        if row["id"] in {"FYP0018","FYP0019"}:
            row["note"]+="；FDA-11b7427da32f 物理16、19，专设7–12及13–17岁人群，设计覆盖、无本臂12–17精确数。"
        if row["id"] in {"FYP0025","FYP0026"}:
            row["note"]+="；FDA-70c6d820903e 物理33、51，分儿童及12–17岁青少年；不能从总例数推算分龄本药人数。"
        if row["id"] in {"FYP0020","FYP0021","FYP0022"}:
            cross=next(x for x in read(OUT/"交叉复核"/"FDA指定试验及分母.json") if row["id"] in x["ids"])
            row.update(role="neg",role_tier="3a",number=cross["finding"],
                       note="逐案CSR的预设主要终点未建立；监管标签三项概述与之相容，逐试验FDA结论链仍待补。")
            row["evidence"].extend(cross["evidence"])
    wb=openpyxl.load_workbook(SOURCES/"Turner2022_S2_Data.xlsx",read_only=True,data_only=True)
    source={(str(r[5]),str(r[6])):(i,str(r[7])) for i,r in enumerate(list(wb.active.values)[1:],2)}
    for r in records.values():
        if r["reference"] or r["s5"]:
            continue
        k=turner_key(r["drug"],r["trial"])
        if k in source:
            idx,value=source[k]
            r["turner"]={"row":idx,"key":list(k),"outcome":value,"role":"pos" if value=="positive" else "neg"}
    save("independent_inputs.json",list(records.values()))
    save("pediatric_25.json",sorted(pediatric,key=lambda r:r["id"]))
    mapped={t["candidate"] for t in records.values()}|old_keys
    save("candidate_dispositions.json",[dict(id=k,drug=v["药物"],trial=v["试验名称候选"],mapped=k in mapped,
            role=v.get("role") or v["纳入范围及理由"],reason=v["未决或身份冲突"]) for k,v in sorted(candidates.items())])


def extract_comparator():
    folder=PACKAGE/"04_当前判断_第二阶段打开"/"FDA_v43"
    xlsx=next(folder.glob("*接收修正版.xlsx"))
    wb=openpyxl.load_workbook(xlsx,read_only=True,data_only=True)
    keys={}
    rows=iter(wb["各设定矩阵"].values)
    cols=[x.split(" ")[0] for x in next(rows)[3:25]]
    for r in rows:
        for i,dim in enumerate(cols,3):
            keys[(r[2],r[0],r[1] or "",dim)]=r[i]
    data=read(PACKAGE/"05_既有计算程序_第二阶段参考"/"02_tasks_and_rules"/"recalculated.json")
    output=[]
    for scenario,rows in data["results"].items():
        for r in rows:
            for dim,c in r["cells"].items():
                key=(scenario,r["drug"],r["regimen"],dim)
                display=keys.pop(key)
                if str(display).rstrip("*†")!=c[0]:
                    raise ValueError(f"Matrix mismatch: {key}, {display}, {c[0]}")
                evidence=[[v[0],v[1],v[2],v[3],
                           "汇总" if "只在汇总层面写明入组" in str(v[4]) else "",
                           v[-1]] for v in c[1]]
                output.append([*key,display,c[0],c[3].get("flag",""),evidence])
    if len(output)!=8360 or keys:
        raise ValueError("Incomplete 19-scenario comparator")
    save("received_inputs.json",output)
    save("received_source.json",dict(workbook=xlsx.name,sha256=hashlib.sha256(xlsx.read_bytes()).hexdigest(),
       machine="05_既有计算程序_第二阶段参考/02_tasks_and_rules/recalculated.json",
       verified_cells=len(output),sheet="各设定矩阵",trace_scope="机器源中试验贡献逐格取出角色、ID、代码、层级、汇总指示及来源，不将接收字母复制至独立输出。"))


if __name__=="__main__":
    normalize()
    extract_comparator()
