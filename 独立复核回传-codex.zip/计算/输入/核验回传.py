"""Validate record coverage and required fields. Does not adjudicate scientific correctness."""
from pathlib import Path
import json,sys,collections
root=Path(__file__).resolve().parents[1]
if len(sys.argv)!=2:raise SystemExit('用法：python 核验回传.py 已填回传.xlsx 或 已填回传.json')
path=Path(sys.argv[1]);template=json.loads((Path(__file__).parent/'回传字段模板.json').read_text(encoding='utf-8'))
if path.suffix.lower()=='.xlsx':
    from openpyxl import load_workbook
    w=load_workbook(path,read_only=True,data_only=True)
    returned={s.title:list(s.values) for s in w};w.close()
else:
    r=json.loads(path.read_text(encoding='utf-8'))
    returned={t['name']:[t['headers'],*t['rows']] for t in r['tables']}
problems=[];report={}
required={'指南来源37':[4,5,7,8,9],'指南陈述626':[5,6,7,8,9,10,11,12,13,14,17,18],'指南418格':[7,8,9,12,14,15],'FDA源表候选235':[7,8,9,10,11,12,13,14,15,16,18,19],'FDA试验维度3674':[7,10,11,12,13,14,16,17],'FDA候选440格':[7,8,10,11,12,14,15]}
for t in template['tables']:
    name=t['name']
    if '核查状态' not in t['headers']:continue
    ri=t['headers'].index('核查状态')
    key=lambda r:(r[0],r[4]) if name=='FDA试验维度3674' else (r[0],)
    expected={key(r) for r in t['rows']}
    got=returned.get(name,[])
    if not got:problems.append(name+'：缺工作表');report[name]={'expected':len(expected),'returned':0};continue
    if list(got[0])[:len(t['headers'])]!=t['headers']:problems.append(name+'：字段名或顺序改变');continue
    rows=[list(r) for r in got[1:] if r and r[0]]
    keys=[key(r) for r in rows];counts=collections.Counter(str(r[ri] or '未开始') for r in rows)
    missing=expected-set(keys);duplicates=[str(k) for k,v in collections.Counter(keys).items() if v>1]
    if missing:problems.append(f'{name}：缺{len(missing)}条既有ID')
    if duplicates:problems.append(f'{name}：重复ID {duplicates[:10]}')
    for row in rows:
        if row[ri]=='已完成':
            empty=[t['headers'][j] for j in required[name] if j>=len(row) or row[j] in (None,'')]
            if empty:problems.append(f'{name} {key(row)}：已完成但缺字段 {empty}')
            if name=='指南418格' and any(row[j]=='未确定' for j in [7,8,9]):problems.append(f'{name} {key(row)}：未确定不得标已完成')
            if name=='指南418格' and any(row[j]=='是' for j in [8,9]) and not row[10]:problems.append(f'{name} {key(row)}：有覆盖但无陈述依据ID')
    completed={key(r) for r in rows if r[ri]=='已完成'}
    report[name]={'expected':len(expected),'returned':len(rows),'states':dict(counts),'all_expected_ids_complete':expected<=completed and not duplicates,'missing_ids':[str(k) for k in sorted(missing)[:20]],'duplicate_ids':duplicates}
out={'package_id':template['package_id'],'coverage':report,'structural_issues':problems,'all_items_marked_complete':not problems and all(v.get('all_expected_ids_complete',False) for v in report.values()),'meaning':'结构与填报覆盖检查，不验证引文真实性、判断正确性或独立性。未完成范围必须如实报告。'}
print(json.dumps(out,ensure_ascii=False,indent=2))
sys.exit(1 if problems else 0)
