"""Replay the pinned R1 v43 calculation, then apply six adjudicable trial-arm facts in a temporary copy."""
import argparse,json,sys,hashlib,subprocess,tempfile,shutil
from pathlib import Path
from collections import Counter
HERE=Path(__file__).resolve().parent
OUT=HERE.parents[1]
read=lambda p:json.loads(p.read_text())
def save(n,v):(HERE/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main(root,with_well=False):
 target=HERE.parent/"现行口径_含84A具名FDA审评" if with_well else HERE
 target.mkdir(exist_ok=True)
 def save(n,v):(target/n).write_text(json.dumps(v,ensure_ascii=False,indent=2))
 mani=OUT/'计算/输入/R1_原包文件清单.json'
 if digest(mani)!='59052c97b1b0529f6368520bd05b3a8d221d9a1beb4c72d91ccd6e618d191103':raise ValueError('R1 manifest mismatch')
 files=read(mani)['files']
 with tempfile.TemporaryDirectory() as tmp:
  work=Path(tmp);prefix='05_既有计算程序_第二阶段参考/04_recompute/'
  for name,info in files.items():
   if not name.startswith(prefix):continue
   src=root/name;dest=work/name.removeprefix(prefix)
   if digest(src)!=info['sha256']:raise ValueError(name)
   dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
  eng=work/'engine';exe=eng/'recalculate_revision.py';data=eng/'recalculated.json';baseline=read(data)
  subprocess.run([sys.executable,str(exe)],cwd=eng,check=True,capture_output=True)
  if read(data)!=baseline:raise ValueError('原版引擎重建与固定结果不同')
  fts=read(OUT/'计算/输入/回传字段模板.json')['tables'][4]['rows'][::22];ident={r[0]:r for r in fts}
  changes=[]
  for e in read(OUT/'第二阶段/原文复看_裁决建议与逐条补证.json'):
   if e['apply_to_retained']:
    f=ident[e['ft']];changes.append(dict(ft=f[0],drug=f[1],regimen=f[2] or '',trial=f[3],dim=e['dimension'],code=e['code'],r_type=e['r_type'],level=e['level'],basis=e['source']+' 物理'+str(e['page'])+' '+e['locator']+' '+e['quote']+' '+e['why']))
  assert len(changes)==6 and len({(r['ft'],r['dim']) for r in changes})==6
  if with_well:
   w=read(OUT/'第二阶段/Well84A具名FDA决定与设计.json')
   f=ident[w['ft']]
   for u in w['updates']:
    refs=[w['evidence'][i] for i in u['evidence_indices']]
    basis=' ｜ '.join(z['sha256']+' 物理'+str(z['page'])+' '+z['locator']+' '+z['quote'] for z in refs)+' '+u['why']
    changes.append(dict(ft=f[0],drug=f[1],regimen=f[2] or '',trial=f[3],dim=u['dimension'],code=u['code'],r_type='design' if u['rtype']=='设计要求' else None,level='1',basis=basis))
  (eng/'r1_fields.json').write_text(json.dumps(changes,ensure_ascii=False))
  hook="""    for z in json.loads((WORK/'r1_fields.json').read_text()):
        for t in trials:
            if (t.key[0],t.key[1],t.tid)==(z['drug'],z['regimen'],z['trial']):
                change_code(t,z['dim'],z['code'],z['basis'],z['level'])
                t.codes[z['dim']][3]['v43_r_type']=z['r_type']
"""
  mark="    if not opt.get('hdao2',True):trials[:]="
  source=exe.read_text()
  if with_well:
   boundary="E['apply_revision']=apply_revision"
   set_level="""for t in E['FDA_N']:
    if t.key[0]=='安非他酮' and t.tid=='标签 Trial 3（门诊）':
        t.level='1 FDA审评 84A'
"""
   assert source.count(boundary)==1
   source=source.replace(boundary,set_level+boundary)
   hook+="""    for t in trials:
        if t.key[0]=='安非他酮' and t.tid=='标签 Trial 3（门诊）':
            t.level='1 FDA审评 84A'
            t.parent_id='安非他酮|Well 84A'
            for dimension,entry in t.codes.items():
                if entry[0]=='?':entry[1]='1'
"""
  assert source.count(mark)==1;exe.write_text(source.replace(mark,hook+mark))
  subprocess.run([sys.executable,str(exe)],cwd=eng,check=True,capture_output=True);new=read(data)
  for j in changes:
   record=next(t for t in new['all_trials'] if (t['drug'],t['regimen'],t['trial'])==(j['drug'],j['regimen'],j['trial']))
   assert record['codes'][j['dim']]['r_type']==j['r_type'] and record['codes'][j['dim']]['basis']==j['basis']
  output=[];changed=[];summ={}
  for scen,drugs in new['results'].items():
   letters=Counter();core=Counter();secondary={d:Counter() for d in ['D16a','D16b','D18']}
   for j,(row,old) in enumerate(zip(drugs,baseline['results'][scen]),1):
    assert (row['drug'],row['regimen'])==(old['drug'],old['regimen'])
    for d,g in row['cells'].items():
     before=old['cells'][d];v=dict(scenario=scen,id=f'FM{j:02d}-{d}',drug=row['drug'],regimen=row['regimen'],dim=d,letter=g[0],v43=before[0],flags=g[3].get('flag',''),support=g[3],note=g[2],changed_evidence=g!=before)
     output.append(v);letters[g[0]]+=1
     if d in secondary:secondary[d][g[0]]+=1
     else:core[g[0]]+=1
     if g!=before:changed.append(dict(**v,old_detail=before,new_detail=g))
   summ[scen]=dict(全网格=dict(letters),成人核心=dict(core),次要维度={d:dict(c) for d,c in secondary.items()},可评分成人=new['facts'][scen],候选格=440,字母变化=sum(r['scenario']==scen and r['letter']!=r['v43'] for r in changed))
  assert len(output)==8360 and len(summ)==19
  save('定向修正输入.json',changes);save('19设定8360格.json',output);save('19设定计数.json',summ);save('与接收底稿逐格差异.json',changed)
  save('执行验证.json',dict(原计算再运行与完整JSON深相等=True,原引擎SHA256=files[prefix+'engine/recalculate_revision.py']['sha256'],临时引擎修改=('另加已具名的84A、FDA来源开关及9个原文维度。' if with_well else '')+'增加固定的六个(索引药、方案、试验、维度)原文事实及R依据类型，所有旧文件字节保持原样。',去重计数=new['facts']['trial_counts'],改动字母总数=sum(x['letter']!=x['v43'] for x in changed),证据明细变动数=len(changed)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--package',type=Path,default=HERE/"R1固定输入");p.add_argument('--well84a',action='store_true');args=p.parse_args();main(args.package.resolve(),args.well84a)
