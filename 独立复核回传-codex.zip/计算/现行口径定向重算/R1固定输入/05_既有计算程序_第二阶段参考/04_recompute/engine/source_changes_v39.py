def apply_source_changes_v39(trials,change,opt):
 for t in trials:
  if t.key[0]!='伏硫西汀':continue
  if t.tid=='LuAA21004_315':
   t.result_source='NDA204447_1物理45–48；204447Orig1s000StatR物理19、31（印刷18、30）；204447Orig1s000OtherR物理69–70、73–74、77'
   t.result_basis='FDA统计审评主要8周MADRS MMRM：15mg差−1.5（SE1.21），p=.224；20mg差−2.8（SE1.21），p=.023。每剂量顺序检验阈值.025；20mg主要成立，随后应答p=.332未通过，后续不可确证化。DUL差−4.1（SE1.21）、p<.001，仅S6。FDA现场核查对所检315中心的疗效/安全数据认为可靠，不等于全部中心所有条款已核。'
   t.codes['D08a'][2]+='；v39：OtherR物理74记一例治疗期间妊娠后揭盲并退出，不能据此认定孕妇获准入组，也不证明妊娠亚组疗效。'
   t.codes['D13b'][2]+='；v39：OtherR物理74将一次急诊氯硝西泮使用记为违禁药事件；该药为抗焦虑药，此个案不补齐AP/稳定剂名单，D13b仍依本试验发表的治疗期间限制（3a），不升级为FDA完整清单。'
   t.codes['D15'][2]+='；v39：OtherR物理69页图为MADRS≥26、CGI-S≥4；文本提取丢失CGI-S等号，不据此制造>4/≥4来源冲突。'
  elif t.tid=='LuAA21004_316':
   t.result_source+='；204447Orig1s000StatR物理19–20、32；OtherR物理70、74、77'
   t.result_basis+=' v39：StatR物理32 Table25重复p=.058/.002及舍入后的差/SE，没有置信区间；不能充当医学审评CI勘误。此表引用CSR11.f第81页，而医学审评索引不同，申请时以试验号、表号与数值共同定位。所查316中心30人记录被认为可靠，不能解释全试验MADRS最低20的来源。'
   t.codes['D15'][2]+='；v39：OtherR物理70页图确认CGI-S≥4，文本提取显示>4为等号丢失。'
  elif t.tid=='11984A':
   t.result_source='NDA204447_1物理25；204447Orig1s000StatR物理56（印刷55）Table46'
   t.result_basis='FDA主要8周MADRS ANCOVA/LOCF：FAS按PBO/DUL/VOR2.5/5/10为145/149/155/155/151，总755；VOR三剂量差−1.4/−1.7/−1.5，p=.219/.132/.185，DUL差−2.0、p=.074，均未分离。FDA判failed；2.5mg非主要确证剂量。Table46标题和正文为MADRS，表内首格却印HAMD-24，保留该标注矛盾，采用明确的主要终点定义，不据表内首格换量表。完整CSR Panel22（报告82页）及原协议仍待定位。'
  elif t.tid=='LuAA21004_303':
   t.result_source='NDA204447_1物理25；204447Orig1s000StatR物理56–57（印刷55–56）Table47'
   t.result_basis='FDA主要6周HAM-D24 ANCOVA/LOCF，FAS PBO286/VOR5mg292，总578；差−0.7（SE.887）、p=.407，未建立疗效。不能把入选MADRS阈值当作主要终点，也不改成8周。完整纳排及治疗期禁药附件仍缺。'
  elif t.tid=='LuAA21004_304':
   t.result_source='NDA204447_1物理25；204447Orig1s000StatR物理57–58（印刷56–57）Table48'
   t.result_basis='FDA主要8周HAM-D24 ANCOVA/LOCF，FAS按PBO/DUL/VOR2.5/5为149/149/146/153，总597；VOR差−1.5（SE1.04）、p=.138和−0.6（SE1.04）、p=.577，均未建立疗效。DUL差−3.0（SE1.05）、p=.005，仅S6；参照药分离不将伏硫西汀转阳性。完整禁药附件及未报告字段继续待补。'
  elif t.tid=='LuAA21004_317':
   t.result_source+='；204447Orig1s000StatR物理58（印刷57）Table49'
   t.result_basis+=' v39：FDA Table49直接确认FAS149/143/142与p=.597/.745，主要阴性结果的监管依据不再只依医学汇总；本节标题及表均317，但设计段首句印316，按剂量10/15mg、表号和分母识别，保留原文标注问题，不混入316。'
  else:continue
  for v in t.codes.values():
   if 'v39' in v[2]:v[3]['revision']='v39 FDA统计与现场核查指定原页'
