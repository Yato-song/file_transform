"""Apply the v42 trial-specific original-source corrections before reference-arm copying."""
import json
from pathlib import Path


def apply_additional_changes(trials, change_code, opt, apply_temporal_rules):
    revisions = json.loads(Path(__file__).with_name("source_changes_v42.json").read_text())
    indexed = {(trial.key[0], trial.tid): trial for trial in trials}
    for record in revisions:
        if record["option"] and not opt.get(record["option"]):
            continue
        trial = indexed.get((record["drug"], record["trial"]))
        if trial is None:
            continue
        dimension = record["dimension"]
        change_code(trial, dimension, record["code"], record["basis"], record["level"])
        trial.codes[dimension][3]["revision"] = "v42 " + record["id"]

        # Apply the existing time-window sensitivity to the newly supplied criterion only.
        if opt.get("s18") or opt.get("s19"):
            focused = trial.copy()
            focused.codes = {dimension: trial.codes[dimension]}
            apply_temporal_rules([focused], opt)
            trial.codes[dimension] = focused.codes[dimension]
