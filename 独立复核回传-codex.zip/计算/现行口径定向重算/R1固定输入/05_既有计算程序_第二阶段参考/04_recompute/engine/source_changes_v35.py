def apply_source_changes_v35(trials,change,opt):
 for t in trials:
  if t.key[0]=='艾司西酞普兰' and t.tid in ['99001','99003']:
   loc='FDA Lexapro 2003 S007/S001审评物理78–79（印刷37–38），完整14条排除附录；'+('99003物理58明确沿用99001同一纳排。' if t.tid=='99003' else '')
   for d,b in [('D03','第2条以current修饰DSM-IV诊断清单，含OCD；依既定时态规则记P。'),('D05','第2条明确current eating disorders，依既定时态规则记P。')]:
    change(t,d,'X' if opt.get('s19') else 'P',loc+b+('S19仅时间限定P转X。' if opt.get('s19') else ''),'1')
   for d,c,b in [
    ('D08a','X','第1条直接排除育龄女性妊娠/妊娠试验阳性。'),
    ('D08b','X','第1条直接排除哺乳。'),
    ('D09','X' if opt.get('s19') else 'P','第4条排当前显著自杀风险及/或MADRS第10项≥5；非全部自伤史。'),
    ('D10','P','第11–13条为临床显著实验室异常、干扰安全/疗效判断的疾病、严重疾病或后遗症；有程度限定，非所有躯体病。'),
    ('D13a','X','第5条禁用其他抗抑郁药：筛前FLX5周、其他SSRI/TCA2周、SNRI1周（米氮平2周）、MAOI2周；物理55/60并说明研究期间精神活性合并药原则禁用。违禁用药记录不等于允许联合。'),
    ('D13b','X','第5条口服抗精神病药筛前2周、长效针剂6个月；研究期间精神活性合并药禁用。失眠苯二氮䓬稳定6个月/偶发低剂量例外不允许抗精神病联合。'),
    ('D14','P','第7条只排既往西酞普兰不反应，包括当前发作；不能扩展为所有SSRI或至少两种AD失败。'),
    ('D15','X','物理52纳入MADRS≥22且≤40；物理55/60又以最高39、40为违反方案；40边界单列Q019-13，轻度排除仍由≥22支持。')]:
    change(t,d,c,loc+b,'1')
   # Replace cross-study inference with this study's own CTD when that source is allowed.
   if opt.get('l3a'):
    pg='1–2' if t.tid=='99001' else '27–28'
    change(t,'D18','X','PMDA公开申办方CTD 79000500_22300AMX00517_K128_1物理'+pg+'，本试验直接列精神病性障碍（包括有精神病性特征的抑郁）；替代旧跨MD01推定。','3a')
   for d in ['D03','D05','D08a','D08b','D09','D10','D13a','D13b','D14','D15','D18']:
    t.codes[d][3]['revision']='v35 本试验指定原页复核'
  if opt.get('l3a') and (t.key[0],t.tid)==('艾司西酞普兰','SCT-MD-02'):
   change(t,'D16b','R','PMDA公开申办方CTD 79000500_22300AMX00517_K129_1物理54（印刷784）表2.7.6.8.6-3：ESC安全臂125人中70岁及以上2人；按本药物臂实际入组，不再仅据年龄上限80岁。','3a')
