def apply_source_changes_v30(trials, change, opt):
    for t in trials:
        if t.key[0] != '度洛西汀' or t.tid not in ('F1J-MC-HMAYa','F1J-MC-HMAYb'):
            continue
        a = t.tid.endswith('a')
        t.result_source = 'FDA 021427_s000_Cymbalta_Medr_P1物理7；NDA021427_副本统计物理10表3；PMDA申办方CTD2.7.6物理498/526（补充分析）'
        t.result_basis = ('FDA按LOCF接受HMAYa；度洛西汀80/120mg及PAR参照结果分别记录。' if a else 'FDA将HMAYb按主要LOCF归失败，继续未建立疗效；申办方MMRM的80mg p=.045、120mg p=.014和PAR p=.089另列，不能据论文显著性升级。')
        if not opt.get('l3a'):
            continue
        page = '491' if a else '519'
        change(t,'D12','X','PMDA公开的申办方CTD2.7.6物理'+page+'明确本研究为≥18岁门诊MDD。属申办方试验汇总3a，不是PMDA独立审评1b；S2/S3不采此补证。','3a')
        ages = '40mg BID臂19.32–64.46；60mg BID臂20.90–74.38；PAR20mg臂21.25–61.94。仅120mg/day度洛西汀臂确证≥65。' if a else '40mg BID臂21.34–74.97；60mg BID臂20.10–73.26；PAR20mg臂20.90–74.19。度洛西汀两个剂量臂均含≥65。'
        change(t,'D16b','R','PMDA公开申办方CTD2.7.6物理'+('497表2.7.6.5.9-4' if a else '525表2.7.6.5.10-4')+'，ITT分臂实际年龄：'+ages+'仅为实际入组证据，不是老年亚组疗效。','3a')
        # The P code remains supported by FDA; the more precise four-week detail
        # is attached only where original publications are permitted.
        b=t.codes['D14'][2]
        change(t,'D14','P',b+' v30原论文补充（3a，仅本设定允许时）：'+('Detke2004印刷459 §2.2' if a else 'Perahia2006印刷368 §2.2')+'将每次充分治疗规定为本次发作治疗剂量至少4周；未明列帕罗西汀失败条款的具体剂量，不借HMAT外推。','1')
        t.codes['D14'][3]['supplemental_source']='3a'
