def apply_source_changes_v27(trials, change, opt):
    for t in trials:
        if t.key[0] == '帕罗西汀' and t.tid in ['PAR 02-001', 'PAR 03-001']:
            change(t, 'D04a', 'P', 'FDA既有原发焦虑障碍排除按DSM-III分类映射PTSD；适应障碍是D04b的依据，不是PTSD的直接条款。', '1')
        if t.key[0] == '帕罗西汀' and t.tid == 'PAR 02-001':
            # Earlier source-1 enrollment evidence actually comes from the sponsor CSR.
            change(t, 'D16b', 'N', 'FDA入选至少18岁，无上限；GSK药物臂实际入组属于3a，未采用3a时只按允许入组。', '1')
            if opt.get('l3a'):
                change(t, 'D16b', 'R', 'GSK 29060/02/001 CSR（3a）物理63、表V.3，既有已核实际年龄记录：帕罗西汀组2例≥65岁。纠正来源类别，非新增入组证据。', '3a')
                change(t, 'D10', 'P', 'paroxetine02001_CSR.pdf物理30：未稳定且显著的肾、肝、呼吸、心血管或内分泌病、癫痫；另排筛选实验室显著异常。此清单没有单列ECG异常，不从其他方案复制。', '3a')
        if opt.get('l3a') and t.key[0]=='伏硫西汀' and t.tid in ['LuAA21004_315','LuAA21004_316']:
            basis = ('Mahableshwarkar2015原文物理5表1：15mg臂实际年龄21–75、20mg臂19–72；药物臂含≥65岁。' if t.tid.endswith('315') else 'Jacobsen2015原文印刷578表1：10mg臂实际年龄18–68、20mg臂18–75；药物臂含≥65岁。')
            change(t, 'D16b', 'R', basis+'记实际入组，不证明老年亚组单独疗效。', '3a')
