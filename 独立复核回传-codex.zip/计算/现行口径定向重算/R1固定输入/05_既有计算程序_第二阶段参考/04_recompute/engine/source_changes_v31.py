def apply_source_changes_v31(trials, change, opt):
    for t in trials:
        if t.key[0]=='艾司西酞普兰' and t.tid in ('99001','99003'):
            # FDA says similar, not identical. Do not present the MD-01 inference as
            # direct trial-specific FDA evidence in the restricted-source analyses.
            dims=['D09','D10','D13a','D13b','D14','D08a','D08b']
            for d in dims:
                change(t,d,'?','FDA Lexapro MedR P1物理29/31仅称欧洲试验条件与美国研究相似，并非逐项相同；撤回旧“推定同MD-01”的直接FDA编码。仅FDA来源下该条未确认。','1')
            if not opt.get('l3a'):continue
            loc='PMDA公开申办方CTD K128_1物理'+('1–3（印刷671–673）' if t.tid=='99001' else '27–29（印刷697–699）')
            vals={
            'D09':('P','排除研究者判断高自杀风险或MADRS第10项≥5者。'),
            'D10':('P','排除严重疾病/后遗症、影响评估的疾病及临床显著实验室异常；并非排除全部躯体共病。原X系跨试验推定，按本试验完整列出的条款改P。'),
            'D13a':('X','禁其他抗抑郁药；FLX筛前5周、其他SSRI/TCA2周、SNRI1周（米氮平2周）、MAOI2周。'),
            'D13b':('X','口服抗精神病药筛前2周、长效针剂6个月；列为合并禁药。稳定6个月的失眠用苯二氮䓬例外不等于允许抗精神病联合。'),
            'D14':('P','排除既往及当前发作对西酞普兰治疗抵抗者；不沿用MD-01的SSRI或≥2其他抗抑郁药失败条件。'),
            'D08a':('X','明确排除妊娠及筛查妊娠试验阳性者；有生育能力女性须有效避孕。'),
            'D08b':('X','明确排除授乳中女性。')}
            for d,(c,b) in vals.items():
                if opt.get('s19') and d=='D09':c='X';b='[S19：当前自杀风险/近期未遂的P按既定时间规则记X] '+b
                change(t,d,c,loc+'，3a：'+b,'3a')
        if t.key[0]=='伏硫西汀' and t.tid in ('LuAA21004_305','LuAA21004_304'):
            change(t,'D16b','N','FDA所列18–75岁是允许年龄，旧R的类型已是permit；统一写N，不能声称该药物臂实际入组≥65。新CTD只给平均年龄，仍未解决分臂年龄。','1')
            if not opt.get('l3a'):continue
            loc='PMDA公开申办方CTD '+('K130_2物理35（2.7.6.35-2）' if t.tid.endswith('305') else 'K133_2物理8–9（2.7.6.40-2/3）')
            for d,c,b in [('D02','X','明确排除现患或既往智力障碍；按既定F76取本试验直接条款，替代FDA多试验汇总的显著轴II障碍P。'),('D18','X','明确含伴精神病性特征的大抑郁及现患/既往精神病性障碍。'),('D08a','X','明确排除妊娠。'),('D08b','X','明确排除授乳。')]:change(t,d,c,loc+'；3a：'+b,'3a')
            if t.tid.endswith('304'):
                change(t,'D14','P',loc+'：两种充分抗抑郁药各≥6周无效；另单列既往度洛西汀不反应，不能遗漏参照药抵抗条件。','3a')
        if opt.get('l3a') and (t.key[0],t.tid) in [('伏硫西汀','12541A'),('度洛西汀','12541A度洛西汀参照臂（老年）')]:
            loc='PMDA公开申办方CTD K134_2物理15（2.7.6.42-2）'
            change(t,'D18','X',loc+'明确排除现患/既往精神病性障碍，括注包含精神病性抑郁；原?补X，3a。','3a')
            change(t,'D14','P',loc+'明确排除两种充分抗抑郁药各≥6周无效，另排除既往或本次发作度洛西汀不反应。','3a')
