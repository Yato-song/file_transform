def apply_source_changes_v28(trials, change, opt):
    for t in trials:
        if t.key[0] == '安非他酮' and t.tid == '标签 Trial 3（门诊）':
            # Identity is independent of evidence hierarchy. The original label record remains one record.
            t.parent_id = '安非他酮|Well 84A'
            t.result_source = '美国标签第14节表6；GSK Well 84A结果摘要物理1–3（2005-09-20）'
            t.result_basis = '多特征对应推定为Well 84A：IR 300mg/day、门诊6周、5中心，疗效110/106及基线/变化相符；申办方关联Lineberry1990。不是FDA明示方案号对照表。随机112/112；疗效110/106；安全110/109。主要HAMD21第42天LOCF p=.0054。标签调整组差−3.9与摘要未调整均值差−3.35分列；标签证据层级仍为2。'
            if opt.get('l3a'):
                supplements = {
                    'D01': ('P', '排除近1年酒精或物质滥用；不能扩写为所有既往物质使用障碍均排除'),
                    'D05': ('P', '排除癫痫易感因素，包括神经性厌食或贪食史；不将两类病史扩写为全部进食障碍'),
                    'D08a': ('X', '排除妊娠女性，或拒绝使用可接受避孕措施者'),
                    'D08b': ('X', '明确排除哺乳女性'),
                    'D10': ('P', '排除不稳定躯体情况及癫痫易感因素；未声称排除全部稳定疾病'),
                    'D15': ('X', '筛选Day−6及基线Day0 HAMD≥20；导入降幅同页同时写不得≥20%下降及排除>20%变化，端点冲突保留，不擅自统一'),
                    'D16b': ('N', '入选≥18岁、摘要无上限；只证明允许，安全人群均龄41.9/40.8不能证明本药臂≥65岁实际入组'),
                }
                for d,(code,basis) in supplements.items():
                    change(t,d,code,'GSK Well 84A原始结果摘要物理1–2（3a）；'+basis+'。摘要非完整协议，未列维度保持未知。','3a')
        if t.key[0] == '奥氮平' and t.tid in ('HDAO-1','HDAO-2'):
            if opt.get('l3a'):
                change(t,'D13b','X','Thase2007印刷225（原论文物理2），禁主要中枢作用合并用药，劳拉西泮例外；既有依据实为3a论文，纠正原来源1标记。FDA关键清单中的既往氯氮平/长效针剂不能替代完整合并用药规则。','3a')
            else:
                change(t,'D13b','?','本设定不采用3a。FDA仅有关键选择性清单及既往氯氮平/长效针剂限制，不能据此判定所有抗精神病药或情感稳定剂合用均被排除。','1')
        if t.key[0] == '奥氮平' and t.tid == 'HGIE':
            change(t,'D14','R','FDA最终决定接受的支持性结果仅限本次MDD发作中既往SSRI充分治疗失败、再经7周前瞻文拉法辛治疗失败的事后严格亚组；原全研究允许其他发作的历史失败，不能用于此支持性人群。021520Orig1s012物理172、206、311。','1')
            t.result_source = '021520Orig1s012物理172、179–181（最终决定层）；273表37、311表3.15（不同分析）'
            t.result_basis = '保留FDA决定层支持性分类，限本次发作两次失败的事后亚组。表3.15第12周LOCF n=334（OFC163/FLX41/OLZ47/VNL41/低剂量OFC42），OFC对FLX p=.021、OLZ .003、VNL .713。表37 OC基线合计335，VNL42；第12周p=.049/.061/.754。分析集差1人原因未解释，不合并分母；全483人人口学及≥50分组不能代替严格亚组逐维特征。'
