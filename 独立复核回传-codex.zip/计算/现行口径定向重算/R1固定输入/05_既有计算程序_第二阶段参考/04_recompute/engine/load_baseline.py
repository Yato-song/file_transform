from pathlib import Path
import sys,json,contextlib,io,hashlib
ROOT=Path(__file__).resolve().parents[2]
SRC=Path(__file__).resolve().parents[1]/'legacy_inputs'
OLD=Path(__file__).resolve().parents[1]/'legacy_json'
WORK=Path(__file__).parent
text=(OLD/'archived_builder_v20.txt').read_text()
prefix=text[:text.index('# 说明规则变化用的对照口径')]
def load():
    env={'__name__':'baseline','__file__':str(WORK/'baseline_compute.py')}
    oldargv=sys.argv
    sys.argv=['baseline_compute.py',str(SRC)]
    try:
        with contextlib.redirect_stdout(io.StringIO()) as log:exec(compile(prefix,'baseline_compute.py','exec'),env)
        (WORK/'baseline_log.txt').write_text(log.getvalue())
    finally:sys.argv=oldargv
    return env
if __name__=='__main__':
    e=load()
    data={'dimensions':e['NEW_DIMS'],'rowkeys':e['ROWKEYS'],'scenarios':{s:[{'drug':k[0],'regimen':k[1],'cells':v} for k,v in r.items()] for s,r in e['RESULTS_N'].items()}}
    (WORK/'baseline_results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print('Loaded read-only baseline:',len(e['FDA_N']),'records;',len(e['RESULTS_N']),'scenarios')
