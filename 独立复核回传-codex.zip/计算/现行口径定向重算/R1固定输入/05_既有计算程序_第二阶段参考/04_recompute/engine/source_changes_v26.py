def apply_source_changes_v26(trials,change,opt):
 # FDA CR review gives selected exclusions, not a complete list. Withdraw
 # unsupported N values even when the sponsor-source sensitivity is disabled.
 for t in trials:
  if t.key[0]=='帕罗西汀' and t.tid in ['CR 448','CR 449','CR 487']:
   for d in ['D02','D07','D08a','D08b','D10','D18']:
    if t.codes[d][0]=='N' and t.codes[d][1]=='1':
     change(t,d,'?','G10：Paxil CR FDA医学审评仅列部分排除条件（449见P1物理31–32）；原N来自未列，不能证明完整清单允许。采用3a时另用逐试验原方案补证；不采用第3级来源的设定保持未知。','1')
 # Sponsor protocol/CSR evidence remains source 3a and is excluded in S2/S3.
 if not opt.get('l3a'): return
 for t in trials:
  if t.key[0]!='帕罗西汀':continue
  if t.tid in ['CR 448','CR 449']:
   loc='paroxetine448_CSR.pdf物理30–32、1240–1242' if t.tid=='CR 448' else 'paroxetine449_CSR.pdf物理29–31、932–933'
   fix={
    'D08a':('X','方案明确排除妊娠检测阳性；不能把FDA摘要未列解释为允许。'),
    'D08b':('X','方案明确排除哺乳者，按G18直接映射产后哺乳排除。'),
    'D10':('P','排除妨碍帕罗西汀治疗的严重躯体病、癫痫史（儿童热性惊厥除外）及基线未解决的显著实验室/ECG异常；是条件性限制。'),
    'D18':('P','近6月以精神病性抑郁为主要或优势轴I诊断者排除；保留时间/主要诊断限定。'),
    'D15':('X','原方案页图核实HAMD17≥20，筛选至基线下降不得超过25%。FDA摘要下降方向有误；排除表另写下降≥25%且HAMD<20，448 CSR改用或，端点/连接词仍列Q034；不影响轻度排除。'),
    'D02':('N','已逐条核对方案完整排除清单，未单列智力障碍；有知情同意/参与条件，不据此推定所有智力障碍排除或实际入组。'),
    'D07':('N','已逐条核对方案完整排除清单，未列人格障碍；不代表实际入组或该亚组疗效。')}
   for d,(c,b) in fix.items():change(t,d,c,loc+'；'+b,'3a')
  if t.tid=='CR 487':
   for d,c,b in [('D18','P','排近6月为主要或优势轴I诊断的精神病性抑郁。'),('D10','P','排可致继发抑郁的神经病、痴呆、MMSE≤24、妨碍给药的严重躯体病及未解决的显著实验室/ECG异常。已目视确认≤号，PDF文本层丢失等号，不能据文本制造冲突。'),('D15','X','CSR页图入选HAMD17≥18，筛选至基线下降不得超过25%；排除条款另写下降≥25%，25%端点仍列Q034，轻度排除不变。'),('D02','N','完整排除清单未单列智力障碍；认知限制见D10，不据未列断言实际入组。'),('D07','N','完整排除清单未列人格障碍。'),('D08a','N','完整排除清单未列妊娠；本项为≥60岁的老年研究，不能用于成人妊娠人群覆盖。'),('D08b','N','完整排除清单未列哺乳；本项为≥60岁的老年研究，不能用于成人产后哺乳覆盖。')]:
    change(t,d,c,'paroxetine487_CSR_register.pdf物理28、33–35；'+b,'3a')
  if t.tid=='PAR 01-001':
   change(t,'D16b','N','paroxetine01001_CSR.pdf物理31：年龄18至65岁（含端点）清楚可读。允许65岁不代表本药臂实际入组≥65。','3a')
   change(t,'D10','P','paroxetine01001_CSR.pdf物理31–32：不稳定且显著的肾、肝、呼吸、心血管或脑血管病；窄角青光眼、显著前列腺增生、癫痫、显著异常EEG及筛选实验室异常。EEG不是ECG；不擅加内分泌病。','3a')
   change(t,'D04a','P','paroxetine01001_CSR.pdf物理32：排原发焦虑障碍；按既定DSM-III焦虑障碍映射处理PTSD，不再用适应障碍排除作PTSD依据。','3a')
