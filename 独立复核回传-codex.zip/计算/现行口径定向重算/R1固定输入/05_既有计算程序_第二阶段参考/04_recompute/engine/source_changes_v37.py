def apply_source_changes_v37(trials,change,opt):
 for t in trials:
  if t.key[0]!='阿立哌唑' or t.tid not in ['CN138139','CN138163']:continue
  for value in t.codes.values():
   value[2]=value[2].replace('。D13b 另据 Berman 2009, CNS Spectr 14:197–206 物理 3、4 页（期刊第 198、199 页）','')
  first=t.tid=='CN138139';pg='9' if first else '17';ag='9 Table2' if first else '16 Table13';cp='569–570' if first else '613–614'
  if opt.get('l3a'):change(t,'D13b','X','本试验申办方CTD 180078000_21800AMZ10013_K100_1物理'+cp+'的合并治疗条款明确禁用神经阻滞剂（含氟哌啶醇/氟奋乃静长效制剂）、抗惊厥药及锂等心境稳定剂。口服神经阻滞剂须于前瞻ADT期开始前3日停用；指定ADT及试验ARI为设计用药。已用本试验直接条款替换CN138165/Berman2009借用，层级仍3a。','3a')
  change(t,'D15','X' if opt.get('s11') else 'R','FDA021436s018_StatR物理'+pg+'基线表：ARI随机臂HAMD17实际范围'+('14–34（n184，含2例错误随机记录）' if first else '14–31（n191）')+'，明确有14分，处于既定轻度8–16分内。随机时资格HAMD17≥14且CGI-I≥3；前瞻阶段≥18不替代随机基线。按G10/G12实际本药臂记录记R，不能解释为8–16全范围有代表性或轻度亚组已证明有效。','1')
  if opt.get('s11'):t.codes['D15'][2]='S11轻度定义HAMD17为8–13；本药随机臂实际最低14，故记X，不能沿用主设定8–16的R。'+t.codes['D15'][2]
  change(t,'D16b','R','FDA021436s018_StatR物理'+ag+'：'+('ARI随机臂n184、年龄21–65；PBO n178、21–64。n184含2例错误随机，不能由该表断言65岁者实际用药或进入主要终点集。' if first else 'ARI随机臂n191、年龄19–67；PBO n190、20–66。与资格18–65存在边界不一致，原因未确定；不擅自修改原年龄上限。')+'药物臂随机记录直接支持≥65入组，按G10/G12记R；≥65人数及亚组疗效仍未知。','1')
  for di in ['D13b','D15','D16b']:t.codes[di][3]['revision']='v37 本试验原件补证'
  t.result_source='021436s018_StatR.pdf物理'+('7–10；CTD物理574、577' if first else '15–18；CTD物理618、621')
  t.result_basis=('FDA主要LOCF MADRS：ARI181/PBO172=353；LS变化−8.78/−5.77，差−3.01（95%CI−4.66至−1.37），p<.001。分配362含2错误随机，完成前瞻期后随机360，用药358。' if first else 'FDA主要LOCF MADRS：ARI185/PBO184=369；LS变化−8.49/−5.65，差−2.84（95%CI−4.53至−1.15），p=.001。随机381，用药379；一般疗效集371，因ARI两人无随机后MADRS而主要终点369。')
