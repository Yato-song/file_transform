def apply_source_changes_v36(trials,change,opt):
 for t in trials:
  if t.key[0]=='艾司西酞普兰' and t.tid in ['SCT-MD-01','SCT-MD-02']:
   change(t,'D10','P','FDA2002 Lexapro统计审评21-323.pdf_Lexapro_Statr.pdf物理3（印刷2）共同条款：排除任何临床有意义且不稳定的躯体病；程度及稳定性限定支持P。CTD K129物理1–2/49–50另提供病种及检测阈值，仍属3a，未把其细则升级为FDA原文。','1')
   t.codes['D10'][3]['revision']='v36 FDA直接条款补证'
  if (t.key[0],t.tid)==('喹硫平','D1448C00001'):
   change(t,'D16b','R','FDA2009 NDA022047 S011统计审评物理241（印刷13）Table2：MITT人群150mg臂n168，年龄19–65；本药该臂直接证实65岁实际入组。50mg臂18–63、300mg臂18–64；不得外推各剂量均有老年入组或亚组有效。替代既有申办摘要3a来源。','1')
   t.codes['D16b'][3]['revision']='v36 FDA分臂年龄表'
