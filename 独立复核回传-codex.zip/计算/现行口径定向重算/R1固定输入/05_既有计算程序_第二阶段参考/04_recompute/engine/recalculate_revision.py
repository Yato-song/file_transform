from pathlib import Path
import json,re,collections,copy,hashlib,sys
from load_baseline import load,ROOT,WORK,OLD,SRC

import argparse
parser = argparse.ArgumentParser(description="Reconstruct the 19 FDA evidence specifications.")
parser.add_argument("--condition", choices=("formal", "without_87A", "with_88105", "explicit_unipolar", "functional_D02"), default="formal")
args = parser.parse_args()
condition = args.condition
revision43 = json.loads((WORK / "v43_inputs.json").read_text())
E=load()
from source_changes_v33 import add_cct004
add_cct004(E)
# The 1999 FDA review now independently supports this existing pooled record.
for t in E['FDA_N']:
    if t.key[0]=='氟西汀' and t.tid=='标签 老年两项':t.level='1 FDA 审评（HCFF两研究汇总）'
FDA=json.loads((OLD/'FDA证据总表_纳排原文_2026-11-02_v20.json').read_text())
MAT=json.loads((OLD/'证据矩阵_合并_主设定与敏感性_2026-11-02_v20.json').read_text())
RAW={(r[0],str(r[3])):(i,r) for i,r in enumerate(FDA['成人与老年试验'],1) if i>1}
CHANGES=[]
EXT=[
 # target medicine, parent drug, parent trial, role, result basis, source, dosage
 ('文拉法辛','伏硫西汀','11492A','pos','相对安慰剂 p<0.001','NDA204447_1.pdf 物理24页，表11','225 mg/day'),
 ('度洛西汀','伏硫西汀','13267A','pos','相对安慰剂 p<0.0001','NDA204447_1.pdf 物理24页，表11','60 mg/day'),
 ('度洛西汀','伏硫西汀','LuAA21004_315','pos','相对安慰剂 p<0.001','NDA204447_1.pdf 物理25页，表11','60 mg/day'),
 ('度洛西汀','伏硫西汀','LuAA21004_304','pos','相对安慰剂 p<0.05；受评药伏硫西汀阴性','NDA204447_1.pdf 物理25页，表11','60 mg/day'),
 ('度洛西汀','伏硫西汀','11984A','neg','参照药与安慰剂未分离','NDA204447_1.pdf 物理25页，表11','60 mg/day'),
 ('度洛西汀','喹硫平','D1448C00002','pos','处长备忘明确记载度洛西汀优于安慰剂','NDA022047 S-011.pdf 物理105页','按本试验参照臂剂量'),
 ('艾司西酞普兰','喹硫平','D1448C00004','neg','喹硫平与艾司西酞普兰均未优于安慰剂','NDA022047 S-011.pdf 物理105页','按本试验参照臂剂量'),
 ('阿米替林','米氮平','003-020','pos','两个活性药在 LOCF 和 OC 分析均优于安慰剂','020415Orig1s000rev.pdf 物理79页','40-280 mg/day 滴定'),
 ('阿米替林','米氮平','003-021','pos','米氮平阴性，阿米替林在 LOCF 分析一致优于安慰剂','020415Orig1s000rev.pdf 物理69、80页','40-280 mg/day 滴定'),
 ('阿米替林','米氮平','003-024','pos','两个活性药在多数变量、LOCF 与 OC 分析优于安慰剂','020415Orig1s000rev.pdf 物理80页','40-280 mg/day 滴定'),
 ('曲唑酮','米氮平','003-023','neg','未建立优于安慰剂的疗效；审评提示可能剂量不足','020415Orig1s000rev.pdf 物理69、80页','40-280 mg/day；平均剂量偏低'),
 ('帕罗西汀','度洛西汀','F1J-MC-HMAYa','pos','相对安慰剂 LOCF p=0.001，重复测量 p<0.001','NDA021427_副本.pdf 物理10页，表3','20 mg/day'),
 ('帕罗西汀','度洛西汀','F1J-MC-HMAYb','neg','相对安慰剂 LOCF p=0.552，重复测量 p=0.089','NDA021427_副本.pdf 物理10页，表3','20 mg/day'),
 ('西酞普兰','艾司西酞普兰','99003','neg','主要终点相对安慰剂 p=0.11，只有数值趋势','21-323.pdf_Lexapro_Medr_P1.pdf 物理31-32页','20-40 mg/day'),
 ('西酞普兰','艾司西酞普兰','SCT-MD-02','neg','主要终点未显示活性药与安慰剂组间显著差异','21-323.pdf_Lexapro_Medr_P1.pdf 物理26-27页；Statr 物理2-3页','20-40 mg/day'),
]
PENDING=[
 ['阿米替林','米氮平','003-022','已确认参照设计，待补该臂结果原文','020415Orig1s000rev.pdf 物理77页'],
 ['曲唑酮','文拉法辛','302（速释）','已确认参照设计，待补该臂结果原文','fdadrug_24.pdf 物理75-77页'],
 ['西酞普兰','艾司西酞普兰','SCT-MD-01','已确认参照设计，待补该臂比较结果原文','21-323.pdf_Lexapro_Statr.pdf.pdf 物理2-3页'],
 ['文拉法辛','去甲文拉法辛','3151A1-309','已确认参照设计，待补该臂比较结果原文','021992s000_MedR_P1.pdf 物理77-78页'],
 ['文拉法辛','去甲文拉法辛','3151A1-317','已确认参照设计，待补该臂比较结果原文','021992s000_MedR_P1.pdf 物理77-78页'],
]

# v22 corrections are applied before comparison-arm construction so shared eligibility follows its parent.
REVIEW=json.loads((WORK/'review_notes.json').read_text())
EXT += [tuple(x) for x in REVIEW['new_references']]
EXT.append(('曲唑酮','文拉法辛','302（速释）','pos','FDA统计审评：LOCF HAMD总分及MADRS总分第4/6周均优于安慰剂；OC和final分析第6周未分离，保留缺失数据及时间点限制。','fdadrug_24.pdf物理101–102（印刷12–13）','按母试验曲唑酮臂；未从其他试验借剂量'))
resolved={(x[0],x[1],x[2]) for x in EXT}
PENDING[:]=[x for x in PENDING if tuple(x[:3]) not in resolved]
# G50-G52: geriatric study status follows design/FDA designation, not age overlap.
old_is_elderly=E['is_elderly']
def is_elderly_v23(t):
    if (t.key[0],t.tid) in [('米氮平','003-023'),('帕罗西汀','CR 487')]: return True
    if getattr(t,'parent_id','') in ('米氮平|003-023','帕罗西汀|CR 487'): return True
    return old_is_elderly(t)
E['is_elderly']=is_elderly_v23
# G01/G02/G04 and the final 23-Nov decision: all ten active-control comparisons are not established.
for tid in ['20','29a','29b','22','23','26','31a','31b','33a','33b']:
    assert not any(t.key[0]=='氟西汀' and t.tid==tid for t in E['FDA_N']),tid
    cs={d:['?','1','fdadrug_22.pdf物理157仅提供本试验设计/结果概述，完整纳排未定位。',{'revision':'G01/G02/G04'}] for d in E['N_LETTER_DIMS']}
    if tid=='20':
        cs=next(t.copy().codes for t in E['FDA_N'] if t.key[0]=='氟西汀' and t.tid=='19')
        for d,v in cs.items():
            v[2]='物理26明确Protocol20同Protocol19（另加丙米嗪禁忌），沿用物理1-2的方案条款：'+str(v[2]);v[3]['revision']='G01/G02/G04'
        cs['D18']=['N','1','物理1、26：方案允许精神病性抑郁；物理28质疑实际精神病性诊断及代表性，不以该记录确证入组特征。',{'revision':'G01/G04'}]
    cs['D12']=['R' if tid in ('29a','29b') else 'X','1','fdadrug_22.pdf物理157：住院试验' if tid in ('29a','29b') else 'fdadrug_22.pdf物理157：门诊试验',{'revision':'G02/F85'}]
    cs['D17']=['R','1','fdadrug_22.pdf物理157：氟西汀单药与三环抗抑郁药平行对照；不表示合用。',{'revision':'G02/F85'}]
    t=E['TrialN'](('氟西汀',''),tid,'neg','1 FDA 审评','', '') if False else E['TrialN'](('氟西汀',''),tid,'neg','1 FDA 审评',cs,'v23补入自身申报活性对照试验')
    t.result_source='fdadrug_22.pdf物理26-28、150、153、157'
    t.result_basis='FDA认为比较难以解释（20）或疗程不等、比较无效（23），未建立疗效。' if tid in ('20','23') else '与活性对照未分离；无安慰剂，不能解释为等效；按F85归未建立疗效。'
    E['FDA_N'].append(t)
    E['POP'][('氟西汀',tid)]='成人MDD'
# v24: final SBA covers all active-control studies; do not invent criteria.
for tid in ['10c','15','21']:
    assert not any(t.key[0]=='安非他酮' and t.tid==tid for t in E['FDA_N'])
    cs={d:['?','1','本试验完整纳排未定位；不能自动沿用其他安非他酮研究。',{'revision':'v24/G01/G02/G04'}] for d in E['N_LETTER_DIMS']}
    cs['D12']=['R' if tid=='21' else 'X','1','018644Orig1s000rev物理131-133、651：21为住院设计；10c和15为门诊。',{'revision':'v24/G10'}]
    cs['D17']=['R','1','018644Orig1s000rev物理131-133、651：安非他酮与活性药平行单药比较，不是合用。',{'revision':'v24/G10'}]
    if tid=='15':cs['D15']=['X','1','018644Orig1s000rev物理132：安慰剂导入第0天HAM-D≤18者替换；保留此方案条款，早期样本数/年龄不作为最终样本。',{'revision':'v24/G10'}]
    t=E['TrialN'](('安非他酮',''),tid,'neg','1 FDA 审评',cs,'v24自身申报活性对照；最终SBA结果已核')
    t.result_source='018644Orig1s000rev.pdf物理131-133、642、651-652；15另见107-111'
    t.result_basis='最终SBA：15的差异有利于阿米替林；无安慰剂不能判断安非他酮绝对无效。按G01/G02/G04归未建立疗效。' if tid=='15' else '最终SBA：七项活性对照中除15外六项未分离，不作为安非他酮疗效证据；结合本项早期无差异摘要，按G01/G02/G04归未建立疗效。单盲/中期及完整原报告限制保留。'
    E['FDA_N'].append(t);E['POP'][('安非他酮',tid)]='成人抑郁研究（历史诊断，须保留原人群边界）'
# Recreate the named parent comparisons before any scenario chooses evidence sources.
active43 = {}
for entry in revision43["parents"]:
    tid = entry["trial"]
    if entry.get("conditional") and condition != "with_88105":
        continue
    if condition == "without_87A" and tid == "87A":
        continue
    if condition == "explicit_unipolar" and tid in {"87A", "91302", "89422"}:
        continue
    if any(t.key[0] == "西酞普兰" and t.tid == tid for t in E["FDA_N"]):
        raise ValueError("Duplicate trial: " + tid)
    active43[tid] = entry
    codes = {d: ["?", "1", "FDA仅提供研究摘要，本字段未明确报告。", {"revision": "v43"}] for d in E["N_LETTER_DIMS"]}
    trial = E["TrialN"](("西酞普兰", ""), tid, "neg", "1 FDA 审评", codes, "v43 G01/G02/G04 自身申报")
    E["FDA_N"].append(trial)
    E["POP"][("西酞普兰", tid)] = "老年" if entry["elderly"] else entry["population"]
s5_entry = revision43["s5"]
s5_codes = {d: [v["code"], v["level"], v["basis"], {"revision": "v43", "v43_r_type": v["r_type"]}]
            for d, v in s5_entry["codes"].items()}
if set(s5_codes) != set(E["N_LETTER_DIMS"]):
    raise ValueError("Incomplete S5 dimensional inventory.")
s5_trial = E["TrialN"](("伏硫西汀", ""), "14178A", "pos", "1b EMA CHMP", s5_codes, s5_entry["origin"])
E["SENS_N"].append(s5_trial)
E["AGE"][("伏硫西汀", "14178A")] = "18–75岁"
EXT.extend(tuple(ref) for ref in revision43["references"] if ref[2] in active43)

OFC=('氟西汀','与奥氮平联合起始')
oldkeys=E['ROWKEYS'][:]
E['ROWKEYS'].insert(E['ROWKEYS'].index(('氟西汀',''))+1,OFC)
E['N_NA'].discard((('氟西汀',''),'D13b'))
E['N_NA'].add((OFC,'D17'))
E['AGE'][(OFC[0],'HGIE（OFC，氟西汀索引）')]='≥18岁'
E['POP'][(OFC[0],'HGIE（OFC，氟西汀索引）')]='成人难治性抑郁'
v42_documented_age = {
    ('伏硫西汀', 'CCT-004', '3a'),
    ('喹硫平', 'D1448C00002', '1'),
    ('喹硫平', 'D1448C00007', '1'),
    ('度洛西汀', '喹硫平 D1448C00002 的度洛西汀参照臂', '1'),
    ('艾司西酞普兰', '喹硫平 D1448C00004 的艾司西酞普兰参照臂', '3a'),
}
v42_reference_age = {
    ('度洛西汀', '喹硫平', 'D1448C00002'): ('1', 'Q013-08 FDA物理245/印刷17表8：度洛西汀参照臂MITT年龄19–65，确有65岁。'),
    ('艾司西酞普兰', '喹硫平', 'D1448C00004'): ('3a', 'Q013-04 申办方CSR摘要物理6表S2：艾司西酞普兰参照臂MITT年龄18–65，确有65岁。'),
}
old_rsub=E['rsub']
def rsub(d,t,s,b):
    explicit = t.codes.get(d, [None, None, None, {}])[3].get("v43_r_type")
    if explicit and t.codes[d][0] == "R":
        return explicit
    if d == 'D16b' and (t.key[0], t.tid, s) in v42_documented_age:
        return 'doc'

    if d=='D16b' and s=='3a' and t.key[0]=='伏硫西汀' and t.tid=='LuAA21004_317':return 'doc'
    if d in ('D15','D16b') and t.key[0]=='阿立哌唑' and t.tid in ['CN138139','CN138163'] and s=='1':return 'doc'
    if d=='D16b' and s=='3a' and ((t.key[0],t.tid)==('艾司西酞普兰','SCT-MD-02') or getattr(t,'parent_id','')=='艾司西酞普兰|SCT-MD-02'):return 'doc'
    if d=='D16b' and s=='3a' and t.key[0]=='文拉法辛' and t.tid in ['0600B-208-US','0600B-209-US','0600B-367-EU']:return 'doc'
    if d=='D16b' and s=='3a' and (t.key[0],t.tid) in [('度洛西汀','F1J-MC-HMAYa'),('度洛西汀','F1J-MC-HMAYb')]:return 'doc'
    if d=='D16b' and (t.key[0],t.tid)==('喹硫平','D1448C00001') and s=='1':return 'doc'
    if d=='D16b' and t.key[0]=='喹硫平' and t.tid in ('D1448C00001','D1448C00007') and s=='3a':return 'doc'
    if d=='D16b' and (t.key[0],t.tid)==('氟西汀','标签 老年两项'):return 'doc'
    if d=='D16b' and ((t.key[0],t.tid) in [('米氮平','003-023'),('帕罗西汀','CR 487')] or getattr(t,'parent_id','')=='米氮平|003-023'):return 'doc'
    if d=='D12' and (t.key[0],t.tid)==('西酞普兰','86141'):return 'doc'
    if d=='D16b' and (t.key[0],t.tid)==('度洛西汀','F1J-MC-HMATb'):return 'doc'
    if d=='D16b' and (t.key[0],t.tid)==('曲唑酮','04ACL3-001') and s=='1':return 'doc'
    if t.key==OFC and d in ('D13a','D13b'):return 'design'
    if t.tid=='FDA项目汇总（老年入组）' and d=='D16b':return 'summary'
    return old_rsub(d,t,s,b)
E['rsub']=rsub
def parent(t):
    if t.key==OFC:return '奥氮平|HGIE'
    if t.tid=='舍曲林 104 的阿米替林臂':return '舍曲林|104'
    if t.tid=='舍曲林 315 的阿米替林臂':return '舍曲林|315'
    if t.tid=='12541A度洛西汀参照臂（老年）':return '伏硫西汀|12541A'
    if hasattr(t,'parent_id'):return t.parent_id
    tid=re.sub(r'（(?:中度层|轻度层)）','',t.tid)
    return t.key[0]+'|'+tid
def change_code(t,d,new,basis,source=None):
    old=t.codes[d]
    t.codes[d]=[new,source or old[1],basis,dict(old[3])]
    t.codes[d][3]['revision']='v22保留；v23按G01/G02/G04/G06/G11/G50-G52复核'
def apply_revision(trials,opt):
    E['apply_rule7'](trials)
    for t in trials:
        if (t.key[0],t.tid) in [('曲唑酮','标签 速释'),('氟西汀','标签 老年两项')]:t.role='lab'
        for d,v in list(t.codes.items()):
            if v[0]=='R' and not t.is_label and rsub(d,t,v[1],v[2])=='summary':
                if d=='D12' and t.key[0] in ('伏硫西汀','度洛西汀'):
                    change_code(t,d,'N','仅为通用入选条件允许住院或门诊，不能证明本试验实际入组住院患者；逐试验来源未报告时不能用于实际入组判定。原汇总依据：'+str(v[2]))
                elif d=='D16b':
                    change_code(t,d,'N','入选条件未排除该年龄；汇总老年入组信息不分配给本试验。原依据：'+str(v[2]))
        if t.key[0]=='伏硫西汀' and t.tid=='标签 总述':
            change_code(t,'D12','?','标签总体包含短期成人、专门老年及维持试验，无法定位 18-65 岁急性期阳性试验的住院入组；汇总原文保留在汇总证据页。','2')
    # FDA decision memorandum explicitly refers to trials supporting the efficacy claim.
    if any(t.key[0]=='文拉法辛' and t.tid=='203（速释）' for t in trials):
        cs={d:['?','1','无本维度的独立汇总信息',{}] for d in E['N_LETTER_DIMS']}
        cs['D16b']=['R','1','FDA 对支持疗效主张的研究汇总说明包含部分老年患者；不归属到具体试验。fdadrug_24.pdf 物理78页',{'revision':'F107'}]
        pool=E['TrialN'](('文拉法辛',''),'FDA项目汇总（老年入组）','lab','1 FDA 审评（汇总）',cs,'v22汇总证据')
        trials.append(pool)
    for t in trials:
        for c in REVIEW['code_changes']:
            if (t.key[0],t.tid)==(c['drug'],c['trial']):
                change_code(t,c['dimension'],c['new'],c['basis'],c['source'])
        if t.key[0]=='米氮平' and t.codes['D04a'][0]=='P' and '适应障碍' in t.codes['D04a'][2]:
            change_code(t,'D04a','P','排主要焦虑障碍；PTSD映射来自当时诊断分类下的焦虑障碍。适应障碍排除条款归D04b，不能用作PTSD的直接依据。')
    for t in trials:
        if (t.key[0],t.tid)==('米氮平','003-023'):
            change_code(t,'D16b','R','G51/G52/F102：020415Orig1s000rev物理499，米氮平组约30%实际年龄≥65；按药物组入组记录，老年研究只进入D16b。','1')
        if (t.key[0],t.tid)==('帕罗西汀','CR 487'):
            change_code(t,'D16b','R','G51/G52/F102：20-936_Paxil_medr_P1物理39，没有60岁以下受试者，每组约半数66-74岁；实际入组，不是年龄下限保证。','1')
        v=t.codes['D16b'];a=str(E['AGE'].get((t.key[0],t.tid)) or '')
        if v[0]=='X' and (re.search(r'(?:[-–至到]|上限)\s*65',a+' '+v[2]) or '18-65' in v[2]) and not re.search(r'<\s*65|小于65|未满65',a+' '+v[2]):
            change_code(t,'D16b','N','G50：老年特征现定义≥65；来源年龄上限为65，允许65岁但不能据此证明实际入组。原条款：'+v[2],v[1])
    for t in trials:
        if t.key[0]=='氟西汀' and t.tid in ['20','22','23','26','29a','29b','31a','31b','33a','33b']:
            t.result_source='fdadrug_22.pdf物理26-28、150、153、157'
            t.result_basis='FDA认为比较难以解释（20）或疗程不等、比较无效（23），未建立疗效。' if t.tid in ('20','23') else '与活性对照未分离；无安慰剂，不能解释为等效；按F85归未建立疗效。'
    # Source-specific v24 changes run after supplementary fills and before reference-arm cloning.
    from source_changes_v24 import apply_source_changes
    apply_source_changes(trials,change_code)
    from source_changes_v25 import apply_source_changes_v25
    apply_source_changes_v25(trials,change_code)
    from source_changes_v26 import apply_source_changes_v26
    apply_source_changes_v26(trials,change_code,opt)
    from source_changes_v27 import apply_source_changes_v27
    apply_source_changes_v27(trials,change_code,opt)
    from source_changes_v28 import apply_source_changes_v28
    apply_source_changes_v28(trials,change_code,opt)
    from source_changes_v29 import apply_source_changes_v29
    apply_source_changes_v29(trials,change_code,opt)
    from source_changes_v30 import apply_source_changes_v30
    apply_source_changes_v30(trials,change_code,opt)
    from source_changes_v31 import apply_source_changes_v31
    apply_source_changes_v31(trials,change_code,opt)
    from source_changes_v33 import apply_source_changes_v33
    apply_source_changes_v33(trials,change_code,opt)
    from source_changes_v35 import apply_source_changes_v35
    apply_source_changes_v35(trials,change_code,opt)
    from source_changes_v36 import apply_source_changes_v36
    apply_source_changes_v36(trials,change_code,opt)
    from source_changes_v37 import apply_source_changes_v37
    apply_source_changes_v37(trials,change_code,opt)
    from source_changes_v38 import apply_source_changes_v38
    apply_source_changes_v38(trials,change_code,opt)
    from source_changes_v39 import apply_source_changes_v39
    apply_source_changes_v39(trials,change_code,opt)
    from source_changes_v40 import apply_source_changes_v40
    apply_source_changes_v40(trials,change_code,opt)
    from source_changes_v41 import apply_source_changes_v41
    apply_source_changes_v41(trials,change_code,opt)
    from additional_changes import apply_additional_changes
    apply_additional_changes(trials,change_code,opt,E["tempo_codes"])
    for t in trials:
        entry = active43.get(t.tid) if t.key[0] == "西酞普兰" else None
        if entry:
            t.result_basis, t.result_source = entry["result"], entry["source"]
            for code in entry["codes"]:
                if code.get("requires") and not opt.get(code["requires"]):
                    continue
                dimension = code["dimension"]
                change_code(t, dimension, code["code"], code["basis"], code["level"])
                t.codes[dimension][3] = {"revision": "v43", "v43_r_type": code.get("r_type")}
        if (t.key[0], t.tid) == ("伏硫西汀", "LuAA21004_317") and opt.get("l3a"):
            change_code(t, "D09", "R", revision43["317_D09"], "3a")
            t.codes["D09"][3] = {"revision": "v43 Q041-08", "v43_r_type": "doc"}
        if (t.key[0], t.tid) == ("伏硫西汀", "14178A"):
            t.result_source = s5_entry["source"]
            t.result_basis = s5_entry["result"]
        if (t.key[0], t.tid) == ("西酞普兰", "89306"):
            for d in ("D13a", "D13b"):
                change_code(t, d, "X", revision43["89306"], "1")
                t.codes[d][3]["revision"] = "v43 Q026-04"
        if condition == "functional_D02" and t.key[0] == "氟西汀" and t.tid in {"19", "20", "25"}:
            change_code(t, "D02", "P", "条件试算：将沟通/完成自评的功能条件映射为部分限制；诊断未直接排除。", "1")
    idx={(t.key[0],t.tid):t for t in trials}
    hg=idx[('奥氮平','HGIE')].copy();hg.key=OFC;hg.tid='HGIE（OFC，氟西汀索引）';hg.origin='OFC自身联合方案申报（同一母试验）'
    change_code(hg,'D13a','R','仅 HGIE 文拉法辛交叉减停 5-9 天的短期重叠；不覆盖持续双抗抑郁药治疗。021520Orig1s012.pdf 物理296-297页','1')
    change_code(hg,'D13b','R','HGIE 随机至奥氮平加氟西汀；文拉法辛导入7周后同时启动，支持性结论限本次发作两次治疗失败的事后亚组。物理172、206-207、296-297页','1')
    change_code(hg,'D17','X','只评价与奥氮平联合的 OFC 方案，不能用于氟西汀单药','1')
    hg.result_basis=idx[('奥氮平','HGIE')].result_basis;hg.result_source=idx[('奥氮平','HGIE')].result_source
    trials.append(hg)
    if opt.get('refarm'):
        for drug,pdrug,tid,role,result,source,dose in EXT:
            base=idx[(pdrug,tid)]
            t=base.copy();t.key=(drug,'');t.tid=f'{pdrug} {tid} 的{drug}参照臂';t.role=role;t.level='1 FDA 审评（跨申报参照臂）';t.origin='扩展参照臂；结果比较单独判定'
            t.parent_id=pdrug+'|'+tid;t.result_basis=result;t.result_source=source;t.reference_dose=dose
            for d,v in t.codes.items():
                if v[0]=='R' and rsub(d,base,v[1],v[2])=='doc':
                    # Do not copy treatment-arm enrollment facts to a different randomized arm.
                    change_code(t,d,'N','同一随机试验的入选条件可沿用；原药物组实际入组人数不能自动归到参照臂。原依据：'+str(v[2]))
            if (drug,pdrug,tid)==('曲唑酮','米氮平','003-023'):
                change_code(t,'D16b','R','G51/G52/F102：020415Orig1s000rev物理499，曲唑酮参照臂自身约19%实际年龄≥65；不能沿用米氮平组30%。','1')
            if opt.get('l3a') and (drug,pdrug,tid)==('度洛西汀','伏硫西汀','LuAA21004_315'):
                change_code(t,'D16b','R','Mahableshwarkar2015原文物理5表1：度洛西汀参照臂自身实际年龄19–72，明确含≥65；仅扩展，不继承伏硫西汀臂记录。','3a')
            if opt.get('l3a') and (drug,pdrug,tid)==('帕罗西汀','度洛西汀','F1J-MC-HMAYb'):
                change_code(t,'D16b','R','日本PMDA公开申办方CTD物理525表2.7.6.5.10-4：帕罗西汀20mg参照臂实际年龄20.90–74.19，明确含≥65；仅扩展，结果仍未建立疗效。','3a')
            if opt.get('l3a') and (drug,pdrug,tid)==('西酞普兰','艾司西酞普兰','SCT-MD-02'):
                change_code(t,'D16b','R','PMDA公开申办方CTD 79000500_22300AMX00517_K129_1物理54（印刷784）表2.7.6.8.6-3：西酞普兰参照臂123人中70岁及以上1人，按本臂实际记录；不继承ESC的2人。','3a')
            if (drug, pdrug, tid) == ("阿米替林", "西酞普兰", "92302"):
                if opt.get("l3a"):
                    change_code(t, "D16b", "R", revision43["92302_reference_age"], "3a")
                    t.codes["D16b"][3]["v43_r_type"] = "design"
                else:
                    change_code(t, "D16b", "?", "FDA称老年设计，未明确本参照臂年龄界限或≥65实际人数。", "1")
            age_source = v42_reference_age.get((drug, pdrug, tid))
            if age_source and (age_source[0] == '1' or opt.get('l3a')):
                change_code(t, 'D16b', 'R', age_source[1], age_source[0])
                t.codes['D16b'][3]['revision'] = 'v42 参照臂自身年龄表'
            E['AGE'][(drug,t.tid)]=E['AGE'].get((pdrug,tid))
            E['POP'][(drug,t.tid)]=E['POP'].get((pdrug,tid))
            trials.append(t)
    if not opt.get('hdao2',True):trials[:]=[t for t in trials if t.key!=OFC]
    return trials
E['apply_revision']=apply_revision
src=(OLD/'archived_builder_v20.txt').read_text()
func=src[src.index('def build_n(opt):'):src.index('\nBASE = dict(label=True',src.index('def build_n(opt):'))]
func=func.replace('def build_n(opt):','def build_revision(opt):').replace('apply_rule7(trials)      # v19','apply_revision(trials, opt)')
func=func.replace("if (k, d) in N_NA:","if k == ('氟西汀', '与奥氮平联合起始') and not mine:\n                res[k][d] = ('—', [], '本设定排除 HGIE 支持性联合方案，无可评分试验', {})\n                continue\n            if (k, d) in N_NA:")
func=func.replace("ps = ped_set(k[0], opt)","ps = [] if k == ('氟西汀', '与奥氮平联合起始') else ped_set(k[0], opt)")
func=func.replace("n_cover = len(cover_rows) if cover_rows else (1 if any(p[0] in ('R', 'N', 'P') for p in pos) else 0)","n_cover = len(cover_rows)")
exec(compile(func,'revision_compute','exec'),E)
SCENARIOS=[]
for code,name,opt in E['SPECS_N']:
    opt=dict(opt);opt['refarm']=code=='S6'
    if code=='主设定':name='主设定：各药自身申报试验，含明确的自身联合方案；参照臂仅扩展'
    if code=='S1':name='去掉美国标签：保留其余主设定来源'
    if code=='S6':name='扩展分析：加入已核实的跨申报参照臂（目录仍待补全）'
    SCENARIOS.append((code,name,opt))
RESULTS={};FILLS={}
for code,name,opt in SCENARIOS:RESULTS[code],FILLS[code]=E['build_revision'](opt)

def prepared(opt):
    ts=[t.copy() for t in E['FDA_N']]
    E['apply_fill_n'](ts,E['FILL_1B_N'],'1b');E['apply_fill_n'](ts,E['FILL_3A_N'],'3a');E['apply_except_3a'](ts)
    apply_revision(ts,opt)
    return [t for t in ts if opt['refarm'] or not t.is_refarm]
MAIN_TRIALS=prepared(dict(E['BASE'],refarm=False))
EXT_TRIALS=prepared(dict(E['BASE'],refarm=True))
def record(t):
    pooled=t.role=='lab'
    return {'drug':t.key[0],'regimen':t.key[1],'trial':t.tid,'role':t.role,'level':t.level,'origin':t.origin,'elderly':E['is_elderly'](t),'reference':t.is_refarm,'parent_id':None if pooled else parent(t),'unit':'汇总证据，不计独立试验' if pooled else '标签单项已对应Well 84A（多特征推定；层级仍为2）' if getattr(t,'parent_id','')=='安非他酮|Well 84A' else '标签可区分单项试验，方案号待定位' if t.is_label else '试验比较/分层','same_trial_usable':not pooled,'codes':{d:dict(code=v[0],source=v[1],basis=v[2],meta=v[3],r_type=rsub(d,t,v[1],v[2]) if v[0]=='R' else None) for d,v in t.codes.items()},'result_basis':getattr(t,'result_basis',None),'result_source':getattr(t,'result_source',None),'reference_dose':getattr(t,'reference_dose',None)}
MAIN=[record(t) for t in MAIN_TRIALS];ALL=[record(t) for t in EXT_TRIALS]
facts={}
for code,res in RESULTS.items():
    core=[res[k][d][0] for k in E['ROWKEYS'] for d in E['N_CORE_DIMS'] if res[k][d][0] not in ('—','n/a')]
    c=collections.Counter(core)
    facts[code]={'cells':len(core),'drugs':len({k[0] for k in E['ROWKEYS'] if any(res[k][d][0] not in ('—','n/a') for d in E['N_CORE_DIMS'])}),'regimens':sum(any(res[k][d][0] not in ('—','n/a') for d in E['N_CORE_DIMS']) for k in E['ROWKEYS']),'counts':dict(c),'gap':c['C']+c['D'],'gap_pct':100*(c['C']+c['D'])/len(core),'E_pct':100*c['E']/len(core)}
adult=[r for r in MAIN if not r['elderly']]
facts['trial_counts']={'adult_pos_comparison_records':sum(r['role']=='pos' for r in adult),'adult_neg_comparison_records':sum(r['role']=='neg' for r in adult),'adult_summary_records':sum(r['role']=='lab' for r in adult),'adult_named_parent_ids':len({r['parent_id'] for r in adult if r['role']!='lab' and (not r['level'].startswith('2') or r['parent_id']=='安非他酮|Well 84A')}),'adult_label_single_records':sum(r['role']=='pos' and r['level'].startswith('2') and r['parent_id']!='安非他酮|Well 84A' for r in adult),'all_reference_records':sum(r['reference'] for r in ALL)}
names={str(h).split()[0]:str(h).split(' ',1)[1] for h in MAT['主设定矩阵'][0] if str(h).startswith('D')}
names['D16b']='65岁及以上'
data={'date':'2026-11-25','version':'v43','condition':condition,'dimensions':E['NEW_DIMS'],'core_dimensions':E['N_CORE_DIMS'],'dimension_names':names,'rowkeys':E['ROWKEYS'],'scenarios':[[c,n,o] for c,n,o in SCENARIOS],'results':{s:[{'drug':k[0],'regimen':k[1],'cells':v} for k,v in rs.items()] for s,rs in RESULTS.items()},'main_trials':MAIN,'all_trials':ALL,'facts':facts,'pending_references':PENDING,'reference_definitions':EXT}
data['s5_trials']=[record(t) for t in E['S5_EFFECTIVE'].values()]
output_name = "recalculated.json" if condition == "formal" else "conditional_" + condition + ".json"
(WORK/output_name).write_text(json.dumps(data,ensure_ascii=False,indent=2))
print(json.dumps({'main':facts['主设定'],'expanded':facts['S6'],'trials':facts['trial_counts']},ensure_ascii=False,indent=2))
