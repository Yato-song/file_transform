"""Reconstruct the formal and four conditional v43 analyses from local inputs."""
import csv
import hashlib
import json
import platform
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
RULES = PACKAGE / "02_tasks_and_rules"
SOURCE = PACKAGE / "04_recompute"
VALIDATION = PACKAGE / "05_validation"
MAIN = "主设定"
SCENARIOS = [MAIN, *("S" + str(i) for i in range(1, 20) if i != 13)]
CONDITIONS = ("without_87A", "with_88105", "explicit_unipolar", "functional_D02")
LETTERS = ("A", "B", "B−", "C", "D", "E")


def require(test, message):
    if not test:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rebuild(condition):
    """Start a clean engine copy with no previously calculated results."""
    with tempfile.TemporaryDirectory(prefix="fda-v43-") as directory:
        copy = Path(directory) / "04_recompute"
        for folder in ("legacy_inputs", "legacy_json", "engine"):
            shutil.copytree(
                SOURCE / folder, copy / folder,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "baseline_log.txt",
                                             "recalculated.json", "conditional_*.json"))
        engine = copy / "engine"
        subprocess.run([sys.executable, "-B", "-X", "utf8", str(engine / "recalculate_revision.py"),
                        "--condition", condition], cwd=engine, stdout=subprocess.DEVNULL, check=True)
        filename = "recalculated.json" if condition == "formal" else f"conditional_{condition}.json"
        raw = (engine / filename).read_bytes()
        # The historical engine writes text using the operating system's default newline.
        digest = hashlib.sha256(raw.replace(b"\r\n", b"\n")).hexdigest()
        return json.loads(raw), digest, hashlib.sha256(raw).hexdigest()


def trial_counts(data):
    adult = [r for r in data["main_trials"] if not r["elderly"]]
    roles = Counter(r["role"] for r in adult)
    named = {r["parent_id"] for r in adult if r["role"] != "lab" and
             (not r["level"].startswith("2") or r["parent_id"] == "安非他酮|Well 84A")}
    single = sum(r["role"] == "pos" and r["level"].startswith("2")
                 and r["parent_id"] != "安非他酮|Well 84A" for r in adult)
    hgie = [r for r in adult if "HGIE" in r["trial"]]
    require(len(hgie) == 2 and {r["parent_id"] for r in hgie} == {"奥氮平|HGIE"},
            "HGIE should have two regimen records with one parent ID")
    require(not any(r["reference"] for r in data["main_trials"]), "Reference in main trials")
    counts = dict(adult_pos_comparison_records=roles["pos"], adult_neg_comparison_records=roles["neg"],
                  adult_summary_records=roles["lab"], adult_named_parent_ids=len(named),
                  adult_label_single_records=single,
                  all_reference_records=sum(r["reference"] for r in data["all_trials"]))
    require(counts == data["facts"]["trial_counts"], "Trial and parent counts disagree")
    return counts


def index_results(data):
    """Index cells and reconstruct every scenario summary directly from the cells."""
    require([item[0] for item in data["scenarios"]] == SCENARIOS, "Scenario roster differs")
    require(list(data["results"]) == SCENARIOS, "Scenario results differ")
    dimensions, core = set(data["dimensions"]), set(data["core_dimensions"])
    rows = [tuple(row) for row in data["rowkeys"]]
    require(len(rows) == len(set(rows)) == 20 and len(dimensions) == 22 and len(core) == 19,
            "Unexpected row or dimension roster")
    require(dimensions - core == {"D16a", "D16b", "D18"}, "Core dimension set differs")
    matrix = {}
    for scenario, records in data["results"].items():
        cells, scored_rows, counts = {}, set(), Counter()
        require([(r["drug"], r["regimen"]) for r in records] == rows, f"Row keys in {scenario}")
        for row in records:
            require(set(row["cells"]) == dimensions, f"Dimensions in {scenario}, {row['drug']}")
            for dimension, evidence in row["cells"].items():
                key = (row["drug"], row["regimen"], dimension)
                cells[key] = evidence
                if dimension in core and evidence[0] not in ("—", "n/a"):
                    require(evidence[0] in LETTERS, f"Unknown grade in {scenario}, {key}")
                    counts[evidence[0]] += 1
                    scored_rows.add(key[:2])
        total = sum(counts.values())
        gap = counts["C"] + counts["D"]
        facts = dict(cells=total, drugs=len({r[0] for r in scored_rows}), regimens=len(scored_rows),
                     counts=dict(counts), gap=gap, gap_pct=100 * gap / total, E_pct=100 * counts["E"] / total)
        require(facts == data["facts"][scenario], f"Cell counts disagree in {scenario}")
        matrix[scenario] = cells
    return matrix


def check_formal(data, matrix):
    core = set(data["core_dimensions"])
    main = matrix[MAIN]
    keys = [key for key in main if key[-1] in core]
    scored_keys = [key for key in keys if main[key][0] in LETTERS]
    require(len(keys) == 380 and len(scored_keys) == 320, "Formal denominator differs")
    with (VALIDATION / "19套设定.csv").open(encoding="utf-8-sig", newline="") as file:
        rows = list(csv.DictReader(file))
    require([row["设定"] for row in rows] == SCENARIOS, "CSV scenario roster differs")
    changes = {}
    for row in rows:
        scenario = row["设定"]
        summary = data["facts"][scenario]
        changes[scenario] = sum(matrix[scenario][key][0] != main[key][0] for key in keys)
        columns = {"分母": summary["cells"], "缺口C+D": summary["gap"],
                   "与主设定不同（380格）": changes[scenario], **summary["counts"]}
        require(all(int(row[k]) == v for k, v in columns.items()), f"CSV counts disagree in {scenario}")
        for column, field in (("缺口%", "gap_pct"), ("不确定%", "E_pct")):
            require(abs(float(row[column]) - summary[field]) <= 1e-12, f"CSV {column} differs in {scenario}")
    main_set = set(scored_keys)
    fixed = [s for s in SCENARIOS if {k for k in keys if matrix[s][k][0] in LETTERS} == main_set]
    require(fixed == [s for s in SCENARIOS if s not in ("S6", "S7")], "Fixed denominators differ")
    stability = read_json(RULES / "stability_v43.json")
    grid = []
    for key in scored_keys:
        grades = [matrix[s][key][0] for s in fixed]
        display = "；".join(f"{s}:{grade}" for s, grade in zip(fixed, grades))
        grid.append([*key, main[key][0], display, "是" if len(set(grades)) == 1 else "否"])
    stable = sum(row[-1] == "是" for row in grid)
    require(stability["fixed_scenarios"] == fixed and grid == stability["grid"][1:],
            "Stability report cell details disagree")
    require((stability["stable"], stability["variable"], stability["strict_changed"])
            == (stable, len(grid) - stable, changes["S8"]) == (201, 119, 8), "Stability counts differ")
    anchors = {}
    for scenario, drug, dimension, grade in ((MAIN, "西酞普兰", "D12", "C"),
                                            ("S5", "伏硫西汀", "D14", "A"),
                                            ("S19", "伏硫西汀", "D09", "C")):
        require(matrix[scenario][drug, "", dimension][0] == grade, f"Unexpected {scenario} {drug} {dimension}")
        anchors[f"{scenario} {drug} {dimension}"] = grade
    numerical = read_json(VALIDATION / "numerical_checks.json")
    require(numerical["scenario_diff"] == changes and numerical["trial_counts"] == data["facts"]["trial_counts"],
            "Numerical validation file disagrees")
    return dict(csv_scenarios=len(rows), primary_grid_cells_per_scenario=len(keys),
                fixed_scenarios=fixed, stable=stable, variable=len(grid) - stable,
                strict_changed=changes["S8"], selected_letters=anchors)


def trial_ids(result):
    return [(r["drug"], r["regimen"], r["trial"]) for r in result["all_trials"]]


def compare_condition(formal, data, base_grid, grid, digest):
    changed, grades = [], []
    for scenario in SCENARIOS:
        for key, evidence in grid[scenario].items():
            previous = base_grid[scenario][key]
            if evidence != previous:
                difference = [scenario, *key, previous[0], evidence[0]]
                changed.append(difference)
                if previous[0] != evidence[0]:
                    grades.append(difference)
    old_ids, new_ids = trial_ids(formal), trial_ids(data)
    old_set, new_set = set(old_ids), set(new_ids)
    return dict(condition=data["condition"], facts=data["facts"], changed_letters=grades,
                changed_evidence_cells=changed, added=[list(k) for k in new_ids if k not in old_set],
                removed=[list(k) for k in old_ids if k not in new_set], full_json_sha256=digest)


def verify():
    import openpyxl
    report = {"version": "v43", "python": platform.python_version(), "openpyxl": openpyxl.__version__,
              "conditions": {}}
    formal, digest, raw_digest = rebuild("formal")
    reference_path = RULES / "recalculated.json"
    expected_digest = hashlib.sha256(reference_path.read_bytes()).hexdigest()
    require(formal["version"] == "v43" and formal["condition"] == "formal", "Formal version differs")
    require(formal == read_json(reference_path), "Formal JSON differs from distributed result")
    require(digest == expected_digest, "Formal JSON SHA-256 differs")
    base_grid = index_results(formal)
    cells = sum(len(grid) for grid in base_grid.values())
    report["formal"] = dict(deep_equal=True, grid_cells=cells, sha256_lf=digest, sha256_raw=raw_digest,
                            expected_sha256=expected_digest, trial_counts=trial_counts(formal),
                            **check_formal(formal, base_grid))
    for condition in CONDITIONS:
        data, digest, raw_digest = rebuild(condition)
        require(data["condition"] == condition, f"Engine returned wrong condition for {condition}")
        grid = index_results(data)
        counts = trial_counts(data)
        snapshot = read_json(VALIDATION / f"conditional_{condition}.json")
        summary = compare_condition(formal, data, base_grid, grid, digest)
        require(summary == snapshot, f"Conditional facts, cell deltas, trial rows or SHA differ for {condition}")
        report["conditions"][condition] = dict(
            deep_equal_summary=True, full_json_sha256_lf=digest, full_json_sha256_raw=raw_digest,
            expected_full_json_sha256=snapshot["full_json_sha256"], scenarios=len(grid),
            grid_cells=sum(len(v) for v in grid.values()), changed_letters=len(summary["changed_letters"]),
            changed_evidence_cells=len(summary["changed_evidence_cells"]),
            added_trial_rows=summary["added"], removed_trial_rows=summary["removed"], trial_counts=counts)
    report["passed"] = True
    return report


if __name__ == "__main__":
    print(json.dumps(verify(), ensure_ascii=False, indent=2))

