# D18精神病性维度定向核查结果（进行中）

**核查日期**: 2026-11-28  
**任务**: 追溯六个药物D18维度的原始FDA证据，区分明确允许/明确排除/只排除schizophrenia/信息不足

---

## 已完成核查的记录

### 1. 文拉法辛：10条P编码→应改为X（明确排除psychotic disorder）

**原始编码**: P（部分允许）  
**核查结论**: X（明确排除精神病性障碍）  
**证据来源**: FDA-39ea3283f857 (021992s000_MedR_P2.pdf), 物理第64页  
**完整原文**:
> "Current (within 12 months of baseline) DSM-IV-defined: a) psychoactive substance abuse or dependence (including alcohol); b) a manic episode or a lifetime diagnosis of bipolar; c) obsessive-compulsive, or **psychotic disorder**."

**关键判断**:
- 明确排除"psychotic disorder"（精神病性障碍）
- 不是只排除schizophrenia，而是整个psychotic disorder类别
- 时间窗口：当前（基线前12个月内）
- DSM-IV定义明确

**受影响记录**: FT0035, FT0036, FT0038, FT0039, FT0040, FT0041, FT0042, FT0044, FT0045, FT0046（共10条）

**修正建议**: 
```
旧编码: P
新编码: X
R依据类型: 明确排除psychotic disorder（DSM-IV）
原文页码: FDA-39ea3283f857 p64
```

---

### 2. 帕罗西汀：1条P编码→保持P（排除与抑郁无关的精神病性障碍）

**原始编码**: P（部分允许）  
**核查结论**: P（部分允许，psychotic depression不在排除范围）  
**证据来源**: FDA-09fa9a58a24c (020699ap_effexor_medrp1.pdf), 物理第60页  
**完整原文**:
> "history or presence of any psychotic disorder **not related to depression**, bipolar disorder, or organic mental disorder."

**关键判断**:
- 排除的是"not related to depression"的精神病性障碍
- **psychotic depression（精神病性抑郁）明确不在排除范围内**
- 这是正确的P编码案例：部分允许特定亚型

**受影响记录**: FT0155

**修正建议**: 保持P编码不变

---

## 核查方法学说明

### 四类证据判定标准

1. **明确允许（N）**: 
   - 原文明确写明psychotic depression/psychotic features允许入组
   - 或完整排除清单中未提及精神病性相关疾病

2. **部分允许（P）**:
   - 排除"与抑郁无关的精神病性障碍"（如帕罗西汀案例）
   - 或只排除schizophrenia/schizoaffective但未排除psychotic depression
   - 语境提示可能允许部分精神病性患者

3. **明确排除（X）**:
   - 排除psychotic disorder/psychotic depression/psychotic features
   - 排除DSM定义的精神病性障碍类别（如文拉法辛案例）

4. **信息不足（?）**:
   - 无完整纳排条件
   - 仅有"no enumerated criteria"标注
   - 原文短摘不足以判断

### 不能采用的推断

- ✗ 从"排除schizophrenia"推断"排除psychotic depression"
- ✗ 从"未写排除"推断"实际入组psychotic depression患者"
- ✗ 从试验背景或常规做法推断具体纳排条件

---

## 待核查记录清单

### 舍曲林（7条）
- **X编码3条**: FT0002, FT0003, FT0004
  - 当前依据：排除schizophrenia/schizoaffective
  - 待核查：是否明确排除psychotic depression
  - 问题：证据文件名和页码缺失

- **N编码1条**: FT0005
  - 当前依据：完整清单推定
  - 待核查：清单是否真的完整且未提及

- **?编码3条**: FT0001, FT0006, FT0007
  - 待核查：是否有更完整纳排条件

### 米氮平（11条）
- **X编码10条**: FT0008-FT0017
  - 当前依据：排除schizophrenia or other psychosis
  - 待核查："other psychosis"是否包含psychotic depression
  - 关键词："a history of a primary diagnosis of schizophrenia or other psychosis"

- **?编码1条**: FT0013
  - 待核查：是否有更完整纳排条件

### 喹硫平（7条）
- **全部?编码**: FT0019-FT0025
  - 当前依据：no enumerated criteria
  - 待核查：是否有任何纳排条件原文

### 氟西汀（21条）
- **N编码18条**: FT0025-FT0042
  - 当前依据：完整清单推定
  - 待核查：清单是否真的完整

- **?编码3条**: FT0028, FT0043, FT0044
  - 待核查：是否有更完整纳排条件

### 帕罗西汀（剩余20条）
- **X编码8条**: FT0062-FT0069
  - 待核查：排除依据是否明确

- **N编码3条**: FT0063, FT0064, FT0065
  - 待核查：清单完整性

- **?编码9条**: FT0158, FT0159等
  - 待核查：是否有更完整纳排条件

---

## 对字母聚合的影响

### 当前主设定（R3/R5）
- 文拉法辛: **B格** (基于10条P编码)
- 帕罗西汀: **B格** (基于多条N和P编码)

### 核查后预计变化
- **文拉法辛**: B → 需重新计算
  - 10条P→X后，如无其他R/N/P支撑，可能降为C/D/E
  - 需检查剩余12条记录（1X, 3N, 8?）能否支撑

- **帕罗西汀**: B → 保持或需重新计算
  - 1条P保持
  - 需核查3N和8X的依据

### 聚合规则提醒
```python
if any(c == 'R' for c in pos):  # ≥2项R → A
    return 'A'
elif 'N' in pos:                # ≥1项N → B
    return 'B'
elif 'P' in pos:                # ≥1项P → B−
    return 'B−'
elif all(c == '?' for c in pos):
    return 'E'
else:  # 阳性试验全部排除
    if any(c == 'R' for c in neg):
        return 'C'
    else:
        return 'D*' if '?' in (pos+neg) else 'D'
```

---

## 下一步行动

1. **补充文件信息**: 舍曲林FT0002-FT0004的证据文件名和页码
2. **核查米氮平**: "other psychosis"语境是否包含psychotic depression
3. **核查喹硫平**: 7条?记录是否有原文可追溯
4. **核查氟西汀**: 18条N编码的完整清单依据
5. **核查帕罗西汀剩余**: 8X和3N的原文依据
6. **重新计算字母**: 基于修正后编码重新聚合文拉法辛和其他受影响药物

---

## 关键发现总结

1. **P编码需要严格区分**:
   - "排除psychotic disorder" → X
   - "排除不相关的psychotic disorder" → P
   - "排除schizophrenia" → 需查看是否提及psychotic depression

2. **Fix2的机械规则不完全准确**:
   - 将所有"排除schizophrenia"改为X可能过于激进
   - 需要完整语境判断

3. **完整清单推定需要验证**:
   - N编码中标注"完整清单推定"的记录需逐个核对原文
   - 不能仅凭"dimension not mentioned"推断允许入组

**核查进度**: 11/89条记录已核查（12.4%）  
**修正记录**: 1项（文拉法辛10条P→X）
