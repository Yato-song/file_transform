#!/usr/bin/env python3
"""D18精神病性维度六个B格药物的定向核查"""
import json
from pathlib import Path

def verify_d18_six_drugs():
    """
    核查目标：舍曲林、米氮平、喹硫平、氟西汀、文拉法辛、帕罗西汀在D18维度的原始证据

    任务：
    1. 追溯每个药物所有D18记录的原文、文件名、页码
    2. 区分：明确允许psychotic depression / 明确排除 / 只排除schizophrenia / 信息不足
    3. 不能从"排除schizophrenia"推断"排除psychotic depression"
    4. 不能从未写排除推断实际入组
    5. 识别父试验和方案ID
    """

    # 读取数据
    base_dir = Path('/Users/dxm/work/jingya/FDAcheck')
    dims_fix2 = json.load(open(base_dir / 'r5_fixes/data_corrected/phase3_dimensions_FIX2.json', encoding='utf-8'))
    trials = json.load(open(base_dir / 'r3_full_revision/phase2_trial_extractions_235.json', encoding='utf-8'))

    target_drugs = {
        '舍曲林': [],
        '米氮平': [],
        '喹硫平': [],
        '氟西汀': [],
        '文拉法辛': [],
        '帕罗西汀': []
    }

    # 收集所有D18记录
    for rec in dims_fix2:
        if rec.get('维度') != 'D18':
            continue

        drug = rec.get('药物', '')
        for target_drug in target_drugs.keys():
            if target_drug in drug:
                target_drugs[target_drug].append({
                    'FT': rec.get('模型记录ID'),
                    '试验': rec.get('试验名称候选'),
                    '药物': drug,
                    '代码_Fix2后': rec.get('独立代码_R_X_P_N_问号'),
                    'R依据': rec.get('R依据类型', ''),
                    '原文短摘': rec.get('原文短摘', ''),
                    '排除范围与时态': rec.get('排除范围与时态', ''),
                    '物理页与印刷页': rec.get('物理页与印刷页', ''),
                    '证据文件及SHA': rec.get('证据文件及SHA', ''),
                    '完整性与直接性': rec.get('完整性与直接性', '')
                })
                break

    # 统计各药物编码分布
    verification_plan = {
        'task': 'D18精神病性维度六个药物定向核查',
        'drugs': {}
    }

    for drug, records in target_drugs.items():
        code_dist = {}
        for rec in records:
            code = rec['代码_Fix2后']
            first = code[0] if code else '?'
            code_dist[first] = code_dist.get(first, 0) + 1

        # 识别需要核查的记录类型
        needs_verification = []

        # 1. P编码（部分允许）：需确认是真的允许psychotic depression还是只是未排除
        p_records = [r for r in records if r['代码_Fix2后'] and r['代码_Fix2后'][0] == 'P']
        if p_records:
            needs_verification.append({
                'code': 'P',
                'count': len(p_records),
                'question': '是否明确允许psychotic depression入组，还是只是未提及排除？',
                'records': [r['FT'] for r in p_records]
            })

        # 2. X编码（明确排除）：需确认是排除psychotic depression还是只排除schizophrenia
        x_records = [r for r in records if r['代码_Fix2后'] and r['代码_Fix2后'][0] == 'X']
        if x_records:
            needs_verification.append({
                'code': 'X',
                'count': len(x_records),
                'question': '排除的是psychotic depression，还是只排除schizophrenia/schizoaffective？',
                'records': [r['FT'] for r in x_records]
            })

        # 3. ?编码（信息不足）：需确认是否有更多原文信息
        q_records = [r for r in records if r['代码_Fix2后'] == '?' or (r['代码_Fix2后'] and r['代码_Fix2后'][0] == '?')]
        if q_records:
            needs_verification.append({
                'code': '?',
                'count': len(q_records),
                'question': '是否有完整纳排条件清单可以判定？',
                'records': [r['FT'] for r in q_records]
            })

        # 4. N编码（明确不排除）：需确认依据
        n_records = [r for r in records if r['代码_Fix2后'] and r['代码_Fix2后'][0] == 'N']
        if n_records:
            needs_verification.append({
                'code': 'N',
                'count': len(n_records),
                'question': '明确不排除psychotic depression的依据是什么？',
                'records': [r['FT'] for r in n_records]
            })

        verification_plan['drugs'][drug] = {
            'total_d18_records': len(records),
            'code_distribution': code_dist,
            'needs_verification': needs_verification,
            'all_records': records
        }

    # 保存核查计划
    output_dir = base_dir / 'r6_targeted_review'
    output_dir.mkdir(exist_ok=True)

    output_file = output_dir / 'd18_verification_plan.json'
    json.dump(verification_plan, open(output_file, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # 生成可读报告
    report_lines = []
    report_lines.append('# D18精神病性维度六个药物定向核查计划\n\n')
    report_lines.append('## 核查原则\n\n')
    report_lines.append('1. **不能从"排除schizophrenia"推断"排除psychotic depression"**\n')
    report_lines.append('2. **不能从未写排除推断实际入组psychotic depression患者**\n')
    report_lines.append('3. **需要完整纳排条件原文，不能依赖摘录片段**\n')
    report_lines.append('4. **区分四类证据**：明确允许 / 明确排除 / 只排除其他精神病 / 信息不足\n\n')

    report_lines.append('## 六个药物的D18记录统计\n\n')

    for drug, info in verification_plan['drugs'].items():
        report_lines.append(f'### {drug}\n\n')
        report_lines.append(f'- **D18记录总数**: {info["total_d18_records"]}条\n')
        report_lines.append(f'- **编码分布**: ')
        for code, count in sorted(info['code_distribution'].items()):
            report_lines.append(f'{code}={count}, ')
        report_lines.append('\n\n')

        report_lines.append(f'**需要核查的记录类型**:\n\n')
        for ver in info['needs_verification']:
            report_lines.append(f'- **{ver["code"]}编码** ({ver["count"]}条): {ver["question"]}\n')
            report_lines.append(f'  * 记录ID: {", ".join(ver["records"])}\n')

        report_lines.append('\n')

        # 展示前3条记录的详细信息作为示例
        report_lines.append(f'**详细记录示例** (前3条):\n\n')
        for i, rec in enumerate(info['all_records'][:3], 1):
            report_lines.append(f'{i}. **{rec["FT"]}** ({rec["试验"]})\n')
            report_lines.append(f'   - 代码: {rec["代码_Fix2后"]}\n')
            report_lines.append(f'   - R依据: {rec["R依据"]}\n')
            report_lines.append(f'   - 原文短摘: {rec["原文短摘"][:150]}...\n')
            if rec['排除范围与时态']:
                report_lines.append(f'   - 排除范围: {rec["排除范围与时态"][:150]}...\n')
            report_lines.append(f'   - 证据文件: {rec["证据文件及SHA"]}\n')
            report_lines.append(f'   - 页码: {rec["物理页与印刷页"]}\n')
            report_lines.append('\n')

    report_lines.append('## 下一步行动\n\n')
    report_lines.append('1. 逐个回到原始FDA文件，定位完整纳排条件章节\n')
    report_lines.append('2. 查找关键词：psychotic, psychosis, psychotic features, psychotic depression\n')
    report_lines.append('3. 区分schizophrenia (精神分裂症) vs psychotic depression (精神病性抑郁)\n')
    report_lines.append('4. 记录：明确允许 / 明确排除 / 只排除其他精神病 / 未提及 / 信息不足\n')
    report_lines.append('5. 识别父试验编号和方案ID\n')
    report_lines.append('6. 更新编码并记录原文依据\n')

    report_file = output_dir / 'd18_verification_plan.md'
    with open(report_file, 'w', encoding='utf-8') as f:
        f.writelines(report_lines)

    print(f'D18核查计划已生成：')
    print(f'  - JSON: {output_file}')
    print(f'  - 报告: {report_file}')
    print(f'\n六个药物D18记录统计：')
    for drug, info in verification_plan['drugs'].items():
        print(f'  {drug}: {info["total_d18_records"]}条 (编码分布: {info["code_distribution"]})')

    return verification_plan

if __name__ == '__main__':
    verify_d18_six_drugs()
