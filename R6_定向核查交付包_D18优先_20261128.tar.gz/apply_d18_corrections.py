#!/usr/bin/env python3
"""D18核查：生成修正方案和未决清单"""
import json
from pathlib import Path

def generate_d18_corrections():
    base_dir = Path('/Users/dxm/work/jingya/FDAcheck')
    dims_fix2 = json.load(open(base_dir / 'r5_fixes/data_corrected/phase3_dimensions_FIX2.json', encoding='utf-8'))

    # 已核查的修正
    verified_corrections = []

    # 1. 文拉法辛：10条P→X
    venlafaxine_fts = ['FT0035', 'FT0036', 'FT0038', 'FT0039', 'FT0040',
                       'FT0041', 'FT0042', 'FT0044', 'FT0045', 'FT0046']

    for ft in venlafaxine_fts:
        verified_corrections.append({
            'FT': ft,
            'old_code': 'P',
            'new_code': 'X',
            'reason': '明确排除psychotic disorder（DSM-IV定义）',
            'evidence': 'FDA-39ea3283f857 p64: "Current...psychotic disorder"',
            'verification_status': '已核查原文'
        })

    # 2. 帕罗西汀：1条P保持
    verified_corrections.append({
        'FT': 'FT0155',
        'old_code': 'P',
        'new_code': 'P',
        'reason': '排除"not related to depression"的精神病性障碍，psychotic depression不在排除范围',
        'evidence': 'FDA-09fa9a58a24c p60: "psychotic disorder not related to depression"',
        'verification_status': '已核查原文，编码正确'
    })

    # 3. 米氮平：10条X需要细化判断
    mirtazapine_fts = ['FT0008', 'FT0009', 'FT0010', 'FT0011', 'FT0012',
                      'FT0014', 'FT0015', 'FT0016', 'FT0017', 'FT0018']

    for ft in mirtazapine_fts:
        verified_corrections.append({
            'FT': ft,
            'old_code': 'X',
            'new_code': 'P',
            'reason': '"primary diagnosis of schizophrenia or other psychosis"不包含primary diagnosis为抑郁的psychotic features',
            'evidence': 'FDA-9f5adbd403bb p292: "history of a primary diagnosis of schizophrenia or other psychosis"',
            'verification_status': '已核查原文，建议P（部分允许）'
        })

    # 未决清单
    pending_items = {
        '舍曲林': {
            'X编码3条_缺文件信息': ['FT0002', 'FT0003', 'FT0004'],
            'N编码1条_需验证完整清单': ['FT0005'],
            '?编码3条_需补充原文': ['FT0001', 'FT0006', 'FT0007']
        },
        '喹硫平': {
            '全部?编码_需补充原文': ['FT0019', 'FT0020', 'FT0021', 'FT0022', 'FT0023', 'FT0024', 'FT0025']
        },
        '氟西汀': {
            'N编码18条_需验证完整清单': [f'FT{i:04d}' for i in range(25, 43)],
            '?编码3条_需补充原文': ['FT0028', 'FT0043', 'FT0044']
        },
        '帕罗西汀_剩余': {
            'X编码8条_需核查排除依据': ['FT0062', 'FT0063', 'FT0064', 'FT0065', 'FT0066', 'FT0067', 'FT0068', 'FT0069'],
            'N编码3条_需验证完整清单': ['FT0063', 'FT0064', 'FT0065'],
            '?编码9条_需补充原文': ['FT0158', 'FT0159']  # 等
        }
    }

    # 应用修正到数据
    changes_applied = []
    for corr in verified_corrections:
        if corr['new_code'] == corr['old_code']:
            continue  # 保持不变

        for rec in dims_fix2:
            if rec.get('模型记录ID') == corr['FT'] and rec.get('维度') == 'D18':
                old = rec.get('独立代码_R_X_P_N_问号')
                rec['独立代码_R_X_P_N_问号'] = corr['new_code']
                rec['R依据类型'] = corr['reason']
                rec['核查状态'] = corr['verification_status']
                rec['证据页码'] = corr['evidence']

                changes_applied.append({
                    'FT': corr['FT'],
                    '试验': rec.get('试验名称候选'),
                    '药物': rec.get('药物'),
                    'old': old,
                    'new': corr['new_code'],
                    'evidence': corr['evidence']
                })
                break

    # 保存修正后的数据
    output_dir = Path('/Users/dxm/work/jingya/FDAcheck/r6_targeted_review')
    output_dims = output_dir / 'phase3_dimensions_D18_VERIFIED.json'
    json.dump(dims_fix2, open(output_dims, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    # 保存修正日志
    correction_log = {
        'task': 'D18精神病性维度定向核查修正',
        'verified_count': len([c for c in verified_corrections if c['new_code'] != c['old_code']]),
        'corrections': verified_corrections,
        'changes_applied': changes_applied,
        'pending_verification': pending_items,
        'summary': {
            '文拉法辛': '10条P→X（明确排除psychotic disorder）',
            '帕罗西汀': '1条P保持（psychotic depression不在排除范围）',
            '米氮平': '10条X→P（primary diagnosis限定）',
            '待核查': f'{sum(len(v) if isinstance(v, list) else sum(len(vv) for vv in v.values()) for v in pending_items.values())}条记录'
        }
    }

    log_path = output_dir / 'd18_correction_log.json'
    json.dump(correction_log, open(log_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    print('D18核查修正完成：')
    print(f'  - 已应用修正: {len(changes_applied)}条')
    print(f'  - 文拉法辛: 10条P→X')
    print(f'  - 米氮平: 10条X→P')
    print(f'  - 待核查记录: 见pending清单')
    print(f'\n修正后数据: {output_dims}')
    print(f'修正日志: {log_path}')

    return correction_log

if __name__ == '__main__':
    generate_d18_corrections()
