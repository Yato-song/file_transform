#!/usr/bin/env python3
"""基于D18核查结果重新计算字母聚合"""
import json
from pathlib import Path
from collections import Counter

def recalculate_d18_letters():
    base_dir = Path('/Users/dxm/work/jingya/FDAcheck')

    # 读取修正后的维度数据
    dims_verified = json.load(open(base_dir / 'r6_targeted_review/phase3_dimensions_D18_VERIFIED.json', encoding='utf-8'))
    trials = json.load(open(base_dir / 'r3_full_revision/phase2_trial_extractions_235.json', encoding='utf-8'))

    # 构建试验索引
    trial_index = {}
    for t in trials:
        key = f"{t.get('药物', '')}|{t.get('试验名称候选', '')}"
        if key not in trial_index:
            trial_index[key] = []
        trial_index[key].append(t)

    # 构建维度编码索引（仅D18）
    code_index = {}
    for rec in dims_verified:
        if rec.get('维度') == 'D18':
            trial_key = f"{rec.get('药物')}|{rec.get('试验名称候选')}"
            code_index[trial_key] = rec.get('独立代码_R_X_P_N_问号', '?')

    # 聚合字母（简化版：仅针对三个已核查药物）
    target_drugs = ['舍曲林', '米氮平', '文拉法辛', '帕罗西汀', '氟西汀', '喹硫平']

    results = {}

    for drug_name in target_drugs:
        # 收集该药物所有D18记录
        d18_codes = []
        pos_codes = []

        for rec in dims_verified:
            if drug_name in rec.get('药物', '') and rec.get('维度') == 'D18':
                code = rec.get('独立代码_R_X_P_N_问号', '?')
                d18_codes.append(code)

                # 查找对应试验的FDA判定
                trial_key = f"{rec.get('药物')}|{rec.get('试验名称候选')}"
                if trial_key in trial_index:
                    for t in trial_index[trial_key]:
                        judgment = t.get('FDA判定', '')
                        if judgment in ('positive', '阳性/支持性', 'supportive'):
                            pos_codes.append(code)
                            break

        # 应用聚合规则
        if not pos_codes:
            letter = '—'
        elif any(c == 'R' for c in pos_codes if c):
            if sum(1 for c in pos_codes if c == 'R') >= 2:
                letter = 'A'
            else:
                letter = 'A'  # 单项R也是A
        elif any(c and c[0] == 'N' for c in pos_codes):
            letter = 'B'
        elif any(c and c[0] == 'P' for c in pos_codes):
            letter = 'B−'
        elif all(c == '?' for c in pos_codes):
            letter = 'E'
        else:
            # 阳性试验全部排除
            letter = 'D*'  # 简化，实际需检查阴性试验

        code_dist = Counter(c[0] if c else '?' for c in d18_codes)

        results[drug_name] = {
            'total_d18_records': len(d18_codes),
            'code_distribution': dict(code_dist),
            'positive_trial_codes': pos_codes,
            'letter_before': '需查询R5数据',
            'letter_after': letter,
            'change': f'待与R5对比'
        }

    # 生成报告
    report_lines = []
    report_lines.append('# D18核查后字母聚合重算结果\n\n')
    report_lines.append('## 核查修正摘要\n\n')
    report_lines.append('- **文拉法辛**: 10条P→X（明确排除psychotic disorder）\n')
    report_lines.append('- **米氮平**: 10条X→P（primary diagnosis限定）\n')
    report_lines.append('- **帕罗西汀**: 1条P保持（排除与抑郁无关的精神病性障碍）\n\n')

    report_lines.append('## 六个药物D18维度字母变化\n\n')
    report_lines.append('| 药物 | D18记录数 | 编码分布 | 阳性试验编码 | 核查后字母 |\n')
    report_lines.append('|------|-----------|----------|--------------|------------|\n')

    for drug, info in results.items():
        code_str = ', '.join(f'{k}={v}' for k, v in info['code_distribution'].items())
        pos_str = ', '.join(info['positive_trial_codes'][:5])
        if len(info['positive_trial_codes']) > 5:
            pos_str += '...'
        report_lines.append(f"| {drug} | {info['total_d18_records']} | {code_str} | {pos_str} | {info['letter_after']} |\n")

    report_lines.append('\n## 关键发现\n\n')
    report_lines.append('### 文拉法辛\n')
    report_lines.append('- **修正前**: 10条P编码，聚合为B格\n')
    report_lines.append('- **修正后**: 10条P→X，所有阳性试验明确排除psychotic disorder\n')
    report_lines.append('- **预计字母**: B → 需检查剩余12条记录（1X, 3N, 8?）能否支撑\n\n')

    report_lines.append('### 米氮平\n')
    report_lines.append('- **修正前**: 10条X编码（排除schizophrenia or other psychosis）\n')
    report_lines.append('- **修正后**: 10条X→P，"primary diagnosis"限定不包含psychotic depression\n')
    report_lines.append('- **预计字母**: 保持或提升（P编码支撑B−格）\n\n')

    report_lines.append('### 帕罗西汀\n')
    report_lines.append('- **核查结果**: 1条P编码正确（排除与抑郁无关的精神病性障碍）\n')
    report_lines.append('- **预计字母**: 保持B格（需核查其他N和X编码）\n\n')

    report_lines.append('## 聚合规则说明\n\n')
    report_lines.append('```\n')
    report_lines.append('阳性试验编码聚合：\n')
    report_lines.append('- R编码（实际入组） → A格（2项及以上）或A格（单项）\n')
    report_lines.append('- N编码（明确不排除） → B格\n')
    report_lines.append('- P编码（部分允许） → B−格\n')
    report_lines.append('- X编码（明确排除） + 阴性R → C格\n')
    report_lines.append('- X编码（明确排除） + 无阴性R → D/D*格\n')
    report_lines.append('- 全?编码 → E格\n')
    report_lines.append('```\n\n')

    report_lines.append('## 待完成工作\n\n')
    report_lines.append('1. **补充舍曲林、喹硫平、氟西汀的原文核查**\n')
    report_lines.append('2. **完整重算所有31个药物的D18字母**\n')
    report_lines.append('3. **与R5主分析19维度对比差异**\n')
    report_lines.append('4. **生成S17等敏感性设定的字母变化**\n\n')

    report_file = base_dir / 'r6_targeted_review' / 'd18_letter_recalculation.md'
    with open(report_file, 'w', encoding='utf-8') as f:
        f.writelines(report_lines)

    # 保存JSON结果
    json_result = {
        'task': 'D18核查后字母重算',
        'drugs_analyzed': target_drugs,
        'results': results,
        'summary': {
            '已核查药物': 3,
            '已修正记录': 20,
            '待核查记录': '见pending清单'
        }
    }

    json_file = base_dir / 'r6_targeted_review' / 'd18_letter_recalculation.json'
    json.dump(json_result, open(json_file, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    print('D18字母重算完成')
    print(f'  报告: {report_file}')
    print(f'  数据: {json_file}')

    for drug, info in results.items():
        print(f'\n{drug}:')
        print(f'  编码分布: {info["code_distribution"]}')
        print(f'  核查后字母: {info["letter_after"]}')

if __name__ == '__main__':
    recalculate_d18_letters()
