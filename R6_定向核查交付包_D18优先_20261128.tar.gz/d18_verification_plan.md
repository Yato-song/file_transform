# D18精神病性维度六个药物定向核查计划

## 核查原则

1. **不能从"排除schizophrenia"推断"排除psychotic depression"**
2. **不能从未写排除推断实际入组psychotic depression患者**
3. **需要完整纳排条件原文，不能依赖摘录片段**
4. **区分四类证据**：明确允许 / 明确排除 / 只排除其他精神病 / 信息不足

## 六个药物的D18记录统计

### 舍曲林

- **D18记录总数**: 7条
- **编码分布**: ?=3, N=1, X=3, 

**需要核查的记录类型**:

- **X编码** (3条): 排除的是psychotic depression，还是只排除schizophrenia/schizoaffective？
  * 记录ID: FT0002, FT0003, FT0004
- **?编码** (3条): 是否有完整纳排条件清单可以判定？
  * 记录ID: FT0001, FT0006, FT0007
- **N编码** (1条): 明确不排除psychotic depression的依据是什么？
  * 记录ID: FT0005

**详细记录示例** (前3条):

1. **FT0001** (103)
   - 代码: ?
   - R依据: 
   - 原文短摘: or medications for physical illness), history of serious intolerance or resistance to antidepressant drugs, presence or history of significant disease...
   - 证据文件: c3e1641beda0_fdadrug_27.pdf | c3e1641beda0016f
   - 页码: 物理9页

2. **FT0002** (104)
   - 代码: X
   - R依据: 排除其他精神病（schizophrenia非psychotic depression）
   - 原文短摘: schizophrenia or scht~ ,di sorrier....
   - 证据文件: 
   - 页码: 

3. **FT0003** (101)
   - 代码: X
   - R依据: 排除其他精神病（schizophrenia非psychotic depression）
   - 原文短摘: alcohol or ~ drug abuse, ;;chir.:opiJenia or schizoaffectivE! disorder....
   - 证据文件: 
   - 页码: 

### 米氮平

- **D18记录总数**: 11条
- **编码分布**: ?=1, X=10, 

**需要核查的记录类型**:

- **X编码** (10条): 排除的是psychotic depression，还是只排除schizophrenia/schizoaffective？
  * 记录ID: FT0008, FT0009, FT0010, FT0011, FT0012, FT0014, FT0015, FT0016, FT0017, FT0018
- **?编码** (1条): 是否有完整纳排条件清单可以判定？
  * 记录ID: FT0013

**详细记录示例** (前3条):

1. **FT0008** (003-002)
   - 代码: X
   - R依据: 排除其他精神病（schizophrenia非psychotic depression）
   - 原文短摘: Exclusion Criteria: -A history of a primary diagnosis of • schizophrenia or other psychosis....
   - 证据文件: 
   - 页码: 

2. **FT0009** (003-020)
   - 代码: X
   - R依据: 排除其他精神病（schizophrenia非psychotic depression）
   - 原文短摘: .Patients with any of the following psychiatric diagnoses: schizophrenia;...
   - 证据文件: 9f5adbd403bb_020415Orig1s000rev.pdf | 9f5adbd403bbe4b3
   - 页码: 物理302页

3. **FT0010** (003-022)
   - 代码: X
   - R依据: 排除其他精神病（schizophrenia非psychotic depression）
   - 原文短摘: .Patients with any of the following psychiatric diagnoses: schizophrenia;...
   - 证据文件: 9f5adbd403bb_020415Orig1s000rev.pdf | 9f5adbd403bbe4b3
   - 页码: 物理302页

### 喹硫平

- **D18记录总数**: 7条
- **编码分布**: ?=7, 

**需要核查的记录类型**:

- **?编码** (7条): 是否有完整纳排条件清单可以判定？
  * 记录ID: FT0019, FT0020, FT0021, FT0022, FT0023, FT0024, FT0164

**详细记录示例** (前3条):

1. **FT0019** (D1448C00006)
   - 代码: ?
   - R依据: 
   - 原文短摘: no enumerated criteria...
   - 证据文件: 
   - 页码: 

2. **FT0020** (D1448C00007)
   - 代码: ?
   - R依据: 
   - 原文短摘: no enumerated criteria...
   - 证据文件: 
   - 页码: 

3. **FT0021** (D1448C00001)
   - 代码: ?
   - R依据: 
   - 原文短摘: no enumerated criteria...
   - 证据文件: 
   - 页码: 

### 氟西汀

- **D18记录总数**: 21条
- **编码分布**: ?=3, N=18, 

**需要核查的记录类型**:

- **?编码** (3条): 是否有完整纳排条件清单可以判定？
  * 记录ID: FT0028, FT0156, FT0157
- **N编码** (18条): 明确不排除psychotic depression的依据是什么？
  * 记录ID: FT0025, FT0026, FT0027, FT0029, FT0030, FT0116, FT0117, FT0118, FT0119, FT0120, FT0121, FT0122, FT0123, FT0124, FT0125, FT0135, FT0161, FT0162

**详细记录示例** (前3条):

1. **FT0025** (19)
   - 代码: N
   - R依据: 
   - 原文短摘: complete exclusion list; dimension not mentioned...
   - 证据文件: 
   - 页码: 

2. **FT0026** (27)
   - 代码: N
   - R依据: 
   - 原文短摘: complete exclusion list; dimension not mentioned...
   - 证据文件: 
   - 页码: 

3. **FT0027** (62（中度层）)
   - 代码: N
   - R依据: 
   - 原文短摘: complete exclusion list; dimension not mentioned...
   - 证据文件: 
   - 页码: 

### 文拉法辛

- **D18记录总数**: 22条
- **编码分布**: ?=8, N=3, P=10, X=1, 

**需要核查的记录类型**:

- **P编码** (10条): 是否明确允许psychotic depression入组，还是只是未提及排除？
  * 记录ID: FT0035, FT0036, FT0038, FT0039, FT0040, FT0041, FT0042, FT0052, FT0053, FT0058
- **X编码** (1条): 排除的是psychotic depression，还是只排除schizophrenia/schizoaffective？
  * 记录ID: FT0037
- **?编码** (8条): 是否有完整纳排条件清单可以判定？
  * 记录ID: FT0054, FT0055, FT0056, FT0059, FT0060, FT0134, FT0153, FT0154
- **N编码** (3条): 明确不排除psychotic depression的依据是什么？
  * 记录ID: FT0043, FT0057, FT0136

**详细记录示例** (前3条):

1. **FT0035** (3151A1-306)
   - 代码: P
   - R依据: 
   - 原文短摘: Outpatients with a primary diagnosis of Major Depressive Disorder, single or recurrent episode, without psychotic features (based on DSM-IV criteria)....
   - 排除范围: Outpatients with a primary diagnosis of Major Depressive Disorder, single or recurrent episode, without psychotic features (based on DSM-IV criteria)....
   - 证据文件: 39ea3283f857_021992s000_MedR_P2.pdf | 39ea3283f857db81
   - 页码: 物理64页

2. **FT0036** (3151A1-308)
   - 代码: P
   - R依据: 
   - 原文短摘: Outpatients with a primary diagnosis of Major Depressive Disorder, single or recurrent episode, without psychotic features (based on DSM-IV criteria)....
   - 排除范围: Outpatients with a primary diagnosis of Major Depressive Disorder, single or recurrent episode, without psychotic features (based on DSM-IV criteria)....
   - 证据文件: 39ea3283f857_021992s000_MedR_P2.pdf | 39ea3283f857db81
   - 页码: 物理64页

3. **FT0037** (3151A1-333)
   - 代码: X
   - R依据: 
   - 原文短摘: 2.3.1 Inclusion Criteria Outpatient men and women at least 18 years of age Primary diagnosis of Major Depressive Disorder based on DSM-IV criteria, si...
   - 排除范围: 2.3.1 Inclusion Criteria Outpatient men and women at least 18 years of age Primary diagnosis of Major Depressive Disorder based on DSM-IV criteria, si...
   - 证据文件: 
   - 页码: 

### 帕罗西汀

- **D18记录总数**: 21条
- **编码分布**: ?=9, N=3, P=1, X=8, 

**需要核查的记录类型**:

- **P编码** (1条): 是否明确允许psychotic depression入组，还是只是未提及排除？
  * 记录ID: FT0155
- **X编码** (8条): 排除的是psychotic depression，还是只排除schizophrenia/schizoaffective？
  * 记录ID: FT0069, FT0070, FT0071, FT0072, FT0075, FT0076, FT0147, FT0148
- **?编码** (9条): 是否有完整纳排条件清单可以判定？
  * 记录ID: FT0065, FT0066, FT0067, FT0068, FT0074, FT0077, FT0078, FT0158, FT0159
- **N编码** (3条): 明确不排除psychotic depression的依据是什么？
  * 记录ID: FT0063, FT0064, FT0073

**详细记录示例** (前3条):

1. **FT0063** (CR 449)
   - 代码: N
   - R依据: 
   - 原文短摘: complete exclusion list; dimension not mentioned...
   - 证据文件: 
   - 页码: 

2. **FT0064** (CR 487)
   - 代码: N
   - R依据: 
   - 原文短摘: complete exclusion list; dimension not mentioned...
   - 证据文件: 
   - 页码: 

3. **FT0065** (PAR 01-001)
   - 代码: ?
   - R依据: 语境不清，无法判断是否排除psychotic depression
   - 原文短摘: In '~h' :\1.1 Efficacy sample there was a signit'icant (p-.09) Interaction of treatment with family history of non-psychotic psychiatric disturbance....
   - 证据文件: 
   - 页码: 

## 下一步行动

1. 逐个回到原始FDA文件，定位完整纳排条件章节
2. 查找关键词：psychotic, psychosis, psychotic features, psychotic depression
3. 区分schizophrenia (精神分裂症) vs psychotic depression (精神病性抑郁)
4. 记录：明确允许 / 明确排除 / 只排除其他精神病 / 未提及 / 信息不足
5. 识别父试验编号和方案ID
6. 更新编码并记录原文依据
