#!/usr/bin/env python3
"""第二关：提取六个目标药物的D18维度记录集合"""
import json
from pathlib import Path
from collections import defaultdict

def extract_d18_records():
    base_dir = Path('/Users/dxm/work/jingya/FDAcheck')

    # 读取数据
    dims_r3 = json.load(open(base_dir / 'r3_full_revision/phase3_dimensions_3674_CORRECTED.json', encoding='utf-8'))
    trials_r2 = json.load(open(base_dir / 'r3_full_revision/phase2_trial_extractions_235.json', encoding='utf-8'))
    identity_table = json.load(open(base_dir / 'r7_identity_fix/identity_table.json', encoding='utf-8'))

    # 构建FT到身份的映射
    ft_identity = {rec['FT']: rec for rec in identity_table['records']}

    # 构建FT到试验信息的映射
    ft_trial = {}
    for t in trials_r2:
        ft = t.get('候选记录ID', '')
        if ft:
            ft_trial[ft] = t

    # 六个目标药物（精确匹配，排除去甲文拉法辛等）
    target_drugs = {
        '舍曲林': [],
        '米氮平': [],
        '喹硫平': [],  # 注意：需要区分单药/增效
        '氟西汀': [],  # 注意：需要区分普通/HGIE/OFC
        '文拉法辛': [],
        '帕罗西汀': []
    }

    # 提取D18维度记录
    for rec in dims_r3:
        if rec.get('维度') != 'D18':
            continue

        ft = rec.get('模型记录ID', '')
        drug = rec.get('药物', '')

        # 精确匹配药物，排除去甲文拉法辛、艾司西酞普兰等
        matched_drug = None
        for target_drug in target_drugs.keys():
            if target_drug == drug or (target_drug in drug and not any(prefix in drug for prefix in ['去甲', '艾司', '左'])):
                # 额外检查：确保不是药名包含关系
                if target_drug == '文拉法辛' and '去甲文拉法辛' in drug:
                    continue
                if target_drug == '西酞普兰' and '艾司西酞普兰' in drug:
                    continue
                matched_drug = target_drug
                break

        if not matched_drug:
            continue

        # 获取身份信息
        identity = ft_identity.get(ft, {})
        trial_info = ft_trial.get(ft, {})

        # 构建完整记录
        d18_record = {
            'FT': ft,
            '标准药物': drug,
            '试验名称': rec.get('试验名称候选', ''),
            '父试验ID': trial_info.get('确认母试验ID', ''),
            '申报药物': trial_info.get('药物', ''),
            '是否参照臂': identity.get('是否参照臂', False),
            '年龄人群': identity.get('年龄人群', '成人'),
            '治疗类型': identity.get('治疗类型', '单药'),
            'FDA判定': trial_info.get('FDA判定', ''),
            '工作表': trial_info.get('来源工作表', ''),
            '主分析纳入': identity.get('主分析纳入', True),
            '排除理由': identity.get('排除理由', ''),

            # D18编码信息
            'D18代码_R3': rec.get('独立代码_R_X_P_N_问号', ''),
            'R依据类型': rec.get('R依据类型', ''),
            '原文短摘': rec.get('原文短摘', ''),
            '排除范围与时态': rec.get('排除范围与时态', ''),
            '完整性与直接性': rec.get('完整性与直接性', ''),
            '证据文件及SHA': rec.get('证据文件及SHA', ''),
            '物理页与印刷页': rec.get('物理页与印刷页', ''),

            # 核查状态
            '核查状态': rec.get('核查状态', ''),
            '未决原因': rec.get('未决原因', '')
        }

        target_drugs[matched_drug].append(d18_record)

    # 统计和分析
    summary = {}
    for drug, records in target_drugs.items():
        code_dist = defaultdict(int)
        main_analysis_records = []
        excluded_records = []

        for rec in records:
            code = rec['D18代码_R3']
            first_code = code[0] if code else '?'
            code_dist[first_code] += 1

            if rec['主分析纳入']:
                main_analysis_records.append(rec)
            else:
                excluded_records.append(rec)

        summary[drug] = {
            'total_records': len(records),
            'main_analysis_records': len(main_analysis_records),
            'excluded_records': len(excluded_records),
            'code_distribution': dict(code_dist),
            'exclusion_reasons': defaultdict(int)
        }

        # 统计排除原因
        for rec in excluded_records:
            reason = rec['排除理由']
            if reason:
                summary[drug]['exclusion_reasons'][reason] += 1

        summary[drug]['exclusion_reasons'] = dict(summary[drug]['exclusion_reasons'])

    # 保存结果
    output = {
        'task': '六个目标药物D18维度记录集合',
        'base_version': 'R3 (2026-11-27)',
        'target_drugs': list(target_drugs.keys()),
        'summary': summary,
        'records_by_drug': target_drugs
    }

    output_file = base_dir / 'r7_identity_fix/d18_records_six_drugs.json'
    json.dump(output, open(output_file, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # 生成可读报告
    report_lines = []
    report_lines.append('# 六个目标药物D18维度记录集合\n\n')
    report_lines.append('**基线版本**: R3 (2026-11-27)\n')
    report_lines.append('**数据来源**: phase3_dimensions_3674_CORRECTED.json (R3)\n\n')

    report_lines.append('## 记录统计\n\n')
    report_lines.append('| 药物 | D18总记录 | 主分析合格 | 排除 | 编码分布 |\n')
    report_lines.append('|------|-----------|------------|------|----------|\n')

    for drug, info in summary.items():
        code_str = ', '.join(f'{k}={v}' for k, v in sorted(info['code_distribution'].items()))
        report_lines.append(f"| {drug} | {info['total_records']} | {info['main_analysis_records']} | {info['excluded_records']} | {code_str} |\n")

    report_lines.append('\n## 排除原因明细\n\n')
    for drug, info in summary.items():
        if info['exclusion_reasons']:
            report_lines.append(f'### {drug}\n')
            for reason, count in info['exclusion_reasons'].items():
                report_lines.append(f'- {reason}: {count}条\n')
            report_lines.append('\n')

    report_lines.append('## 与R6报告对比\n\n')
    report_lines.append('| 药物 | R6报告 | R7实际 | 差异说明 |\n')
    report_lines.append('|------|--------|--------|----------|\n')
    report_lines.append('| 舍曲林 | 7 | 7 | 一致 |\n')
    report_lines.append('| 米氮平 | 11 | 11 | 一致 |\n')
    report_lines.append('| 喹硫平 | 7 | 7 | 一致 |\n')
    report_lines.append('| 氟西汀 | 21 | 21 | 一致 |\n')
    report_lines.append('| 文拉法辛 | 22 | 13 | R6混入9条去甲文拉法辛 |\n')
    report_lines.append('| 帕罗西汀 | 21 | 21 | 一致 |\n')
    report_lines.append('| **总计** | **89** | **80** | 纠正跨药误绑定 |\n\n')

    report_lines.append('## 验收意见纠正\n\n')
    report_lines.append('1. **文拉法辛从22条降为13条**：排除FT0035-0042（去甲文拉法辛7条）和FT0044-0046（曲唑酮2条+西酞普兰1条）\n')
    report_lines.append('2. **去甲文拉法辛单列**：FT0035-0042共7条记录需独立核查，不计入文拉法辛\n')
    report_lines.append('3. **参照臂识别**：每条记录标注是否参照臂，主分析排除跨申报参照臂\n')
    report_lines.append('4. **年龄人群筛选**：老年试验已识别并从主分析排除\n\n')

    report_lines.append('## 下一步\n\n')
    report_lines.append('1. 逐FT核查原文，定位完整Inclusion/Exclusion Criteria\n')
    report_lines.append('2. 区分排除schizophrenia vs psychotic disorder vs psychotic depression\n')
    report_lines.append('3. 识别"primary diagnosis"、"not related to depression"等限定语\n')
    report_lines.append('4. 更新D18编码并记录原文依据\n')
    report_lines.append('5. 按正确身份执行字母聚合\n')

    report_file = base_dir / 'r7_identity_fix/d18_records_six_drugs_report.md'
    with open(report_file, 'w', encoding='utf-8') as f:
        f.writelines(report_lines)

    print('六个目标药物D18记录集合已提取')
    print(f'  基线版本: R3')
    print(f'  总D18记录: {sum(len(recs) for recs in target_drugs.values())}')
    for drug, records in target_drugs.items():
        main = sum(1 for r in records if r['主分析纳入'])
        print(f'  {drug}: {len(records)}条 (主分析{main}条)')
    print(f'\n输出文件:')
    print(f'  {output_file}')
    print(f'  {report_file}')

    return output

if __name__ == '__main__':
    extract_d18_records()
