#!/usr/bin/env python3
"""D18编码裁决与更新"""
import json
from pathlib import Path

def update_d18_codes():
    base_dir = Path('/Users/dxm/work/jingya/FDAcheck')

    # 读取R3基线
    dims_r3 = json.load(open(base_dir / 'r3_full_revision/phase3_dimensions_3674_CORRECTED.json', encoding='utf-8'))

    # 已核查记录的编码裁决
    verified_decisions = {
        # 去甲文拉法辛：纳入要求without psychotic features + 排除psychotic disorder
        'FT0035': {'old': 'P', 'new': 'X', 'reason': '纳入标准要求without psychotic features，排除标准排除psychotic disorder（12个月内）', 'evidence': 'FDA-39ea3283f857 p64行12+行43', 'drug': '去甲文拉法辛'},
        'FT0036': {'old': 'P', 'new': 'X', 'reason': '纳入标准要求without psychotic features，排除标准排除psychotic disorder（12个月内）', 'evidence': 'FDA-39ea3283f857 p64行12+行43', 'drug': '去甲文拉法辛'},
        'FT0038': {'old': 'P', 'new': 'X', 'reason': '同FT0035-0036（共用第64页条件）', 'evidence': 'FDA-39ea3283f857 p64', 'drug': '去甲文拉法辛'},
        'FT0039': {'old': 'P', 'new': 'X', 'reason': '同FT0035-0036（共用第64页条件）', 'evidence': 'FDA-39ea3283f857 p64', 'drug': '去甲文拉法辛'},
        'FT0040': {'old': 'P', 'new': 'X', 'reason': '同FT0035-0036（共用第64页条件）', 'evidence': 'FDA-39ea3283f857 p64', 'drug': '去甲文拉法辛'},
        'FT0041': {'old': 'P', 'new': 'X', 'reason': '同FT0035-0036（共用第64页条件）', 'evidence': 'FDA-39ea3283f857 p64', 'drug': '去甲文拉法辛'},
        'FT0042': {'old': 'P', 'new': 'X', 'reason': '同FT0035-0036（共用第64页条件）', 'evidence': 'FDA-39ea3283f857 p64', 'drug': '去甲文拉法辛'},

        # 米氮平003-002：primary diagnosis限定，纳入标准未限制psychotic features
        'FT0008': {'old': 'X', 'new': 'P', 'reason': '排除"primary diagnosis of schizophrenia or other psychosis"，不包含primary diagnosis为MDD的psychotic features；纳入标准未限制psychotic features', 'evidence': 'FDA-9f5adbd403bb p291-292', 'drug': '米氮平'},

        # 帕罗西汀参照臂：not related to depression限定
        'FT0155': {'old': 'P', 'new': 'P', 'reason': '排除"psychotic disorder not related to depression"，psychotic depression不在排除范围；但此为参照臂，不计入主分析', 'evidence': 'FDA-09fa9a58a24c p60', 'drug': '帕罗西汀', 'is_reference_arm': True}
    }

    # 应用修正
    changes_applied = []
    for rec in dims_r3:
        if rec.get('维度') != 'D18':
            continue

        ft = rec.get('模型记录ID')
        if ft not in verified_decisions:
            continue

        decision = verified_decisions[ft]
        old_code = rec.get('独立代码_R_X_P_N_问号')

        if decision['new'] != old_code:
            rec['独立代码_R_X_P_N_问号'] = decision['new']
            rec['R依据类型'] = decision['reason']
            rec['核查状态'] = '已核查原文完整纳排标准'
            rec['证据页码'] = decision['evidence']

            changes_applied.append({
                'FT': ft,
                'drug': decision['drug'],
                'trial': rec.get('试验名称候选'),
                'old_code': old_code,
                'new_code': decision['new'],
                'reason': decision['reason'],
                'evidence': decision['evidence'],
                'is_reference_arm': decision.get('is_reference_arm', False)
            })

    # 保存修正后数据
    output_dims = base_dir / 'r7_identity_fix/phase3_dimensions_D18_VERIFIED_R7.json'
    json.dump(dims_r3, open(output_dims, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

    # 保存修正日志
    correction_log = {
        'task': 'D18编码裁决（已核查原文）',
        'base_version': 'R3 (2026-11-27)',
        'verified_records': len(verified_decisions),
        'changes_applied': len(changes_applied),
        'decisions': verified_decisions,
        'changes': changes_applied,
        'notes': [
            '去甲文拉法辛7条：纳入标准without psychotic features为更直接依据',
            '米氮平003-002：primary diagnosis限定不包含psychotic features of MDD',
            '帕罗西汀FT0155：参照臂，不计入主分析',
            '未核查记录保持R3编码，标注待核'
        ]
    }

    log_path = base_dir / 'r7_identity_fix/d18_correction_log_verified.json'
    json.dump(correction_log, open(log_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    print('D18编码裁决完成')
    print(f'  核查记录: {len(verified_decisions)}条')
    print(f'  代码变更: {len(changes_applied)}条')
    print(f'    去甲文拉法辛7条P→X')
    print(f'    米氮平1条X→P')
    print(f'    帕罗西汀1条P保持（参照臂）')
    print(f'\n输出文件:')
    print(f'  {output_dims}')
    print(f'  {log_path}')

    return correction_log

if __name__ == '__main__':
    update_d18_codes()
