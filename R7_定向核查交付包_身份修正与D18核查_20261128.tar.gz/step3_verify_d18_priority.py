#!/usr/bin/env python3
"""第三关：逐FT核查D18原文并更新编码"""
import json
from pathlib import Path

def verify_d18_original_text():
    base_dir = Path('/Users/dxm/work/jingya/FDAcheck')

    # 读取D18记录集合
    d18_data = json.load(open(base_dir / 'r7_identity_fix/d18_records_six_drugs.json', encoding='utf-8'))

    # 读取OCR文本
    def read_ocr_page(file_sha, page_num):
        """读取指定文件的指定页"""
        file_id = file_sha.split('|')[0].strip() if '|' in file_sha else file_sha.split()[0]
        file_id = file_id.replace('.pdf', '').replace('_', '-')

        ocr_path = base_dir / f'r3_full_revision/_ocrtext/FDA-{file_id}.json'
        if not ocr_path.exists():
            return None

        try:
            ocr_data = json.load(open(ocr_path, encoding='utf-8'))
            return ocr_data['pages'].get(str(page_num), None)
        except:
            return None

    # 验收意见重点核查的记录
    priority_checks = [
        # 去甲文拉法辛（FT0035-0042）：验收意见要求单列，不计入文拉法辛
        # 物理64页，文件39ea3283f857
        {'FT': 'FT0035', 'file': '39ea3283f857', 'page': 64, 'drug': '去甲文拉法辛', 'trial': '3151A1-306'},
        {'FT': 'FT0036', 'file': '39ea3283f857', 'page': 64, 'drug': '去甲文拉法辛', 'trial': '3151A1-308'},

        # 米氮平003-002：验收意见确认物理292页
        {'FT': 'FT0008', 'file': '9f5adbd403bb', 'page': 292, 'drug': '米氮平', 'trial': '003-002'},

        # 帕罗西汀参照臂：验收意见确认物理60页，但是参照臂
        {'FT': 'FT0155', 'file': '09fa9a58a24c', 'page': 60, 'drug': '帕罗西汀', 'trial': '0600B-367-EU参照臂'}
    ]

    verification_results = []

    for check in priority_checks:
        ft = check['FT']
        file_id = check['file']
        page = check['page']
        drug = check['drug']
        trial = check['trial']

        # 读取原文
        page_text = read_ocr_page(file_id, page)

        if not page_text:
            verification_results.append({
                'FT': ft,
                'drug': drug,
                'trial': trial,
                'file': file_id,
                'page': page,
                'status': 'OCR文件不存在',
                'original_text': None
            })
            continue

        # 查找排除标准
        lines = page_text.split('\n')
        exclusion_section = []
        in_exclusion = False

        for i, line in enumerate(lines):
            if 'exclusion' in line.lower() and 'criteria' in line.lower():
                in_exclusion = True
                exclusion_section = lines[max(0, i-2):min(len(lines), i+30)]
                break

        # 查找psychotic关键词
        psychotic_context = []
        for i, line in enumerate(lines):
            if 'psychotic' in line.lower() or 'psychosis' in line.lower() or 'schizophren' in line.lower():
                start = max(0, i-3)
                end = min(len(lines), i+5)
                psychotic_context.append({
                    'line_num': i,
                    'context': '\n'.join(lines[start:end])
                })

        # 查找纳入标准中的"without psychotic features"等
        inclusion_psychotic = []
        for i, line in enumerate(lines):
            if ('inclusion' in line.lower() or 'inclusion' in lines[i-1].lower() if i > 0 else False):
                # 检查后续10行
                for j in range(i, min(len(lines), i+15)):
                    if 'without psychotic' in lines[j].lower() or 'no psychotic' in lines[j].lower():
                        inclusion_psychotic.append({
                            'line_num': j,
                            'text': lines[j]
                        })

        verification_results.append({
            'FT': ft,
            'drug': drug,
            'trial': trial,
            'file': file_id,
            'page': page,
            'status': '已读取原文',
            'exclusion_section': '\n'.join(exclusion_section) if exclusion_section else None,
            'psychotic_context': psychotic_context,
            'inclusion_psychotic_restrictions': inclusion_psychotic,
            'full_page_length': len(page_text)
        })

    # 保存验证结果
    output = {
        'task': 'D18原文核查（优先记录）',
        'priority_checks': len(priority_checks),
        'results': verification_results
    }

    output_file = base_dir / 'r7_identity_fix/d18_verification_priority.json'
    json.dump(output, open(output_file, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # 生成可读报告
    report_lines = []
    report_lines.append('# D18原文核查结果（优先记录）\n\n')

    for result in verification_results:
        report_lines.append(f"## {result['FT']}: {result['drug']} - {result['trial']}\n\n")
        report_lines.append(f"**文件**: {result['file']}, 物理第{result['page']}页\n")
        report_lines.append(f"**状态**: {result['status']}\n\n")

        if result.get('exclusion_section'):
            report_lines.append('### 排除标准章节\n\n```\n')
            report_lines.append(result['exclusion_section'][:800])
            report_lines.append('\n```\n\n')

        if result.get('psychotic_context'):
            report_lines.append('### Psychotic关键词上下文\n\n')
            for ctx in result['psychotic_context'][:3]:
                report_lines.append(f"行{ctx['line_num']}:\n```\n{ctx['context']}\n```\n\n")

        if result.get('inclusion_psychotic_restrictions'):
            report_lines.append('### 纳入标准中的精神病性限制\n\n')
            for inc in result['inclusion_psychotic_restrictions']:
                report_lines.append(f"- 行{inc['line_num']}: {inc['text']}\n")
            report_lines.append('\n')

        report_lines.append('---\n\n')

    report_file = base_dir / 'r7_identity_fix/d18_verification_priority_report.md'
    with open(report_file, 'w', encoding='utf-8') as f:
        f.writelines(report_lines)

    print(f'D18优先记录原文核查完成')
    print(f'  核查记录数: {len(verification_results)}')
    print(f'  成功读取: {sum(1 for r in verification_results if r["status"] == "已读取原文")}')
    print(f'\n输出文件:')
    print(f'  {output_file}')
    print(f'  {report_file}')

    return output

if __name__ == '__main__':
    verify_d18_original_text()
