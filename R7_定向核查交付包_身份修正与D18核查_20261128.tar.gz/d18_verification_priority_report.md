# D18原文核查结果（优先记录）

## FT0035: 去甲文拉法辛 - 3151A1-306

**文件**: 39ea3283f857, 物理第64页
**状态**: 已读取原文

### 排除标准章节

```
(306; Minimum screening and baseline score of 4 on the CG]-S)

Exclusion Criteria:

Treatment with venlafaxine (IR or ER) or desvenlafaxine within 3 months of Study Day 1
History of hypersensitivity to venlafaxine (IR or ER)

Significant risk of suicide at study entry or during the study based on clinical judgment; and/or a score
2 5 on the suicidality item of the MADRS scale.

Current (within 12 months of baseline) DSM-IV-defined: a) psychoactive substance abuse or dependence
(including alcohol); b) a manic episode or a lifetime diagnosis of bipolar; c) obsessive-compulsive, or
psychotic disorder. Subjects whose clinical picture was dominated by an anxiety disorder as defined by
DSM-IV. Personality disorder (such as antisocial, schizotypal disorder, histrionic, borderline, narcissistic)
s
```

### Psychotic关键词上下文

行12:
```
1.

Outpatients with a primary diagnosis of Major Depressive Disorder, single or recurrent episode, without
psychotic features (based on DSM-IV criteria).

Presence of depressive symptoms for at least one month before entry into the study.

Men and (for Study 223 only): postmenopausal or surgically sterile women aged 18 to 65 years, inclusive.
```

行43:
```

Current (within 12 months of baseline) DSM-IV-defined: a) psychoactive substance abuse or dependence
(including alcohol); b) a manic episode or a lifetime diagnosis of bipolar; c) obsessive-compulsive, or
psychotic disorder. Subjects whose clinical picture was dominated by an anxiety disorder as defined by
DSM-IV. Personality disorder (such as antisocial, schizotypal disorder, histrionic, borderline, narcissistic)
severe enough to compromise the investigator’s ability to evaluate the efficacy and safety of the test article.

Current DSM-IV-defined anxiety disorder that was considered by the investigator as being primary,
```

---

## FT0036: 去甲文拉法辛 - 3151A1-308

**文件**: 39ea3283f857, 物理第64页
**状态**: 已读取原文

### 排除标准章节

```
(306; Minimum screening and baseline score of 4 on the CG]-S)

Exclusion Criteria:

Treatment with venlafaxine (IR or ER) or desvenlafaxine within 3 months of Study Day 1
History of hypersensitivity to venlafaxine (IR or ER)

Significant risk of suicide at study entry or during the study based on clinical judgment; and/or a score
2 5 on the suicidality item of the MADRS scale.

Current (within 12 months of baseline) DSM-IV-defined: a) psychoactive substance abuse or dependence
(including alcohol); b) a manic episode or a lifetime diagnosis of bipolar; c) obsessive-compulsive, or
psychotic disorder. Subjects whose clinical picture was dominated by an anxiety disorder as defined by
DSM-IV. Personality disorder (such as antisocial, schizotypal disorder, histrionic, borderline, narcissistic)
s
```

### Psychotic关键词上下文

行12:
```
1.

Outpatients with a primary diagnosis of Major Depressive Disorder, single or recurrent episode, without
psychotic features (based on DSM-IV criteria).

Presence of depressive symptoms for at least one month before entry into the study.

Men and (for Study 223 only): postmenopausal or surgically sterile women aged 18 to 65 years, inclusive.
```

行43:
```

Current (within 12 months of baseline) DSM-IV-defined: a) psychoactive substance abuse or dependence
(including alcohol); b) a manic episode or a lifetime diagnosis of bipolar; c) obsessive-compulsive, or
psychotic disorder. Subjects whose clinical picture was dominated by an anxiety disorder as defined by
DSM-IV. Personality disorder (such as antisocial, schizotypal disorder, histrionic, borderline, narcissistic)
severe enough to compromise the investigator’s ability to evaluate the efficacy and safety of the test article.

Current DSM-IV-defined anxiety disorder that was considered by the investigator as being primary,
```

---

## FT0008: 米氮平 - 003-002

**文件**: 9f5adbd403bb, 物理第292页
**状态**: OCR文件不存在

---

## FT0155: 帕罗西汀 - 0600B-367-EU参照臂

**文件**: 09fa9a58a24c, 物理第60页
**状态**: 已读取原文

### 排除标准章节

```
visits.

Relevant exclusion criteria included the following:

© history or presence of any psychotic disorder not related to
depression, bipolar @isorder, or organic mental disorder.

e use of any investigational drug, antipsychotic drug, or ECT
within 30 days; fluoxetine within 21 days; MAOI, paroxetine, or
sertraline within 14 days; or any other antidepressant,
anxiolytic, sedative-hypnotic, or other psychotropic agent within
7 days (except chloral hydrate) .

© use of any drug with psychotropic effects within 7 days of the
study unless a stable dose had been maintained for the past
month.

© drug or alcohol dependence within 1 year.

Desian

This was a randomized, double-blind, placebo- and active-
controlled, double-dumny, parallel group, fixed dose study
conducted at 35 sites in Europ
```

### Psychotic关键词上下文

行27:
```

Relevant exclusion criteria included the following:

© history or presence of any psychotic disorder not related to
depression, bipolar @isorder, or organic mental disorder.

e use of any investigational drug, antipsychotic drug, or ECT
within 30 days; fluoxetine within 21 days; MAOI, paroxetine, or
```

行30:
```
© history or presence of any psychotic disorder not related to
depression, bipolar @isorder, or organic mental disorder.

e use of any investigational drug, antipsychotic drug, or ECT
within 30 days; fluoxetine within 21 days; MAOI, paroxetine, or
sertraline within 14 days; or any other antidepressant,
anxiolytic, sedative-hypnotic, or other psychotropic agent within
7 days (except chloral hydrate) .
```

---

