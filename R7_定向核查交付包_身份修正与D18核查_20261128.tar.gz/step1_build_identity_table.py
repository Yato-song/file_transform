#!/usr/bin/env python3
"""第一关：建立逐记录身份对照表"""
import json
import hashlib
from pathlib import Path
from collections import defaultdict

def sha256_file(path):
    if not Path(path).exists():
        return None
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

def build_identity_table():
    base_dir = Path('/Users/dxm/work/jingya/FDAcheck')

    # 读取R3基线数据（未被R6误改的原始状态）
    dims_r3 = json.load(open(base_dir / 'r3_full_revision/phase3_dimensions_3674_CORRECTED.json', encoding='utf-8'))
    trials_r2 = json.load(open(base_dir / 'r3_full_revision/phase2_trial_extractions_235.json', encoding='utf-8'))

    # 记录输入SHA256
    input_manifest = {
        'phase3_dimensions_3674_CORRECTED.json': sha256_file(base_dir / 'r3_full_revision/phase3_dimensions_3674_CORRECTED.json'),
        'phase2_trial_extractions_235.json': sha256_file(base_dir / 'r3_full_revision/phase2_trial_extractions_235.json'),
        'base_version': 'R3 (2026-11-27)'
    }

    # 构建试验索引
    trial_index = {}
    for t in trials_r2:
        ft = t.get('候选记录ID', '')
        trial_index[ft] = t

    # 构建身份对照表
    identity_records = []

    # 按FT分组维度记录
    ft_groups = defaultdict(list)
    for rec in dims_r3:
        ft = rec.get('模型记录ID', '')
        ft_groups[ft].append(rec)

    # 逐FT建立身份
    for ft, dim_recs in sorted(ft_groups.items()):
        if not dim_recs:
            continue

        # 从第一条维度记录获取共同信息
        first_rec = dim_recs[0]
        drug = first_rec.get('药物', '')
        trial_name = first_rec.get('试验名称候选', '')

        # 从trial提取获取详细信息
        trial_info = trial_index.get(ft, {})

        # 判断是否自身申报还是参照臂
        is_reference_arm = False
        申报药物 = trial_info.get('药物', '')
        if 申报药物 and 申报药物 != drug:
            is_reference_arm = True

        # 识别年龄人群
        age_group = '成人'
        if '老年' in trial_name or '老年' in trial_info.get('试验名称候选', ''):
            age_group = '老年'
        elif '青少年' in trial_name or '儿童' in trial_name:
            age_group = '儿少'

        # 识别治疗类型（单药/增效）
        treatment_type = '单药'
        if '加药' in drug or '增效' in trial_info.get('工作表', ''):
            treatment_type = '增效'

        # 方案ID（初步，需后续细化）
        regimen_id = f"{drug}|{treatment_type}"

        # 判断主分析纳入
        main_analysis_eligible = True
        exclusion_reason = []

        if is_reference_arm:
            main_analysis_eligible = False
            exclusion_reason.append('参照臂（非自身申报）')

        if age_group == '老年':
            main_analysis_eligible = False
            exclusion_reason.append('老年试验（主分析限成人）')
        elif age_group == '儿少':
            main_analysis_eligible = False
            exclusion_reason.append('儿少试验（主分析限成人）')

        # 构建身份记录
        identity = {
            'FT': ft,
            '标准药物': drug,
            '申报药物': 申报药物,
            '试验名称': trial_name,
            '父试验ID': trial_info.get('父试验编号', ''),
            '治疗臂ID': '',  # 待补充
            '方案ID': regimen_id,
            '年龄人群': age_group,
            '治疗类型': treatment_type,
            '是否参照臂': is_reference_arm,
            'FDA判定': trial_info.get('FDA判定', ''),
            '来源文件': first_rec.get('证据文件及SHA', ''),
            '工作表': trial_info.get('工作表', ''),
            '主分析纳入': main_analysis_eligible,
            '排除理由': '; '.join(exclusion_reason) if exclusion_reason else '',
            '维度记录数': len(dim_recs)
        }

        identity_records.append(identity)

    # 检查问题
    issues = {
        '重复ID': [],
        '药物不一致': [],
        '跨药绑定': [],
        '缺父试验ID': [],
        '参照臂误入主分析': [],
        '老年试验误入主分析': []
    }

    # 检查重复ID
    ft_counts = defaultdict(int)
    for rec in identity_records:
        ft_counts[rec['FT']] += 1
    for ft, count in ft_counts.items():
        if count > 1:
            issues['重复ID'].append(ft)

    # 检查药物一致性
    for rec in identity_records:
        if rec['申报药物'] and rec['申报药物'] != rec['标准药物']:
            if not rec['是否参照臂']:
                issues['药物不一致'].append({
                    'FT': rec['FT'],
                    '标准药物': rec['标准药物'],
                    '申报药物': rec['申报药物']
                })

    # 检查跨药绑定（R6问题案例）
    r6_crossdrug_cases = {
        'FT0035': {'错误绑定药物': '文拉法辛', '正确药物': '去甲文拉法辛'},
        'FT0036': {'错误绑定药物': '文拉法辛', '正确药物': '去甲文拉法辛'},
        'FT0038': {'错误绑定药物': '文拉法辛', '正确药物': '去甲文拉法辛'},
        'FT0039': {'错误绑定药物': '文拉法辛', '正确药物': '去甲文拉法辛'},
        'FT0040': {'错误绑定药物': '文拉法辛', '正确药物': '去甲文拉法辛'},
        'FT0041': {'错误绑定药物': '文拉法辛', '正确药物': '去甲文拉法辛'},
        'FT0042': {'错误绑定药物': '文拉法辛', '正确药物': '去甲文拉法辛'},
        'FT0044': {'错误绑定药物': '文拉法辛', '正确药物': '曲唑酮'},
        'FT0045': {'错误绑定药物': '文拉法辛', '正确药物': '曲唑酮'},
        'FT0046': {'错误绑定药物': '文拉法辛', '正确药物': '西酞普兰'}
    }
    issues['跨药绑定'] = r6_crossdrug_cases

    # 检查缺父试验ID
    for rec in identity_records:
        if not rec['父试验ID']:
            issues['缺父试验ID'].append(rec['FT'])

    # 检查参照臂误入主分析
    for rec in identity_records:
        if rec['是否参照臂'] and rec['主分析纳入']:
            issues['参照臂误入主分析'].append(rec['FT'])

    # 检查老年试验误入主分析
    for rec in identity_records:
        if rec['年龄人群'] == '老年' and rec['主分析纳入']:
            issues['老年试验误入主分析'].append(rec['FT'])

    # 保存身份对照表
    output = {
        'task': '逐记录身份对照表',
        'input_manifest': input_manifest,
        'total_ft_records': len(identity_records),
        'main_analysis_eligible': sum(1 for r in identity_records if r['主分析纳入']),
        'issues': issues,
        'records': identity_records
    }

    output_file = Path('/Users/dxm/work/jingya/FDAcheck/r7_identity_fix/identity_table.json')
    json.dump(output, open(output_file, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # 生成可读报告
    report_lines = []
    report_lines.append('# 逐记录身份对照表\n\n')
    report_lines.append(f'**基线版本**: {input_manifest["base_version"]}\n')
    report_lines.append(f'**总FT记录数**: {len(identity_records)}\n')
    report_lines.append(f'**主分析合格**: {sum(1 for r in identity_records if r["主分析纳入"])}\n')
    report_lines.append(f'**排除记录**: {sum(1 for r in identity_records if not r["主分析纳入"])}\n\n')

    report_lines.append('## 检查发现的问题\n\n')
    for issue_type, issue_data in issues.items():
        if isinstance(issue_data, list) and issue_data:
            report_lines.append(f'### {issue_type} ({len(issue_data)}项)\n\n')
            if isinstance(issue_data[0], dict):
                for item in issue_data[:10]:
                    report_lines.append(f'- {item}\n')
            else:
                report_lines.append(f'{", ".join(str(x) for x in issue_data[:20])}\n')
            report_lines.append('\n')
        elif isinstance(issue_data, dict) and issue_data:
            report_lines.append(f'### {issue_type}\n\n')
            for ft, info in list(issue_data.items())[:10]:
                report_lines.append(f'- **{ft}**: {info}\n')
            report_lines.append('\n')

    report_lines.append('## 六个目标药物的FT记录\n\n')
    target_drugs = ['舍曲林', '米氮平', '喹硫平', '氟西汀', '文拉法辛', '帕罗西汀']
    for drug_name in target_drugs:
        drug_recs = [r for r in identity_records if drug_name in r['标准药物'] and not any(x in r['标准药物'] for x in ['去甲', '艾司'])]
        main_eligible = [r for r in drug_recs if r['主分析纳入']]
        report_lines.append(f'### {drug_name}\n')
        report_lines.append(f'- 总FT记录: {len(drug_recs)}\n')
        report_lines.append(f'- 主分析合格: {len(main_eligible)}\n')
        report_lines.append(f'- 排除: {len(drug_recs) - len(main_eligible)}\n\n')

    report_file = Path('/Users/dxm/work/jingya/FDAcheck/r7_identity_fix/identity_table_report.md')
    with open(report_file, 'w', encoding='utf-8') as f:
        f.writelines(report_lines)

    print(f'身份对照表已生成')
    print(f'  总FT记录: {len(identity_records)}')
    print(f'  主分析合格: {sum(1 for r in identity_records if r["主分析纳入"])}')
    print(f'  缺父试验ID: {len(issues["缺父试验ID"])}')
    print(f'  R6跨药绑定案例: {len(issues["跨药绑定"])}')
    print(f'\n输出文件:')
    print(f'  {output_file}')
    print(f'  {report_file}')

    return output

if __name__ == '__main__':
    build_identity_table()
