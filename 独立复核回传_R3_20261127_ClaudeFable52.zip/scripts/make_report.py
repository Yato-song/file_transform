#!/usr/bin/env python3
"""生成 R3 复核报告、未完成清单、SHA256 清单"""
import json, hashlib, os, glob, collections
from datetime import datetime

def load(p):
    return json.load(open(p, encoding='utf-8'))

def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()

def main():
    synced = load('r3_work/all_guideline_statements_synced.json')
    trials = load('phase2_trial_extractions_235.json')
    dims = load('phase3_dimensions_3674_CORRECTED.json')
    main_letters = load('phase5_fda_letters_19_CORRECTED.json')['主设定']['matrix']
    ind = load('phase1_418_INDEPENDENT.json')
    cmp418 = load('phase7_comparison_418_vs_v4.json')
    gap = load('phase6_gap_mapping.json')
    who = load('phase1_WHO_fixed.json')
    log = load('correction_log_fda.json')

    # 未完成清单
    no_excerpt = [s['stmt_id'] for s in synced if not s.get('excerpt')]
    no_evidence = [t['候选记录ID'] for t in trials if not t.get('证据块')]
    na_judg = [t['候选记录ID'] for t in trials
               if str(t.get('FDA判定')) in ('not_assessable', 'uncertain', '')]
    scen_partial = {
        'S2': '缺逐试验 1b 来源标志，未能与主设定区分',
        'S3': '缺"仅FDA文件"来源过滤标志（已按标签名粗滤，未逐试验核来源层级）',
        'S5': '缺他机构判阳性标志的完整清单（部分EMA标志可用）',
        'S7': '缺安慰剂对照标志（hdao2）',
        'S9': 'Turner判定缺未发表试验清单',
        'S15': '缺"仅汇总层入组"标志',
        'S17': '已按修正后的?处理，但未与主设定形成独立差异（等同主设定）',
        'S16': '适应障碍按部分排除未逐试验实现',
        'S11/S12': '轻度HAMD阈值需逐试验严重度原文，未完整实现',
    }
    with open('未完成与未决清单.txt', 'w', encoding='utf-8') as f:
        f.write('未完成与未决清单 R3\n生成时间: %s\n\n' % datetime.now().strftime('%Y-%m-%d %H:%M'))
        f.write('一、指南陈述无摘录（未定位，共%d条，需补检索/语义核对）\n' % len(no_excerpt))
        f.write('  ' + ', '.join(no_excerpt) + '\n\n')
        f.write('二、FDA候选记录无证据块（共%d条）\n' % len(no_evidence))
        f.write('  ' + ', '.join(no_evidence) + '\n\n')
        f.write('三、FDA判定不可评估/不确定（共%d条）\n' % len(na_judg))
        f.write('  ' + ', '.join(na_judg) + '\n\n')
        f.write('四、19套设定中未完整差异化（逐项原因）\n')
        for k, v in scen_partial.items():
            f.write('  %s: %s\n' % (k, v))
        f.write('\n五、结构性限制\n')
        f.write('  F033/F035 为DOCX附件，按表/段定位，不适用PDF页码\n')
        f.write('  F038 中国2025为扫描件（452页），需OCR/页图核对\n')
        f.write('  CANMAT系列(F003/F004/F006/F007)证据等级以圆形符号呈现，文本抽取不可读，需页图核对\n')
        f.write('  1990年代扫描件（安非他酮SR、文拉法辛速释、部分氟西汀）OCR存在识别误差\n')

    # 报告
    lp = collections.Counter()
    for rowk, row in main_letters.items():
        for d, v in row.items():
            if d in ('D16a', 'D16b', 'D18'): continue
            lp[v[0] if v else '—'] += 1
    dist = ind['state_distribution']
    r = []
    r.append('# R3 全量复核报告（修复与继续）\n')
    r.append('生成：%s；执行者：Claude Fable 5.2；目录：r3_full_revision\n' % datetime.now().strftime('%Y-%m-%d %H:%M'))
    r.append('## 一、撤回的声明（上一版回传不成立）\n')
    r.append('- 撤回"418格已完成实质判定"：上版按药名整行传播（308=14×22、286=13×22），已废弃。\n')
    r.append('- 撤回"历史93格80格验证通过"：上版未读v4、未做版本比较；已改为逐格对照并区分相同/不同。\n')
    r.append('- 撤回"WHO已有效提取134个结局"：上版134项全部 NOT_AVAILABLE 且重复计数；已重提取。\n')
    r.append('## 二、已核实\n')
    r.append('- WHO F026：%d条陈述，%d个可计数值结局，%d个原文明确Not available；经 pypdf、PyMuPDF、直接文本检索三方核对（物理页19/21/23/27/29/31）。示例：S0111 艾司西酞普兰 SMD −0.29（−0.35至−0.24），21研究，6432人，LOW；S0129 舍曲林 SMD −0.27（−0.34至−0.21）；S0133 自杀结局 Not available；S0143 产后叙述保留第48页。\n' % (
        who['counts']['total_statement_records'], who['counts']['available_numeric_outcomes'], who['counts']['not_available_outcomes']))
    r.append('- FDA文件索引：643条，SHA256逐一核对通过。\n')
    r.append('- FDA试验提取：235条候选记录，129条附证据块原文；判定分布含阳性78、阴性49+33、supportive 6等。\n')
    r.append('## 三、机械纠正（明确标注：非语义审核完成）\n')
    r.append('- 维度编码纠正 %d 项：N 810→613（无完整清单依据改?）、P 293→356、R 149→277（D16b"允许65岁"记仅允许R，聚合按N）、X 645→626、? 1777→1802。\n' % log['total_changes'])
    r.append('- 三类规则：①N需完整清单或允许语句；②D18精神病性按排除语境判X/P；③D01未限时态排除判X、history of判P。\n')
    r.append('## 四、指南418格（关键词初筛，待语义复核）\n')
    r.append('- 状态分布：%s\n' % json.dumps(dist, ensure_ascii=False))
    r.append('- 与v4事后对照：相同 %d、不同 %d；历史93格：相同 %d、不同 %d（相同≠原文验证通过，不同≠v4错误）。\n' % (
        cmp418['same'], cmp418['different'], cmp418['hist93_same'], cmp418['hist93_different']))
    r.append('- 方法限制：映射基于原文摘录关键词，未做逐条语义判读；192格因存在未提取陈述记"未确定"，不记"均未定位"。\n')
    r.append('## 五、FDA字母层（基于机械纠正编码聚合）\n')
    r.append('- 主设定成人核心19维分布：%s（行数 %d，含无阳性试验行的"—"）。\n' % (dict(lp), len(main_letters)))
    r.append('- v43基线（仅对照，不设为目标）：320可评分格，A27/B72/C6/B−106/D82/E27，缺口88。本次分母口径不同（31行×19维，含"—"），不可直接比较总数。\n')
    r.append('## 六、缺口与指南对应（C/D格）\n')
    r.append('- C/D共 %d 格；其中 FDA未测试但指南有研究与建议 51 格、指南未确定 30 格、无对应行列 9 格、C且指南有依据 2 格。\n' % gap['counts']['total'])
    r.append('## 七、proposal 修改建议（不覆盖原文）\n')
    r.append('1. 覆盖图/正文引用 WHO DEP1 数值处，改用本报告二节的修正值；删除"134结局"表述。\n')
    r.append('2. 指南侧证据表：对192个"未确定"格与197条无摘录陈述优先补语义核对，标注依据来源。\n')
    r.append('3. FDA缺口表述按三类分开：①指南有依据但FDA未测试（51格）；②双方均无充分证据（30格）；③无对应行列（9格，需补方案行或说明）。\n')
    r.append('4. 情景分析仅报告已实现的13套（主设定及可算差异套），其余6套如实标注"未实现差异化"及原因。\n')
    r.append('5. 历史93格使用"相同/不同"表述，不使用"验证通过"。\n')
    r.append('## 八、可复核性\n')
    r.append('- 脚本：scripts/fda_correct_and_aggregate.py、scripts/guideline_independent_mapping.py、scripts/compare_and_gap.py（仅标准库）。\n')
    r.append('- 输入与输出均为JSON，附SHA256清单。原始R1材料、原回传、正式表与proposal均未改动。\n')
    open('复核报告_R3.md', 'w', encoding='utf-8').write(''.join(r))

    # SHA256 清单
    files = sorted(set(glob.glob('*.json') + glob.glob('*.md') + glob.glob('*.txt') + glob.glob('scripts/*.py')))
    man = {f: sha(f) for f in files if os.path.isfile(f)}
    json.dump(man, open('SHA256_MANIFEST.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('报告与清单已生成；文件数:', len(man))
    print('未完成: 无摘录陈述 %d, FDA无证据 %d, 不可评估 %d' % (len(no_excerpt), len(no_evidence), len(na_judg)))

if __name__ == '__main__':
    main()
