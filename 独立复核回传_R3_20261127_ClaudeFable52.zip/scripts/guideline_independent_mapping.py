#!/usr/bin/env python3
"""指南独立维度映射 + 418格重建（不读取v4映射）
方法：对626条陈述的原文摘录做关键词初筛得到维度集合（独立于v4），
再按(方案,维度)双条件取陈述，分别判定研究讨论/用药建议。
所有判定标注为"机械关键词初筛-待语义复核"，不声称已完成语义核查。
与v4仅作事后对照，且区分"相同"与"原文验证通过"。
"""
import json, re, collections

DIMS = {
 'D01': r'(alcohol|substance use|substance abuse|drug abuse|illicit drug|酒精|物质使用|物质滥用)',
 'D02': r'(intellectual disabilit|learning disabilit|mental retardation|智力障碍|智力残疾)',
 'D03': r'(obsessive[- ]compulsive|\bOCD\b|强迫症)',
 'D04a': r'(PTSD|post-?traumatic stress|创伤后应激)',
 'D04b': r'(adjustment disorder|适应障碍)',
 'D05': r'(eating disorder|anorexia|bulimia|进食障碍|厌食|贪食)',
 'D06': r'(developmental disorder|autism|autistic|ADHD|attention[- ]deficit|发育障碍|孤独症|自闭)',
 'D07': r'(personality disorder|borderline personality|人格障碍|边缘型人格)',
 'D08a': r'(pregnan|antenatal|孕期|妊娠|怀孕)',
 'D08b': r'(postpartum|post-?natal|breast-?feed|lactation|产后|哺乳)',
 'D09': r'(self-?harm|suicide attempt|suicidal behavio|自杀未遂|自伤|自杀行为)',
 'D10': r'(chronic physical|medical comorbid|cancer|diabetes|cardiovascular|coronary|stroke|epilep|Parkinson|dialysis|HIV|躯体疾病|癌症|糖尿病|心血管|癫痫|帕金森)',
 'D11': r'(anxiety disorder|generalized anxiety|\bGAD\b|panic disorder|social anxiety|焦虑障碍|广泛性焦虑|惊恐)',
 'D12': r'(inpatient|hospitali[sz]ed|hospital admission|住院)',
 'D13a': r'(combination of (two )?antidepressants|antidepressant combination|two antidepressants|合用.{0,6}抗抑郁|两种抗抑郁)',
 'D13b': r'(antipsychotic|aripiprazole|lithium|mood stabilizer|mood stabiliser|quetiapine|olanzapine|抗精神病|锂盐|心境稳定)',
 'D14': r'(treatment[- ]resistant|refractory|failed (to|at least)|non-?response|inadequate response|难治|治疗抵抗|疗效不佳)',
 'D15': r'(mild depress|subthreshold|轻度抑郁|轻度)',
 'D16a': r'(adolescen|children|child|youth|pediatric|paediatric|青少年|儿童)',
 'D16b': r'(older adult|elderly|geriatric|late[- ]life|aged (6[5-9]|[7-9]\d)|老年|高龄)',
 'D17': r'(monotherapy|single agent|as a single|单药)',
 'D18': r'(psychotic|delusion|hallucination|精神病性|妄想|幻觉)',
}
PLANS = ['舍曲林','米氮平','喹硫平单药','喹硫平加药','氟西汀','艾司西酞普兰','去甲文拉法辛',
         '曲唑酮','西酞普兰','黛力新','文拉法辛','阿立哌唑','帕罗西汀','阿米替林','奥氮平',
         '伏硫西汀','安非他酮','度洛西汀','米安色林']
BASE = {'舍曲林':'舍曲林','米氮平':'米氮平','氟西汀':'氟西汀','艾司西酞普兰':'艾司西酞普兰',
        '去甲文拉法辛':'去甲文拉法辛','曲唑酮':'曲唑酮','西酞普兰':'西酞普兰','黛力新':'黛力新',
        '文拉法辛':'文拉法辛','阿立哌唑':'阿立哌唑','帕罗西汀':'帕罗西汀','阿米替林':'阿米替林',
        '奥氮平':'奥氮平','伏硫西汀':'伏硫西汀','安非他酮':'安非他酮','度洛西汀':'度洛西汀',
        '米安色林':'米安色林','喹硫平':'喹硫平'}
ADULT_CORE = [d for d in DIMS if d not in ('D16a','D16b','D18')]

def plans_of(drug):
    drug = drug or ''
    out = []
    if '喹硫平' in drug:
        out.append('喹硫平加药' if re.search(r'(加药|增效|合用|联合|augment)', drug) else '喹硫平单药')
    for b, p in BASE.items():
        if b == '喹硫平': continue
        if b in drug:
            out.append(p)
    seen = []
    for p in out:
        if p not in seen: seen.append(p)
    return seen

RESEARCH_PAT = re.compile(r'(study|studies|trial|RCT|randomi[sz]ed|meta-?analy|systematic review|evidence|研究|试验|荟萃|系统评价|meta分析)', re.I)
ADVICE_PAT = re.compile(r'(recommend|should|consider|first[- ]line|second[- ]line|suggest|indicated|推荐|建议|首选|一线|二线|应考虑)', re.I)

def main():
    stmts = json.load(open('r3_work/all_guideline_statements_synced.json', encoding='utf-8'))
    by_id = {s['stmt_id']: s for s in stmts}

    indep = {}
    for s in stmts:
        ex = s.get('excerpt') or ''
        dims = [d for d, pat in DIMS.items() if ex and re.search(pat, ex, re.I)]
        indep[s['stmt_id']] = {
            'stmt_id': s['stmt_id'], 'source': s.get('source'), 'drug': s.get('drug'),
            'status': s.get('status'), 'pages': s.get('pages'),
            'dims': dims,
            'mapping_basis': '关键词初筛（独立于v4）',
            'has_excerpt': bool(ex),
            'research': bool(ex and RESEARCH_PAT.search(ex)),
            'advice': bool(ex and ADVICE_PAT.search(ex)),
            'excerpt_head': ex[:160]
        }

    cells = {}
    for plan in PLANS:
        for dim in DIMS:
            if plan == '喹硫平加药' and dim == 'D17':
                cells[f'{plan}|{dim}'] = dict(plan=plan, dim=dim, structural=False,
                    reason='加药方案不含单药使用维度', research=False, advice=False, support=[], state='结构不适用')
                continue
            if plan == '喹硫平单药' and dim == 'D13a':
                cells[f'{plan}|{dim}'] = dict(plan=plan, dim=dim, structural=False,
                    reason='索引为抗精神病单药，与抗抑郁药合用属加药行', research=False, advice=False, support=[], state='结构不适用')
                continue
            supp = []
            pending = 0
            for s in stmts:
                if plan not in plans_of(s.get('drug')):
                    continue
                if not s.get('excerpt'):
                    pending += 1; continue
                info = indep[s['stmt_id']]
                if dim in info['dims']:
                    supp.append({'stmt_id': s['stmt_id'], 'source': s.get('source'),
                                 'research': info['research'], 'advice': info['advice'],
                                 'drug': s.get('drug')})
            r = any(x['research'] for x in supp)
            a = any(x['advice'] for x in supp)
            state = ('研究' if r else '') + ('+建议' if a else '') or ('未确定（存在未提取陈述）' if pending else '两项均未定位')
            cells[f'{plan}|{dim}'] = dict(plan=plan, dim=dim, structural=True, research=r, advice=a,
                                          support=supp, pending_statements=pending, state=state,
                                          mapping_basis='关键词初筛-待语义复核')

    st = collections.Counter(v['state'] for v in cells.values())
    with open('phase1_mapping_INDEPENDENT.json', 'w', encoding='utf-8') as f:
        json.dump({'method': '关键词初筛，独立于v4；待语义复核', 'statements': indep}, f, ensure_ascii=False)
    with open('phase1_418_INDEPENDENT.json', 'w', encoding='utf-8') as f:
        json.dump({'cells': cells, 'state_distribution': st}, f, ensure_ascii=False, indent=1)

    # 与 v4 事后对照（不作为真值）
    try:
        v4 = json.load(open('r3_work/v4_418_grid.json', encoding='utf-8'))
    except Exception:
        v4 = {}
    same = diff = und = 0
    hist_same = hist_diff = hist_und = 0
    diffs = []
    if isinstance(v4, dict) and v4:
        # 尝试解析结构
        vcells = v4.get('cells') if 'cells' in v4 else v4
        keys = list(vcells)[:3]
        print('v4 keys sample:', keys)
        for k, v in cells.items():
            # 匹配 v4 中对应 (drug,dim)
            cand = None
            for kk, vv in (vcells.items() if isinstance(vcells, dict) else []):
                if isinstance(vv, dict) and vv.get('drug') == v['plan'] and vv.get('dimension') == v['dim']:
                    cand = vv; break
            if cand is None:
                und += 1; continue
            v4r = bool(cand.get('has_research')); v4a = bool(cand.get('has_recommendation'))
            if v['state'] == '结构不适用':
                same += 1; continue
            if (v['research'], v['advice']) == (v4r, v4a):
                same += 1
                if cand.get('historical_93'): hist_same += 1
            elif (v['research'], v['advice']) != (v4r, v4a):
                diff += 1
                if cand.get('historical_93'): hist_diff += 1
                diffs.append({'cell': k, 'independent': [v['research'], v['advice']],
                              'v4': [v4r, v4a], 'hist93': bool(cand.get('historical_93')),
                              'state': v['state'], 'support': [x['stmt_id'] for x in v['support']][:8]})
    with open('comparison_418_INDEPENDENT_vs_v4.json', 'w', encoding='utf-8') as f:
        json.dump({'note': '相同仅指与v4判断一致，不等于原文验证通过',
                   'same': same, 'different': diff, 'undetermined': und,
                   'hist93_same': hist_same, 'hist93_different': hist_diff,
                   'state_distribution': st, 'differences_sample': diffs[:120]}, f, ensure_ascii=False, indent=1)
    print('418 state dist:', dict(st))
    print('vs v4: same', same, 'diff', diff, 'und', und, '| hist93 same', hist_same, 'diff', hist_diff)

if __name__ == '__main__':
    main()
