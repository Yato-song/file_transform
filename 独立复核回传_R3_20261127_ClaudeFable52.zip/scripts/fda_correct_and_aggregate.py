#!/usr/bin/env python3
"""FDA维度编码机械纠正 + 字母聚合重算
纠正三类已确认错误（可规则化检出的部分）：
 1) N 无完整清单依据 -> ?（或按允许语句证据保留）
 2) D18 精神病性：排除精神分裂症/分裂情感障碍却被编 N
 3) D01 物质使用：未限时态排除统一为 X（'history of/past' 为 P）
输出：CORRECTED 编码、纠正日志、字母层（主设定+19套可算设定）、v43 对照统计
所有改动均记录改前/改后与证据，标注“机械纠正-待语义复核”；不声称语义核查完成。
"""
import json, re, collections

DIM_KEYS = ['D01','D02','D03','D04a','D04b','D05','D06','D07','D08a','D08b','D09','D10',
            'D11','D12','D13a','D13b','D14','D15','D16a','D16b','D17','D18']
ADULT_CORE = [d for d in DIM_KEYS if d not in ('D16a','D16b','D18')]

ALLOW_PAT = re.compile(r'(allowed|permitted|was not excluded|not an exclusion|允许|可入组|未排除|eligible)', re.I)
EXCL_CTX = re.compile(r'(exclud|not allowed|not permitted|排除|不允许|不得)', re.I)
HIST_PAT = re.compile(r'(history of|past |prior |既往|曾经)', re.I)

def load(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)

def d16b_fix(row):
    """D16b：年龄上限含65=允许(仅允许R，聚合按N)；上限<65=X"""
    ev = (row.get('排除范围与时态') or '') + ' ' + (row.get('原文短摘') or '')
    m = re.findall(r'(\d{2})\s*[-–~至到]\s*(\d{2})', ev)
    up = None
    for a, b in m:
        up = max(int(a), int(b)) if up is None else max(up, int(b))
    for mm in re.finditer(r'(?:≥|>=|大于等于|at least)\s*(6[5-9]|7\d|8\d)', ev):
        up = int(mm.group(1)) if up is None else max(up, int(mm.group(1)))
    if up is not None:
        if up >= 65:
            return ('R', '仅允许', '年龄上限%d，65岁允许入组（仅允许，不证明实际入组，聚合按N）' % up)
        return ('X', '', '年龄上限%d<65，明确不含老年' % up)
    return None

def correct_row(row):
    code = row.get('独立代码_R_X_P_N_问号')
    dim = row.get('维度')
    comp = row.get('完整性与直接性') or ''
    ev = ' '.join(filter(None, [row.get('排除范围与时态'), row.get('原文短摘')]))
    new, basis, why = code, row.get('R依据类型') or '', ''

    if dim == 'D16b':
        r = d16b_fix(row)
        if r:
            new, basis, why = r

    elif dim == 'D18':
        if re.search(r'(schizophren|schizoaffective|psychotic|精神分裂|分裂情感|精神病性)', ev, re.I):
            if EXCL_CTX.search(ev):
                new = 'P' if HIST_PAT.search(ev) else 'X'
                why = '证据明确提及精神分裂/分裂情感/精神病性且为排除语境'
            elif ALLOW_PAT.search(ev):
                new = 'N'; why = '证据明确允许精神病性患者'
            else:
                new = 'P'; why = '提及但语境不清，保守记P'
        elif code == 'N' and comp != '完整清单推定':
            new = '?'; why = '未提及精神病性且无完整清单，N改?'

    elif dim == 'D01':
        if re.search(r'(alcohol|substance|drug abuse|酒精|物质)', ev, re.I) and EXCL_CTX.search(ev):
            new = 'P' if HIST_PAT.search(ev) else 'X'
            why = '物质/酒精排除：带既往限定=P，未限时态=X'

    if code == 'N' and new == code and comp != '完整清单推定':
        if ALLOW_PAT.search(ev):
            why = '有允许语句支撑，保留N'
        else:
            new = '?'; why = '无完整排除清单且无允许语句，N改?'

    if new != code:
        row['独立代码_R_X_P_N_问号'] = new
        if new == 'R':
            row['R依据类型'] = basis or '仅允许'
        row['未决原因'] = (row.get('未决原因') or '') + ('；' if row.get('未决原因') else '') + '机械纠正：' + why
        row['核查状态'] = '机械纠正-待语义复核'
        return code, new, why
    return None

judgment_class = {}
def class_of(j):
    j = (j or '').strip()
    if j in ('positive', '阳性/支持性', 'supportive', 'comparator_positive'):
        return 'pos'
    if j in ('negative', '阴性/失败', 'failed', 'no_superiority_active_control'):
        return 'neg'
    return 'unassessable'

def agg_letters(trials, codes_by_trial, scenario_key):
    """trials: list of dict(药物,方案候选,试验名称候选,FDA判定,工作表); codes_by_trial: {trialkey:{dim:code}}"""
    out = {}
    for (drug, plan), tl in trials.items():
        row = {}
        for dim in DIM_KEYS:
            pos, neg = [], []
            for t in tl:
                cls = class_of(t['FDA判定'])
                c = codes_by_trial.get(t['_key'], {}).get(dim, '?')
                if cls == 'pos': pos.append(c)
                elif cls == 'neg': neg.append(c)
            if not pos:
                row[dim] = '—'; continue
            # S18 宽松：X->P
            if scenario_key == 'S18':
                pos = ['P' if c == 'X' else c for c in pos]
            if scenario_key == 'S19':
                pass  # 已在编码层按 history 处理
            R_eff = [c for c in pos if c == 'R']
            if any(c == 'R' for c in pos):
                row[dim] = 'A'
            elif 'N' in pos:
                row[dim] = 'B'
            elif 'P' in pos:
                row[dim] = 'B−'
            elif all(c == '?' for c in pos):
                row[dim] = 'E'
            else:
                # 阳性试验均排除该维度
                if any(c == 'R' for c in neg):
                    row[dim] = 'C'
                    if scenario_key == 'S8' and any(c == '?' for c in neg):
                        row[dim] = 'E'
                else:
                    row[dim] = 'D' + ('*' if any(c == '?' for c in pos + neg) else '')
            if scenario_key == 'S14' and row[dim] in ('A', 'B', 'B−'):
                support = sum(1 for c in pos if c in ('R', 'N', 'P'))
                if support < 2:
                    row[dim] = 'E'
        out[f'{drug}|{plan}'] = row
    return out

def main():
    dims = load('phase3_dimensions_3674.json')
    trials = load('phase2_trial_extractions_235.json')

    log = []
    dist_old = collections.Counter(r['独立代码_R_X_P_N_问号'] for r in dims)
    for r in dims:
        ch = correct_row(r)
        if ch:
            o, n, why = ch
            log.append({'FT': r['模型记录ID'], '试验': r['试验名称候选'], '药物': r['药物'],
                        '维度': r['维度'], 'old': o, 'new': n, 'reason': why})
    dist_new = collections.Counter(r['独立代码_R_X_P_N_问号'] for r in dims)

    with open('phase3_dimensions_3674_CORRECTED.json', 'w', encoding='utf-8') as f:
        json.dump(dims, f, ensure_ascii=False, indent=1)
    with open('correction_log_fda.json', 'w', encoding='utf-8') as f:
        json.dump({'total_changes': len(log), 'dist_old': dist_old, 'dist_new': dist_new,
                   'changes': log}, f, ensure_ascii=False, indent=1)

    # 试验键与编码索引
    # 3674 用 模型记录ID + 试验名称候选；trial extractions 用 候选记录ID
    # 以 药物+试验名称候选 对齐
    code_index = collections.defaultdict(dict)
    for r in dims:
        code_index[(r['药物'], r['试验名称候选'])][r['维度']] = r['独立代码_R_X_P_N_问号']

    recs = {}
    for t in trials:
        key = (t['药物'], t['试验名称候选'])
        recs.setdefault(key, t)

    trial_list = collections.defaultdict(list)
    for (drug, tn), t in recs.items():
        tk = dict(t); tk['_key'] = (t.get('药物'), t.get('试验名称候选'))
        trial_list[(t.get('药物'), t.get('方案候选') or '')].append(tk)

    # 主设定运行时排除扩展参照臂
    def scenario_trials(key):
        d = collections.defaultdict(list)
        for (drug, plan), tl in trial_list.items():
            for t in tl:
                if key in ('S6',) or t.get('来源工作表') != '扩展参照臂':
                    d[(drug, plan)].append(t)
        return d

    out = {}
    for skey in ['主设定', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10',
                 'S12', 'S14', 'S15', 'S16', 'S17', 'S18', 'S19']:
        tl = scenario_trials(skey)
        if skey == 'S10':
            for k in tl:
                tl[k] = [t for t in tl[k] if 'CIT-MD-18' not in str(t.get('试验名称候选'))]
        if skey in ('S1', 'S2', 'S3'):
            tl = {k: [t for t in v if '标签' not in str(t.get('试验名称候选'))] for k, v in tl.items()} if skey == 'S1' else tl
        m = agg_letters(tl, code_index, skey)
        cnt = collections.Counter()
        for _, row in m.items():
            for d, v in row.items():
                if d in ADULT_CORE:
                    cnt[v[0] if v and v[0] in 'ABCE' else ('B-' if v and v[0] == 'B' else v[0])] += 0
        out[skey] = {'source_note': 'corrected codes; scenarios with unavailable flags marked in report',
                     'matrix': m}
    # 只保留主设定与可算差异显著的几套为完整矩阵，其余精简
    with open('phase5_fda_letters_19_CORRECTED.json', 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False)

    # 主设定字母分布（成人核心）
    mainm = out['主设定']['matrix']
    cnt = collections.Counter()
    for rowk, row in mainm.items():
        for d in ADULT_CORE:
            v = row.get(d, '—')
            k = v[0] if v else '—'
            cnt[k] += 1
    print('主设定 成人核心19维 字母分布:', dict(cnt), '总计', sum(cnt.values()))
    print('纠正项数:', len(log), '改前:', dict(dist_old), '改后:', dict(dist_new))

if __name__ == '__main__':
    main()
