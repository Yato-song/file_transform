#!/usr/bin/env python3
"""418格独立结果 vs v4 事后对照 + FDA缺口与指南对应"""
import json, collections

def load(p):
    return json.load(open(p, encoding='utf-8'))

def main():
    ind = load('phase1_418_INDEPENDENT.json')['cells']
    v4 = load('r3_work/v4_418_grid.json')

    # 建 v4 索引
    v4idx = {}
    for r in v4:
        key = f"{r.get('药物／方案')}|{r.get('维度')}"
        v4idx[key] = r

    same = diff = und = 0
    hs = hd = hu = 0
    diffs = []
    for key, c in ind.items():
        r = v4idx.get(key)
        if r is None:
            und += 1; hu += 1; continue
        hist = (r.get('历史93格') == '是')
        def _01(x):
            try:
                return int(x)
            except (TypeError, ValueError):
                return None
        v4r = _01(r.get('研究讨论（1/0）'))
        v4a = _01(r.get('用药建议（1/0）'))
        if v4r is None or v4a is None:
            same += 1
            if hist: hs += 1
            continue
        if c['state'] == '结构不适用' or r.get('结构适用') == '否':
            same += 1
            if hist: hs += 1
            continue
        o = (1 if c['research'] else 0, 1 if c['advice'] else 0)
        if o == (v4r, v4a):
            same += 1
            if hist: hs += 1
        else:
            diff += 1
            if hist: hd += 1
            diffs.append({'cell': key, 'cell_id': r.get('格ID'), 'hist93': hist,
                          'independent': list(o), 'v4': [v4r, v4a],
                          'state': c['state'],
                          'indep_support': [x['stmt_id'] for x in c.get('support', [])][:10],
                          'v4_research_ids': r.get('研究陈述ID'),
                          'v4_advice_ids': r.get('建议陈述ID')})
    out = {
        'note': '与v4相同仅表示判断一致，不等于原文已验证；不同不表示v4错误',
        'independent_state_distribution': {k: v for k, v in ind and collections.Counter(x['state'] for x in ind.values()).items()},
        'total_cells': len(ind),
        'same': same, 'different': diff, 'undetermined': und,
        'hist93_same': hs, 'hist93_different': hd, 'hist93_undetermined': hu,
        'differences': diffs
    }
    json.dump(out, open('phase7_comparison_418_vs_v4.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('对照:', 'same', same, 'diff', diff, 'und', und, '| hist93 same', hs, 'diff', hd, 'und', hu)

    # ---- 缺口映射 ----
    fda = load('phase5_fda_letters_19_CORRECTED.json')['主设定']['matrix']
    gap = []
    for rowk, row in fda.items():
        drug, plan = rowk.split('|', 1)
        for dim, v in row.items():
            if v[0] not in ('C', 'D'):
                continue
            g = ind.get(f'{drug}|{dim}')
            gap.append({
                'key': rowk, 'dim': dim, 'fda_letter': v,
                'guideline_state': g['state'] if g else '无对应行列',
                'guideline_research': bool(g['research']) if g else None,
                'guideline_advice': bool(g['advice']) if g else None,
                'guideline_support': [x['stmt_id'] for x in g['support']][:8] if g else [],
                'condition_match': '需人工核对人群/阶段/方案'
            })
    cnt = collections.Counter((x['fda_letter'][0], x['guideline_state']) for x in gap)
    json.dump({'counts': {'total': len(gap)},
               'by_pair': {f'{a}->{b}': n for (a, b), n in cnt.items()},
               'rows': gap}, open('phase6_gap_mapping.json', 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print('缺口格(C/D):', len(gap), '按类型:', dict(cnt))

if __name__ == '__main__':
    main()
